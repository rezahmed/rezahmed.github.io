/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file ppl_constraint.h
 * Header for a concrete constraint 
 * based on the ppl library and representing
 * the possibly infinite set of configurations 
 * of the system as a convex polyhedra
 *
 * @author Rezine Ahmed
 */

#ifndef _PPL_CONSTRAINT_H
#define _PPL_CONSTRAINT_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <ppl.hh>


#include "ref.h"
#include "minset.h"
#include "cma_order.h"
#include "cma_constraint.h"
#include "partial_function.h" 

using namespace std;
using namespace Parma_Polyhedra_Library;
using namespace Parma_Polyhedra_Library::IO_Operators;

struct Z_Box_Interval_Info_Policy {
  const_bool_nodef(store_special, true);
  const_bool_nodef(store_open, false);
  const_bool_nodef(cache_empty, true);
  const_bool_nodef(cache_singleton, true);
  const_bool_nodef(cache_normalized, false);
  const_int_nodef(next_bit, 0);
  const_bool_nodef(may_be_empty, true);
  const_bool_nodef(may_contain_infinity, false);
  const_bool_nodef(check_empty_result, false);
  const_bool_nodef(check_inexact, false);
};

typedef Parma_Polyhedra_Library::Interval_Restriction_None<Interval_Info_Bitset<unsigned int,Z_Box_Interval_Info_Policy> > Z_Box_Interval_Info;

typedef Box<Interval<mpz_class, Z_Box_Interval_Info> > Z_Box;

typedef pair<Z_Box, C_Polyhedron> ZC;


class pplConstraint: public cmaConstraint
{

 public:
  
 pplConstraint(Degenerate_Element kind=UNIVERSE):zbox(Z_Box(cmaConstraint::numberOfSharedVariables, kind)),
    cpoly(C_Polyhedron(cmaConstraint::numberOfLocalVariables, kind)){}
  
 pplConstraint(Degenerate_Element zkind, Degenerate_Element ckind):
  zbox(Z_Box(cmaConstraint::numberOfSharedVariables, zkind)),
    cpoly(C_Polyhedron(cmaConstraint::numberOfLocalVariables, ckind)){}

 pplConstraint(const Z_Box& _zbox, const C_Polyhedron& _cpoly):zbox(_zbox), cpoly(_cpoly)
 {
   assert(zbox.space_dimension()==cmaConstraint::numberOfSharedVariables);
   assert(cpoly.space_dimension()==cmaConstraint::numberOfLocalVariables);
 }
  
 bool entails(const cmaConstraintRef& other) const{ 
   if((other.dyncast<pplConstraint>())->zbox.contains(zbox))
     return (other.dyncast<pplConstraint>())->cpoly.contains(cpoly);
   return false;
 }
  
 cmaConstraintRef intersect(const cmaConstraintRef& other) const{
   Z_Box ozbox=(other.dyncast<pplConstraint>())->zbox;
   ozbox.intersection_assign(zbox);
   if(ozbox.is_empty() & cmaConstraint::numberOfSharedVariables>0)
     {
       return cmaConstraintRef(new pplConstraint(Z_Box(cmaConstraint::numberOfSharedVariables, EMPTY),
						 C_Polyhedron(cmaConstraint::numberOfLocalVariables, EMPTY)));
     }

   C_Polyhedron ocpoly=(other.dyncast<pplConstraint>())->cpoly;
   ocpoly.intersection_assign(cpoly);
   return cmaConstraintRef(new pplConstraint(ozbox, ocpoly));
 }
  



 bool isEmpty()const{return (zbox.is_empty() && cmaConstraint::numberOfSharedVariables>0) | cpoly.is_empty();}
 
 friend class pplUpward;
 friend class pplRule;
 friend class pplH76Extrapolate;
 friend class pplH76BdsExtrapolate;

 static PartialFunction sharedReverse; 
 static PartialFunction localReverse; 

 static Variables_Set sharedCodomainSet;   
 static Variables_Set sharedDomainSet;  
 
 static Variables_Set localCodomainSet;   
 static Variables_Set localDomainSet;  

 static Z_Box largestBox;
 static C_Polyhedron largestCpolyhedron;
 

static map<dimension_type, string> nameOfLocalDimension;
static map<string, dimension_type> dimensionOfLocalName;

static map<dimension_type, string> nameOfSharedDimension;
static map<string, dimension_type> dimensionOfSharedName;

 static void namingLocal(ostream& s, const Variable& v);
 static void namingShared(ostream& s, const Variable& v);



 virtual ~pplConstraint(){}
 
 protected:
 void printOn(std::ostream& o) const {
   o << "[" ;
   if(numberOfSharedVariables>0)
     {
       Variable::set_output_function(namingShared);
       o << zbox << ":" ;
     }
   Variable::set_output_function(namingLocal);
   o << cpoly << "]" ; 
 };
 
 private:
 
 pplConstraint join(const pplConstraint& other) const{
   Z_Box ozbox=other.zbox;
   ozbox.upper_bound_assign(zbox);
   C_Polyhedron ocpoly=other.cpoly;
   ocpoly.poly_hull_assign(cpoly);
   return pplConstraint(ozbox, ocpoly);
 }

 Z_Box zbox;
 C_Polyhedron cpoly;
};


#endif
