/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file ppl_upward.h
 *
 * @author Rezine Ahmed
 */

#ifndef _PPL_UPWARD_H
#define _PPL_UPWARD_H

//#define DEBUG_NEGATE

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <list>
#include <ppl.hh>

#include "ref.h"
#include "minset.h"
#include "cma_order.h"
#include "cma_upward.h"
#include "cma_constraint.h"
#include "ppl_constraint.h"

using namespace std;
using namespace Parma_Polyhedra_Library;
using namespace Parma_Polyhedra_Library::IO_Operators;

typedef pair<C_Polyhedron, C_Polyhedron> CC;

class pplUpward: public cmaUpward, private list<CC>
{
  public:
 
  pplUpward()
    { CC p(C_Polyhedron(2*cmaConstraint::numberOfSharedVariables,UNIVERSE),
	   C_Polyhedron(2*cmaConstraint::numberOfLocalVariables,UNIVERSE));
      push_back(p);}

  pplUpward(const C_Polyhedron& z_rel, const C_Polyhedron& c_rel)
    { assert(z_rel.space_dimension()==2*cmaConstraint::numberOfSharedVariables);
      assert(c_rel.space_dimension()==2*cmaConstraint::numberOfLocalVariables);
      push_back(CC(z_rel,c_rel)); }

  pplUpward(const list<CC>& rels)
    {
      list<CC>::const_iterator rel=rels.begin();
      for(; rel!=rels.end(); ++rel)
	{
	  assert(rel->first.space_dimension()==2*cmaConstraint::numberOfSharedVariables);
	  assert(rel->second.space_dimension()==2*cmaConstraint::numberOfLocalVariables);
	  push_back(CC(rel->first, rel->second)); 
	}
    }

  cmaUpwardRef 
    constrainWith(const cmaConstraintRef& frontier) const
  {
    const pplConstraint* pplfrontier=
      dynamic_cast<const pplConstraint*>(frontier.getPtr());
    assert(pplfrontier);

    Z_Box frontierBox = pplfrontier->zbox;
    frontierBox.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
    //Variable::set_output_function(pplConstraint::namingShared);
    
    C_Polyhedron frontierPoly=pplfrontier->cpoly;
    frontierPoly.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
    //Variable::set_output_function(pplConstraint::namingLocal);
    
    list<CC> newConstrainedRel=negate(ZC(frontierBox,frontierPoly));

    C_Polyhedron zIdentity(frontierBox);
    //    zIdentity.map_space_dimensions(pplConstraint::sharedReverse);
    //zIdentity.intersection_assign(C_Polyhedron(frontierBox));
    C_Polyhedron cIdentity(frontierPoly);
    //cIdentity.map_space_dimensions(pplConstraint::localReverse);
    //cIdentity.intersection_assign(frontierPoly);

    newConstrainedRel.push_back(CC(zIdentity,cIdentity));

    pplUpward result;  result.clear();

    for(list<CC>::const_iterator previt = begin(); previt!=end(); ++previt)
      {
	for(list<CC>::const_iterator relit=newConstrainedRel.begin(); 
	    relit!=newConstrainedRel.end(); ++relit)
	  {
	    C_Polyhedron zcandidate = relit->first;
	    //zcandidate.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
	    zcandidate.map_space_dimensions(pplConstraint::sharedReverse);
	    zcandidate.intersection_assign(relit->first);
	    //zcandidate.intersection_assign(C_Polyhedron(pplConstraint::largestBox));
	    zcandidate.intersection_assign(previt->first);
	    if(!zcandidate.is_empty())
	      {
		C_Polyhedron candidate = relit->second;
		candidate.map_space_dimensions(pplConstraint::localReverse);
		candidate.intersection_assign(relit->second);
		//candidate.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
		//candidate.intersection_assign(pplConstraint::largestCpolyhedron);
		candidate.intersection_assign(previt->second);
		if(!candidate.is_empty())
		  result.push_back(CC(zcandidate,candidate));
	      }
	  }
      }
    cmaUpwardRef rref(new pplUpward(result));
    return rref;
  } 


  cmaSetConstraintRef 
    close(const cmaConstraintRef& cstr) const{
    cmaSetConstraintRef p;
    const pplConstraint* pplcstr=
      dynamic_cast<const pplConstraint*>(cstr.getPtr());
    //assert(pplcstr);

    //cout << "to be closed " << cstr << endl;
    
    C_Polyhedron cstrBox=C_Polyhedron(pplcstr->zbox);
    cstrBox.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
    //Variable::set_output_function(pplConstraint::namingShared);
    //cout << "cstrBox "<< cstrBox << endl;

    C_Polyhedron cstrCpoly =pplcstr->cpoly; 
    cstrCpoly.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
    //Variable::set_output_function(pplConstraint::namingLocal);
    //cout << "cstrCpoly "<< cstrCpoly << endl;


    for(list<CC>::const_iterator it=begin(); it!=end(); ++it)
      {
	C_Polyhedron zcandidate=it->first;
	//Variable::set_output_function(pplConstraint::namingShared);
	//cout << "z rule: " << zcandidate << endl;
	zcandidate.intersection_assign(cstrBox);
	if(!zcandidate.is_empty())
	  {
	    zcandidate.map_space_dimensions(pplConstraint::sharedReverse);
	    zcandidate.remove_space_dimensions(pplConstraint::sharedCodomainSet);
	    //zcandidate.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
	
	    C_Polyhedron candidate=it->second;
	    //Variable::set_output_function(pplConstraint::namingLocal);
	    //cout << "c rule: " << candidate << endl;
	    candidate.intersection_assign(cstrCpoly);
	    //	    cout << "c rule & cstr: " << candidate << endl;
	    if(!candidate.is_empty())
	      {
		candidate.map_space_dimensions(pplConstraint::localReverse);
		candidate.remove_space_dimensions(pplConstraint::localCodomainSet);
		//		cout << "result candidate: " << candidate << endl;
		//candidate.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
		p.insert(cmaConstraintRef(new pplConstraint(Z_Box(zcandidate),candidate)));
	      }
	  }
      }

    return p;
  }; 


  virtual ~pplUpward(){}

 protected:
  void printOn(std::ostream& o) const{ 
    list<CC>::const_iterator it=begin(); 
    if(it!=end()){
      o << std::endl 
	<< "   {"; 
      if(pplConstraint::numberOfSharedVariables!=0)
	{
	  Variable::set_output_function(pplConstraint::namingShared);
	  o << it->first << ":";
	}
      Variable::set_output_function(pplConstraint::namingLocal);
      o << it->second; 
      o << "}" << std::endl;
      ++it;
    }
    for(; it!=end();++it)
      {
	o << "or {";
	if(pplConstraint::numberOfSharedVariables!=0)
	  {
	    Variable::set_output_function(pplConstraint::namingShared);    
	    o << it->first << ":";
	  }
	Variable::set_output_function(pplConstraint::namingLocal);
	o << it->second; 
	o << "}" << std::endl;
      }
  };

 private:

  static list<CC> negate(const ZC& pairToBeNegated) 
  {
    Z_Box boxToBeNegated = pairToBeNegated.first;
    C_Polyhedron polyToBeNegated = pairToBeNegated.second;

    //    Variable::set_output_function(pplConstraint::namingShared);    
    //cout << "boxToBeNegated: " << boxToBeNegated << endl;

    //Variable::set_output_function(pplConstraint::namingLocal);    
    //cout << "polyToBeNegated: " << polyToBeNegated << endl;

    list<CC> neg;
    list<Z_Box> zneg;
    list<C_Polyhedron> pneg;

    Variable::set_output_function(pplConstraint::namingShared);    

    if(pplConstraint::numberOfSharedVariables>0)
      {

	Constraint_System zcs = boxToBeNegated.minimized_constraints();
	Z_Box zprevious=pplConstraint::largestBox;
	//zprevious.remove_space_dimensions(pplConstraint::sharedCodomainSet);
	Constraint_System zcurrent=zprevious.minimized_constraints();
	//	Variable::set_output_function(pplConstraint::namingShared);    
	for(Constraint_System::const_iterator izcs=zcs.begin(), zcs_end=zcs.end(); izcs!=zcs_end;++izcs){
	  //assert(! izcs->is_strict_inequality());
	  Linear_Expression e;
	  for(dimension_type dim=izcs->space_dimension(); dim-->0; )
	    e+=izcs->coefficient(Variable(dim))*Variable(dim);
	  e+=izcs->inhomogeneous_term();
	  if(izcs->is_equality()){
	    Constraint_System zcsi; zcsi.insert(e>=1);
	    Z_Box zcandidate(zcsi);
	    zcandidate.intersection_assign(zprevious);
	    if(!zcandidate.is_empty())
	      {
		zneg.push_back(zcandidate);
	      }
	  }
	  Constraint_System zcsi; zcsi.insert(e<=-1);
	  Z_Box zcandidate(zcsi);
	  zcandidate.intersection_assign(zprevious);
	  if(!zcandidate.is_empty())
	    {
	      zneg.push_back(zcandidate);
	    }
	  zcurrent.insert(*izcs);
	  zprevious=Z_Box(zcurrent);
	}
      }
    //	zneg.push_back(pplConstraint::largestBox);


    //Variable::set_output_function(pplConstraint::namingLocal);    

    Constraint_System pcs = polyToBeNegated.minimized_constraints();
    C_Polyhedron pprevious=pplConstraint::largestCpolyhedron;
    //pprevious.remove_space_dimensions(pplConstraint::localCodomainSet);
    Constraint_System pcurrent=pprevious.minimized_constraints();
    Variable::set_output_function(pplConstraint::namingLocal);    
    for(Constraint_System::const_iterator ipcs=pcs.begin(), pcs_end=pcs.end(); ipcs!=pcs_end;++ipcs){
      //      assert(! ipcs->is_strict_inequality());
      Linear_Expression e;
      for(dimension_type dim=ipcs->space_dimension(); dim-->0; )
	e+=ipcs->coefficient(Variable(dim))*Variable(dim);
      e+=ipcs->inhomogeneous_term();
      if(ipcs->is_equality()){
	Constraint_System pcsi; pcsi.insert(e>=1);
	C_Polyhedron pcandidate(pcsi);
	pcandidate.intersection_assign(pprevious);
	if(!pcandidate.is_empty())
	  {
	    pneg.push_back(pcandidate);
	}
      }
      Constraint_System pcsi; pcsi.insert(e<=-1);
      C_Polyhedron pcandidate(pcsi);
      pcandidate.intersection_assign(pprevious);
      if(!pcandidate.is_empty())
	{
	  pneg.push_back(pcandidate);
	}
      pcurrent.insert(*ipcs);
      pprevious=C_Polyhedron(pcurrent);
    }

    //    cout << "negation of " << pairToBeNegated.first << ": " << pairToBeNegated.second << endl;

    list<C_Polyhedron>::const_iterator pit=pneg.begin();
    for(; pit!=pneg.end(); ++pit)
      {
	//	cout << "  or:" ; 
	//Variable::set_output_function(pplConstraint::namingShared);    
	//cout << C_Polyhedron(pplConstraint::largestBox);
	//Variable::set_output_function(pplConstraint::namingLocal);    
	//cout << *pit << endl;

	neg.push_back(CC(C_Polyhedron(pplConstraint::largestBox),*pit));
      }
    
    //if(pplConstraint::numberOfSharedVariables == 0)
    //  assert(zneg.empty());

    list<Z_Box>::const_iterator zit=zneg.begin();
    for(; zit!=zneg.end(); ++zit)
      {
	//	cout << "  or:" ; 
	//Variable::set_output_function(pplConstraint::namingShared);    
	//cout << C_Polyhedron(*zit);
	//Variable::set_output_function(pplConstraint::namingLocal);    
	//cout << pplConstraint::largestCpolyhedron << endl;
	//neg.push_back(CC(C_Polyhedron(*zit),pplConstraint::largestCpolyhedron));
	neg.push_back(CC(C_Polyhedron(*zit),polyToBeNegated));
      }
    /*    
    zit=zneg.begin();
    for(; zit!=zneg.end(); ++zit)
      {
	list<C_Polyhedron>::const_iterator pit=pneg.begin();
	for(; pit!=pneg.end();++pit)
	  {
	    cout << "obtaining : " << endl;
	    Variable::set_output_function(pplConstraint::namingShared);    
	    cout << C_Polyhedron(*zit) << endl;
	    Variable::set_output_function(pplConstraint::namingLocal);    
	    cout << *pit << endl;
	    neg.push_back(CC(C_Polyhedron(*zit),*pit));
	  }
      }
    */
    return neg;
  }

};

#endif
