/*
    Copyright (C) 2003 Johann Deneux

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>
*/

#ifndef _REF_H
#define _REF_H

//#define REF_DEBUG
#ifdef REF_DEBUG
#include <iostream>
#endif

#include <assert.h>

//! Non intrusive reference class
/*! Provides reference counting garbage collection */
template<class T>
class Ref
{
public:
    Ref(): rep(0) {
#ifdef REF_DEBUG
	std::cerr<<"Created null reference"<<std::endl;
#endif
	count = new int(1);
    }

    explicit Ref(T* p): rep(p) {
#ifdef REF_DEBUG
	std::cerr<<"Created reference on "<<rep<<std::endl;
#endif
	count = new int(1);
    }

    Ref(const Ref<T>& other): rep(other.rep), count(other.count) {
	++(*count);
#ifdef REF_DEBUG
	std::cerr<<(*count)<<"th reference on "<<rep<<std::endl;
#endif
    }

    //! Build a reference by providing a pointer and a count
    /*! Keep children away ! */
    Ref(T* p, int* c): rep(p), count(c) {++(*count);}

    //! Static cast to type U
    template<class U> Ref<U> statcast() {
	Ref<U> ret(static_cast<U*>(rep), count);
#ifdef REF_DEBUG
	std::cerr<<(*count)<<"th reference on "<<rep<<std::endl;
#endif
	return ret;
    }

    //! Dynamic cast to type U
    template<class U> Ref<U> dyncast() const {
	U* ptr = dynamic_cast<U*>(rep);
	if (ptr) {
	    return Ref<U>(ptr, count);
	}
	return Ref<U>(0, new int(0));
    }

    //! C-like cast
    /*! Note The cast operator could have been used instead, but using
             explicit casts functions seems less dangerous
    */
    template<class U> Ref<U> ccast() const {
	return Ref<U>((U*)rep, count);
    }

    //! Check if this is a null reference
    operator bool() const { return rep != 0; }

    T* operator->() { return rep; }
    const T* operator->() const { return rep; }

    T& operator*() { return *rep; }
    const T& operator*() const { return *rep; }

    Ref<T>& operator=(const Ref<T>& other) {
	if (rep == other.rep) {
	    assert(count == other.count);
	    return *this;
	}

	release();
	rep = other.rep;
	count = other.count;
	++(*count);

#ifdef REF_DEBUG
	std::cerr<<(*count)<<"th reference on "<<rep<<std::endl;
#endif

	return *this;
    }

    bool operator<(const Ref<T>& other) const {
	return rep < other.rep;
    }

    //! Direct access to the pointer
    /*! To be used with caution */
    T* getPtr() { return rep; }
    const T* getPtr() const { return rep; }

    ~Ref() { release(); }

private:
    void release() {
	--(*count);
#ifdef REF_DEBUG
	std::cerr<<"Released "<<rep<<". Now "<<(*count)<<std::endl;
#endif
	if (*count == 0) { delete count; if (rep != 0) delete rep; }
    }

    T* rep;
    int* count;
};

template< class T >
class UnRefEq {
public:
    UnRefEq(Ref<T> r): ref(r) {}

    inline bool operator()(Ref<T> other) { return *ref == *other; }
private:
    Ref<T> ref;
};

#endif
