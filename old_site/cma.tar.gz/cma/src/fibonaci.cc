
#include <config.h>
#include <iostream>
#include <stdlib.h>
#include <ppl.hh>
#include <string>
#include <map>

#include "partial_function.h" 


using namespace Parma_Polyhedra_Library;
using namespace Parma_Polyhedra_Library::IO_Operators;

using namespace std;

  Variable am4(0); //a-4
  Variable am3(1); //a-3
  Variable am2(2); //a-2
  Variable am1(3); //a-1
  Variable a0(4);  //a0
  Variable a1(5);  //a1
  Variable a2(6);  //a2
  Variable a3(7);  //a3
  Variable a4(8);  //a4
  
  Variable m1(9);  //m1
  Variable m2(10);  //m2
  

void naming(std::ostream& s, const Variable& v)
{
  dimension_type varid = v.id();
  switch(varid)
    {
    case 0: s << "am4"; break;
    case 1: s << "am3"; break;
    case 2: s << "am2"; break;
    case 3: s << "am1"; break;
    case 4: s << "a0"; break;
    case 5: s << "a1"; break;
    case 6: s << "a2"; break;
    case 7: s << "a3"; break;
    case 8: s << "a4"; break;
    case 9: s << "m1"; break;
    case 10: s << "m2"; break;
    default: s << "UNKNOWN"; break;
  }
};

class square
{
public:

  square(bool pervasive=true):content(C_Polyhedron(11, (pervasive? UNIVERSE : EMPTY))){}

  square(const C_Polyhedron& _content) :content(_content){}

  void set_initial_to_m1(int initial){
    content.unconstrain(m1);
    content.add_constraint_and_minimize(m1==initial);}

  void set_initial_to_m2(int initial){
    content.unconstrain(m2);
    content.add_constraint_and_minimize(m2==initial);}

  void set_m2_to_m1(){
    content.unconstrain(m1);
    content.add_constraint_and_minimize(m1==m2);}


  void save_m1_in_am4(){
    content.unconstrain(am4);
    content.add_constraint_and_minimize(am4==m1);
  }

  void save_m2_in_a4(){
    content.unconstrain(a4);
    content.add_constraint_and_minimize(a4==m2);
  }

  void set_rx_to_m2(){
    content.unconstrain(m2);
    content.add_constraint_and_minimize(m2==am4+a4);
    content.unconstrain(am4);
    content.unconstrain(a4);
  }

  square join(const square& sq){
    C_Polyhedron result=content;
    result.poly_hull_assign_and_minimize(sq.content);
    return square(result);}

  square meet(const square& sq){
    C_Polyhedron result=content;
    result.intersection_assign_and_minimize(sq.content);
    return square(result);}


  square translate(int shift){
    C_Polyhedron result=content;
    cout << "entry" << content << endl;
    cout << "shift " << shift << endl;
    switch(shift) {
    case -3:
      //result.unconstrain(am4);      //result.add_constraint_and_minimize(am4==am1);
      result.unconstrain(am3);      result.add_constraint_and_minimize(am3==a0);
      result.unconstrain(am2);      result.add_constraint_and_minimize(am2==a1);
      result.unconstrain(am1);      result.add_constraint_and_minimize(am1==a2);
      result.unconstrain(a0);      result.add_constraint_and_minimize(a0==a3);
      result.unconstrain(a1);      //result.add_constraint_and_minimize(a1==a4);
      result.unconstrain(a2);
      result.unconstrain(a3);
      //      result.unconstrain(a4);
      break;
     case -2:
       //result.unconstrain(am4);      result.add_constraint_and_minimize(am4==am2);
      result.unconstrain(am3);      result.add_constraint_and_minimize(am3==am1);
      result.unconstrain(am2);      result.add_constraint_and_minimize(am2==a0);
      result.unconstrain(am1);      result.add_constraint_and_minimize(am1==a1);
      result.unconstrain(a0);      result.add_constraint_and_minimize(a0==a2);
      result.unconstrain(a1);      result.add_constraint_and_minimize(a1==a3);
      result.unconstrain(a2);      //result.add_constraint_and_minimize(a2==a4);
      result.unconstrain(a3);
      //      result.unconstrain(a4);
      break;
    case -1:
      //      result.unconstrain(am4);      result.add_constraint_and_minimize(am4==am3);
      result.unconstrain(am3);      result.add_constraint_and_minimize(am3==am2);
      result.unconstrain(am2);      result.add_constraint_and_minimize(am2==am1);
      result.unconstrain(am1);      result.add_constraint_and_minimize(am1==a0);
      result.unconstrain(a0);      result.add_constraint_and_minimize(a0==a1);
      result.unconstrain(a1);      result.add_constraint_and_minimize(a1==a2);
      result.unconstrain(a2);      result.add_constraint_and_minimize(a2==a3);
      result.unconstrain(a3); //     result.add_constraint_and_minimize(a3==a4);
      //      result.unconstrain(a4);
      break;
    case 0:
      break;
    case 1:
      //      result.unconstrain(a4);      result.add_constraint_and_minimize(a3==a4);
      result.unconstrain(a3);      result.add_constraint_and_minimize(a2==a3);
      result.unconstrain(a2);      result.add_constraint_and_minimize(a1==a2);
      result.unconstrain(a1);      result.add_constraint_and_minimize(a0==a1);
      result.unconstrain(a0);      result.add_constraint_and_minimize(am1==a0);
      result.unconstrain(am1);      result.add_constraint_and_minimize(am2==am1);
      result.unconstrain(am2);      result.add_constraint_and_minimize(am3==am2);
      result.unconstrain(am3);   //   result.add_constraint_and_minimize(am4==am3);
      //      result.unconstrain(am4);
      break;
    case 2:
      //  result.unconstrain(a4);      result.add_constraint_and_minimize(a2==a4);
      result.unconstrain(a3);      result.add_constraint_and_minimize(a1==a3);
      result.unconstrain(a2);      result.add_constraint_and_minimize(a0==a2);
      result.unconstrain(a1);      result.add_constraint_and_minimize(am1==a1);
      result.unconstrain(a0);      result.add_constraint_and_minimize(am2==a0);
      result.unconstrain(am1);      result.add_constraint_and_minimize(am3==am1);
      result.unconstrain(am2);     // result.add_constraint_and_minimize(am4==am2);
      result.unconstrain(am3);      
      //result.unconstrain(am4);
      break;
    case 3:
      //      result.unconstrain(a4);      result.add_constraint_and_minimize(a1==a4);
      result.unconstrain(a3);      result.add_constraint_and_minimize(a0==a3);
      result.unconstrain(a2);      result.add_constraint_and_minimize(am1==a2);
      result.unconstrain(a1);      result.add_constraint_and_minimize(am2==a1);
      result.unconstrain(a0);      result.add_constraint_and_minimize(am3==a0);
      result.unconstrain(am1); //     result.add_constraint_and_minimize(am4==am1);
      result.unconstrain(am2);      
      result.unconstrain(am3);      
      //      result.unconstrain(am4);
      break;
    default: 
      assert(false);
      break;
    }
    cout << "exwit" << result << endl;
    return result;
  }
    


  void set_to_m1_plus_m2(int k){
    switch(k) {
    case -4:
      content.unconstrain(am4);
      content.add_constraint_and_minimize(am4==m1+m2);
      break;
    case -3:
      content.unconstrain(am3);
      content.add_constraint_and_minimize(am3==m1+m2);
      break;
    case -2:
      content.unconstrain(am2);
      content.add_constraint_and_minimize(am2==m1+m2);
      break;
    case -1:
      content.unconstrain(am1);
      content.add_constraint_and_minimize(am1==m1+m2);
      break;
    case 0:
      content.unconstrain(a0);
      content.add_constraint_and_minimize(a0==m1+m2);
      break;
    case 1:
      content.unconstrain(a1);
      content.add_constraint_and_minimize(a1==m1+m2);
      break;
    case 2:
      content.unconstrain(a2);
      content.add_constraint_and_minimize(a2==m1+m2);
      break;
    case 3:
      content.unconstrain(a3);
      content.add_constraint_and_minimize(a3==m1+m2);
      break;
    case 4:
      content.unconstrain(a4);
      content.add_constraint_and_minimize(a4==m1+m2);
      break;
    default: 
      break;
    }    
  }

  set<int> dependsOn()
  {
    set<int> result;
    C_Polyhedron test=content;
    test.unconstrain(am4);
    if(!(test==content))
      result.insert(-4);
    test=content;
    test.unconstrain(am3);
    if(!(test==content))
      result.insert(-3);
    test=content;
    test.unconstrain(am2);
    if(!(test==content))
      result.insert(-2);
    test=content;
    test.unconstrain(am1);
    if(!(test==content))
      result.insert(-1);
    test=content;
    test.unconstrain(a0);
    if(!(test==content))
      result.insert(0);
    test=content;
    test.unconstrain(a1);
    if(!(test==content))
      result.insert(1);
    test=content;
    test.unconstrain(a2);
    if(!(test==content))
      result.insert(2);
    test=content;
    test.unconstrain(a3);
    if(!(test==content))
      result.insert(3);
    test=content;
    test.unconstrain(a4);
    if(!(test==content))
      result.insert(4);
    return result;
  }


  friend std::ostream& operator<< (std::ostream& out, const square& sq);

private:
  C_Polyhedron content;
};

inline std::ostream& operator<< 
(std::ostream& o, const square& sq){
  o << "[" << sq.content << "]";
  return o;};


class labels: public set<string>
{
public:
  labels(){}

  labels(const string& label){add(label);}

  bool contains(const string& label) const
  {return find(label)!=end();}

  bool add(const string& label) 
  {
    if (contains(label)) 
      return false;
    insert(label); 
    return true;
  }

  bool remove(const string& label)
  {
    if (!contains(label))
      return false;
    erase(find(label)); 
    return true;
  }

  bool replace(const string& el, const string& by)
  {
    if(find(el)==end())
      return false;
    erase(find(el));
    insert(by);
    return true;
  }

  labels intersection(const labels& other) const
  {
    labels result;
    for(labels::const_iterator it=begin(); it!=end(); ++it)
      if(other.contains(*it))
	result.add(*it);
    return result;
  }

  bool intersects(const labels& other) const
  {
    labels inter = intersection(other);
    return !inter.empty();
  }

  bool isSingleton(){return size()==1;}

  string getElement(){assert(begin()!=end()); return *begin();}


};

inline std::ostream& operator<< 
(std::ostream& o, const labels& lab)
{
  o << "{";
  labels::const_iterator l=lab.begin();
  if(l!=lab.end())
    {
      o << *l;
      ++l;
    }
  for(; l!=lab.end(); ++l)
    o << " " << *l;
  o << "}";    

  return o;
};



class chain
{
public:
  
  chain(){};

  chain(const labels& _src, const square& _head, const int& _length, const square& _body, const labels& _dest)
    :src(_src), head(_head), l(_length), body(_body), dest(_dest){}

  bool mayCoexist(const chain& other)
  {
    if(src.intersects(other.src) | dest.intersects(other.dest))
      return false;
    return true;      
  }

  friend std::ostream& operator<< (std::ostream& out, const chain& lst);

  labels src, dest;

  square head, body;

  int l;
};

inline std::ostream& operator<< 
(std::ostream& o, const chain& lst)
{
  o << "[" << lst.src << ":" 
    << lst.head 
    << ",l=" << lst.l 
    << "," << lst.body 
    << "," << lst.dest << "]";
  return o;
};


class abstractElement: public list<chain>
{
  typedef list<chain>::iterator iterator;
  typedef list<chain>::const_iterator const_iterator;

public:
  abstractElement(int _maxHistory):maxHistory(_maxHistory){}

  bool add(const chain& candidate)
  {
    for(iterator it=begin(); it!=end(); ++it)
      if(!it->mayCoexist(candidate))
	return false;
    push_back(candidate);
    return true;
  }

  void incrementAge(const string& label, const int& k)
  {

    stringstream froms;    froms << label;
    if(k>0)
      froms << k;
    string from = froms.str();
    stringstream tos;    tos << label << k+1 ;
    string to = tos.str();

    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->src.replace(from, to);
	aeit->dest.replace(from, to);
      }
  }


  iterator findInSource(const string& label)
  {
    iterator result=begin();
    for(; result!=end(); ++result)
      if(result->src.contains(label))
	break;
    return result;
  }
  iterator findInDestination(const string& label)
  {
    iterator result=begin();
    for(; result!=end(); ++result)
      if(result->dest.contains(label))
	break;
    return result;
  }


  void shift(const string& label)
  {
    //increase ages
    for(int k=maxHistory; k>=0; --k)
      incrementAge(label, k);
    
    //add label
    stringstream label1s;    label1s << label << 1;
    iterator s=findInSource(label1s.str());
    assert(s!=end());
    iterator d=findInDestination(label1s.str());
    if(d!=end())  
      assert(s->src==d->dest);

    if(s->l > 1)
      {
	chain c(labels(label), s->body, (s->l)-1, s->body, s->dest);
	
	s->l=1;
	s->body=square(false);
	s->dest=labels(label);
	assert(add(c));
      }
    else
      {
	iterator o = findInSource(s->dest.getElement());
	s->dest.add(label);
	o->src.add(label);
      }


    //removing oldest
    stringstream maxLabel;    maxLabel << label << maxHistory+1;
    s=findInSource(maxLabel.str());
    d=findInDestination(maxLabel.str());

    //    assert(s!=end());

    if(s!=end())
      {
	if(s->src.isSingleton())
	  {
	    assert(d!=end());
	    d->body = (s->head).join(d->body);
	    d->body = (s->body).join(d->body);
	    d->l = d->l + s->l;
	    d->dest = s->dest;
	    erase(s);
	  }
	else
	  {
	    s->src.remove(maxLabel.str());
	    if(d!=end())
	      d->dest.remove(maxLabel.str());	    
	  }
      }
    
  }

  void set_initial_to_m1(int initial)
  {
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->head.set_initial_to_m1(initial);
	aeit->body.set_initial_to_m1(initial);
      }
  }

  void set_initial_to_m2(int initial)
  {
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->head.set_initial_to_m2(initial);
	aeit->body.set_initial_to_m2(initial);
      }
  }

  void set_m2_to_m1()
  {
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->head.set_m2_to_m1();
	aeit->body.set_m2_to_m1();
      }
  }


  void set_rx_to_m2(){
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->head.set_rx_to_m2();
	aeit->body.set_rx_to_m2();
      }
  }

  void save_m1_in_am4(){
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->head.save_m1_in_am4();
	aeit->body.save_m1_in_am4();
      }
  }

  void save_m2_in_a4(){
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	aeit->head.save_m2_in_a4();
	aeit->body.save_m2_in_a4();
      }
  }


  void normalize()
  {
    for(iterator aeit=begin(); aeit!=end(); ++aeit)
      {
	cout << "dealing with " << *aeit << endl; 
	iterator previous = aeit;
	previous = findInDestination(previous->src.getElement());
	bool ecum = previous!=end();
	int shift=0;
	while(ecum)
	  {
	    --shift;
	    if(previous->l==1)
	      {
		aeit->head=(previous->head.translate(shift)).meet(aeit->head);
		previous = findInDestination(previous->src.getElement());
		ecum = previous!=end();
	      }
	    else
	      ecum=false;
	  }

	iterator next = aeit;
	next = findInSource(next->dest.getElement());
	ecum = next!=end() && aeit->l==1;
	shift=0;
	while(ecum)
	  {
	    ++shift;
	    aeit->head=(next->head.translate(shift)).meet(aeit->head);
	    ecum = next->l==1;
	    next = findInSource(next->dest.getElement());
	    ecum = next!=end() && ecum; 
	  }
	cout << "obtained " << *aeit << endl;
      }
  }

  void widen(abstractElement other)
  {
    
  }

  void set_to_m1_plus_m2(const string& label)
  {
    iterator s=findInSource(label);
    iterator d=findInDestination(label);
    assert(s!=end());
 

    // this is a delicate part.
    // we use historical stamps to replace constant shifts.
    // this needs to be clearly defined:
    // 1. let rx be the label to be assigned.
    // 2. if a label x is a neighbor of some neighbor of rx, then
    //    x is said to be a neighbor of rx. the formula associated to x
    //    is to be updated with the assignement of rx.
    // 3. we also need to look at each "partition" whether it refers to an
    //   element that could be the one pointed to by rx.
    //   one issue here is to decide the refering part:  we are dealing with lists
    //   that may change. 
    //   Say for instance that x is a neighbor of rx, that we update
    //   x after changing rx, and that we insert a fresh element between x and rx using some
    //   label tmp, and that rx is modified so that it labels the labeling of tmp, and that we move away our tmp friend,
    //   and use it to insert new elements. we end up with lrger and larger references  in x's formula to 
    //   successor elements.
    //   This is to be avoided if it generates unbounded formulae.
    //   We need tyo manipulate static references while keeping them consistent
    //   So in the scenarion above, where x references +1, then +2, then ...
    //   we stop at +2, if no historic stamps are used, more if used but in a finite manner,
    //   where 2 is the largest neighboring chain. Introducing more historical elements
    //   increases the  precision and the amount of work.
    //   Needs to be clearly stated:
    //   
    


    int length=0;
    s->head.set_to_m1_plus_m2(length);

    while(d!=end())
      {
	square el(false);
	set<int> dep = d->body.dependsOn();
	int modified_elements=0;
	for(set<int>::const_iterator depit=dep.begin();depit!=dep.end(); ++depit)
	  {
	    if((length < (*depit)) && ( (*depit) < length+d->l ))
	      {
		square tmp=d->body;
		tmp.set_to_m1_plus_m2(*depit);
		el=el.join(tmp); 
		++modified_elements;
	      } 
	  }
	if(modified_elements==(d->l-1))
	  d->body=el;
	else
	  d->body=el.join(d->body);

	length+=d->l;
	
	dep = d->head.dependsOn();
	for(set<int>::const_iterator depit=dep.begin();depit!=dep.end(); ++depit)
	  if(*depit==length)
	    d->head.set_to_m1_plus_m2(length);
	
	d=findInDestination(d->src.getElement());	
      }

  }
  
  friend std::ostream& operator<< (std::ostream& out, const abstractElement& ae);
  int maxHistory;
};

inline std::ostream& operator<< (std::ostream& o, const abstractElement& ae)
{
  for(abstractElement::const_iterator it=ae.begin();
      it!=ae.end(); ++it)
    o << *it;
  return o;
};

int main (void)
{

  Variable::set_output_function(naming);

  labels sx, snone;
  sx.add("x");sx.add("rx");
  snone.add("none");
  chain c0(sx,square(), 10, square(), snone);
  abstractElement ae(2);
  ae.add(c0);
  std::cout << "ae =" << ae << std::endl;
  ae.set_initial_to_m1(0);
  ae.set_initial_to_m2(1);
  std::cout << "m1,m2 := 0,1 " << std::endl 
	    << ae << std::endl;

  abstractElement previous=ae;

  for(int iter=0; iter!=6; ++iter)
    {

      std::cout << "###################"<< std::endl;

      previous=ae;
      ae.save_m1_in_am4();
      ae.save_m2_in_a4();
      ae.set_to_m1_plus_m2("rx");
      std::cout << "rx := m1+m2 " 
		<< std::endl << ae << std::endl;
      ae.normalize();
      std::cout << "normalize " 
		<< std::endl << ae << std::endl;
  
      ae.set_m2_to_m1();
      std::cout << "m1:=m2 " 
		<< std::endl << ae << std::endl;
      ae.normalize();
      std::cout << "normalize " 
		<< std::endl << ae << std::endl;
      
      ae.set_rx_to_m2();
      std::cout << "m2:=rx " << std::endl 
		<< ae << std::endl;
      ae.normalize();
      std::cout << "normalize " 
		<< std::endl << ae << std::endl;
      
      ae.shift("rx");
      std::cout << "++rx "   << std::endl 
		<< ae << std::endl;
      ae.normalize();
      std::cout << "normalize " 
		<< std::endl << ae << std::endl;

      //      ae.widen(previous);
      //std::cout << "widened " << std::endl
      //		<< ae << std::endl;
    }

  return 0;
}

