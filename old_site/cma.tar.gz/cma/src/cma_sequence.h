/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/

/**@file cma_sequence.h
 * Whatever is needed for tracing
 *
 *@author Ahmed Rezine
 */

#ifndef _CMA_SEQUENCE_H
#define _CMA_SEQUENCE_H

#include <iostream>
#include <stdlib.h>
#include <map>

#include "ref.h"
#include "cma_constraint.h"
#include "cma_rule.h"

class cmaSequence;

typedef Ref<cmaSequence> cmaSequenceRef;

class cmaSequence 
{
 public:
  cmaSequence(){}

  bool addSetOfConstraints(const cmaSetConstraintRef& cstr_set)
  {constraints.push_back(cstr_set);}

  bool addRule(const cmaRuleRef& rule)
  {rules.push_back(rule); }

  void clear(){constraints.clear();rules.clear();};
  
  friend std::ostream& operator<< (std::ostream& o, const cmaSequenceRef& sequence);
  
 private:
  std::list<cmaSetConstraintRef > constraints;
  std::list<cmaRuleRef> rules;
};

inline std::ostream& operator<<
(std::ostream& o, const cmaSequenceRef& sequence)
{
  std::list<cmaSetConstraintRef>::const_iterator 
    cit=sequence->constraints.begin();
  std::list<cmaRuleRef>::const_iterator rit=
    sequence->rules.begin();

  if(cit!=sequence->constraints.end())
    {
      o<< *cit << std::endl;
      ++cit;
    }
  while(cit!=sequence->constraints.end()) 
    {
      assert(rit!=sequence->rules.end());
      o << "via rule: " << (*rit)->getRuleIdentifier() << std::endl 
	<< "gives: " << std::endl 
	<< *cit << std::endl ;
      ++cit;
      ++rit;
    }

  return o;
};

#endif

