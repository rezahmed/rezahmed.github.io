/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file ppl_rule.h
  *
 * @author Rezine Ahmed
 */

#ifndef _PPL_RULE_H
#define _PPL_RULE_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <ppl.hh>

#include "ref.h"
#include "minset.h"
#include "cma_order.h" 
#include "cma_constraint.h"
#include "cma_rule.h"

#include "ppl_constraint.h"

class pplRule: public cmaRule
{

  public:

  pplRule(){}

 pplRule(const std::string& identifier, 
	 const C_Polyhedron& _zrule, 
	 const C_Polyhedron& _prule):zrule(_zrule), prule(_prule)
  {ruleIdentifier = identifier;
    assert(zrule.space_dimension()==2*cmaConstraint::numberOfSharedVariables);
    assert(prule.space_dimension()==2*cmaConstraint::numberOfLocalVariables);}

  cmaSetConstraintRef post(const cmaConstraintRef& from)const
    {
      cmaSetConstraintRef p;
      const pplConstraint* pplfrom=
	dynamic_cast<const pplConstraint*>(from.getPtr());
      assert(pplfrom);

      C_Polyhedron zimage=C_Polyhedron(pplfrom->zbox);
      //      cout << "domain " << endl;
      assert(zimage.space_dimension()==cmaConstraint::numberOfSharedVariables);
      zimage.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
      if(cmaConstraint::numberOfSharedVariables!=0){
	zimage.intersection_assign(zrule);
	if(zimage.is_empty())
	  return p;

	zimage.remove_space_dimensions(pplConstraint::sharedDomainSet);
	//	zimage.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
      }

      C_Polyhedron pimage =pplfrom->cpoly;
      assert(pimage.space_dimension()==cmaConstraint::numberOfLocalVariables);
      pimage.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
      pimage.intersection_assign(prule);
      if(!pimage.is_empty())
	{
	  pimage.remove_space_dimensions(pplConstraint::localDomainSet);
	  //	  pimage.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
	  p.insert(cmaConstraintRef(new pplConstraint(Z_Box(zimage),pimage)));
	}
      return p;
    };


  cmaSetConstraintRef pred(const cmaConstraintRef& from)const
    {
      cmaSetConstraintRef p;
      const pplConstraint* pplfrom=
	dynamic_cast<const pplConstraint*>(from.getPtr());
      assert(pplfrom);

      C_Polyhedron zimage =C_Polyhedron(pplfrom->zbox);
      assert(zimage.space_dimension()==cmaConstraint::numberOfSharedVariables);
      zimage.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);

      if(cmaConstraint::numberOfSharedVariables!=0){
	zimage.map_space_dimensions(pplConstraint::sharedReverse);
	zimage.intersection_assign(zrule);
	if(zimage.is_empty())
	  return p;
	zimage.remove_space_dimensions(pplConstraint::sharedCodomainSet);
	//zimage.add_space_dimensions_and_embed(cmaConstraint::numberOfSharedVariables);
      }

      C_Polyhedron pimage =pplfrom->cpoly;
      assert(pimage.space_dimension()==cmaConstraint::numberOfLocalVariables);
      pimage.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);

      pimage.map_space_dimensions(pplConstraint::localReverse);
      pimage.intersection_assign(prule);

      if(!pimage.is_empty())
	{
	  pimage.remove_space_dimensions(pplConstraint::localCodomainSet);
	  //pimage.add_space_dimensions_and_embed(cmaConstraint::numberOfLocalVariables);
	  p.insert(cmaConstraintRef(new pplConstraint(Z_Box(zimage),pimage)));
	}
      return p;
    };

  friend std::ostream& operator<< 
    (std::ostream& out, const cmaRuleRef& rule);


  virtual ~pplRule(){}

 protected:

  void printOn(std::ostream& o) const{
    o << "[" << ruleIdentifier << ":" ;
    Variable::set_output_function(pplConstraint::namingShared);
    o << zrule << ":" ;
    Variable::set_output_function(pplConstraint::namingLocal);
    o << prule << "]" ; 
    o << std::endl;
  };

 private:
  C_Polyhedron zrule;
  C_Polyhedron prule;
};


#endif
