/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file upward.h
 *
 * @author Rezine Ahmed
 */

#ifndef _CMA_UPWARD_H
#define _CMA_UPWARD_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>

#include "ref.h"
#include "minset.h"
#include "cma_order.h"
#include "cma_constraint.h"


class cmaUpward;

typedef Ref<cmaUpward> cmaUpwardRef;

class cmaUpward
{

 public:  
  virtual cmaUpwardRef 
    constrainWith(const cmaConstraintRef& frontier) const =0;

  cmaUpwardRef constrainWith(const cmaSetConstraintRef& set_cstr) const
  {
    cmaSetConstraintRef::const_iterator cstr=set_cstr.begin();
    assert(cstr!=set_cstr.end());
    cmaUpwardRef result=constrainWith(*cstr);
    ++cstr;
    for(; cstr!=set_cstr.end(); ++cstr)
      result = result->constrainWith(*cstr);
    return result;
  };


  virtual cmaSetConstraintRef close(const cmaConstraintRef& cstr) const=0;

  cmaSetConstraintRef close(const cmaSetConstraintRef& set_cstr) const
  {
    cmaSetConstraintRef result;
    for(cmaSetConstraintRef::const_iterator cstr=set_cstr.begin(); 
	cstr!=set_cstr.end(); ++cstr)
      {
	cmaSetConstraintRef lresult = close(*cstr);
	result.insert(lresult.begin(), lresult.end());
      }
    return result;
  };
  
  friend std::ostream& operator<< 
    (std::ostream& out, const cmaUpwardRef& up);

  virtual ~cmaUpward(){}

 protected:
  virtual void printOn(std::ostream& o) const = 0;
};

inline std::ostream& operator<< 
(std::ostream& o, const cmaUpwardRef& rel)
{
  rel->printOn(o);
  return o;
};



#endif
