/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file cma_widening.h
 *
 * @author Rezine Ahmed
 */

#ifndef _CMA_WIDENING_H
#define _CMA_WIDENING_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>

#include "ref.h"
#include "minset.h"
#include "cma_order.h" 
#include "cma_constraint.h"

class cmaWidening;

typedef Ref<cmaWidening> cmaWideningRef;

class cmaWidening
{

  public:

  virtual bool entails(const cmaWideningRef& other)const=0;

  virtual cmaWideningRef 
    intersect(const cmaWideningRef& other)const=0;

  MinSet<cmaWideningRef, entailmentOrder> 
    intersect(const MinSet<cmaWideningRef, entailmentOrder>& set_cstr) const{
    MinSet<cmaWideningRef, entailmentOrder> result;
    for(MinSet<cmaWideningRef, entailmentOrder>::const_iterator cstr=set_cstr.begin(); cstr!=set_cstr.end(); ++cstr)
      {
	cmaWideningRef candidate=intersect(*cstr);
	if(!candidate->isEmpty())
	  result.insert(candidate);
      }
    return result;
  };

  //virtual MinSet<cmaWideningRef, entailmentOrder>
  //  negate() const=0;

  virtual bool isEmpty()const=0;

  friend std::ostream& operator<< 
    (std::ostream& out, const cmaWideningRef& cstr);


  virtual ~cmaWidening(){}

  unsigned wideningIdentifier;

  static unsigned wideningCounter;

  static unsigned numberOfVariables;


 protected:

  virtual void printOn(std::ostream& o) const = 0;
};

inline std::ostream& operator<< 
(std::ostream& o, const cmaWideningRef& cstr)
{
  cstr->printOn(o);
  return o;
}



#endif
