/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/

/**@file cma_trace.h
 * Whatever is needed for tracing
 *
 *@author Ahmed Rezine
 */

#ifndef _CMA_TRACE_H
#define _CMA_TRACE_H

#include <iostream>
#include <map>

#include "cma_constraint.h"
#include "cma_rule.h"


class childRuleParent
{
 public:

  childRuleParent(){}

 childRuleParent(const cmaConstraintRef& _child, const cmaRuleRef& _rule, const cmaConstraintRef& _parent)
   :child(_child),rule(_rule),parent(_parent){}

  friend std::ostream& operator<< (std::ostream& out, const childRuleParent& crp);

  friend class cmaTrace;

 private:
  cmaConstraintRef child, parent;
  cmaRuleRef rule;
};


class cmaTrace : public std::map<unsigned, childRuleParent>
{
 public:

  cmaTrace(){}

  bool add(const cmaConstraintRef& child, const cmaRuleRef& rule, const cmaConstraintRef& parent){
    if(find(child->constraintIdentifier)!=end())
      return false;
    operator[](child->constraintIdentifier)=childRuleParent(child,rule,parent);
    return true;
  }

  cmaConstraintRef parentOf(const cmaConstraintRef& child) const{
    std::map<unsigned, childRuleParent>::const_iterator it=find(child->constraintIdentifier);
    assert(it!=end());
    assert(it->second.parent);
    return it->second.parent;
  }
  cmaRuleRef generatingRuleOf(const cmaConstraintRef& child) const{
    //    cout << "child " << child << endl;
    std::map<unsigned, childRuleParent>::const_iterator it=find(child->constraintIdentifier);
    assert(it!=end());
    assert(it->second.rule);
    return it->second.rule;
  }
};

inline std::ostream& operator<<
(std::ostream& o, const childRuleParent& crp)
{
  o<< crp.child << std::endl 
   << "via" << std::endl 
   << crp.rule << std::endl 
   << "gives" << std::endl 
   << crp.parent << std::endl ;

  return o;
};

#endif

