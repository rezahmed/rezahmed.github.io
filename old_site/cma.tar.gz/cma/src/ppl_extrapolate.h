/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file extrapolate.h
 *
 * @author Rezine Ahmed
 */

#ifndef _PPL_EXTRAPOLATE_H
#define _PPL_EXTRAPOLATE_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <ppl.hh>

#include "ref.h"
#include "minset.h"
#include "cma_order.h"
#include "cma_constraint.h"
#include "ppl_constraint.h"
#include "partial_function.h" 





class pplH76Extrapolate : public cmaExtrapolate
{

 public:  
 
 pplH76Extrapolate(){}
  

 void initializeCollapsedState(const cmaSetConstraintRef& inits)
 {
   CollapsedState=pplConstraint(EMPTY,EMPTY);
   cmaSetConstraintRef::const_iterator cstrs=inits.begin();  
   assert(cstrs!=inits.end());
   for(; cstrs!=inits.end();++cstrs){
     const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(cstrs->getPtr());
     assert(pplAdd);
     CollapsedState=widen(CollapsedState,*pplAdd);
   }
 }

 cmaConstraintRef withIncrementCollapse(const cmaConstraintRef& add) 
 {
   const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(add.getPtr());
   assert(pplAdd);
   CollapsedState=widen(CollapsedState,*pplAdd);
   return cmaConstraintRef(new pplConstraint(CollapsedState));
 };

 /* withIncrement(add): wrapper for frontier widening wrt (add->zbox, add->cpoly).
  * it uses the private withIcrement, and returns a copy of the extrapolateState, 
  * that is, the previous frontiers together with the new widened one.
  */
 cmaSetConstraintRef withIncrement(const cmaConstraintRef& add) 
 {
   cmaSetConstraintRef result;
   const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(add.getPtr());
   assert(pplAdd);
   withIncrement(pplAdd->zbox,pplAdd->cpoly);
   list<ZC>::const_iterator cit=extrapolateState.begin();
   for(; cit!=extrapolateState.end(); ++cit)
     result.insert(cmaConstraintRef(new pplConstraint(cit->first, cit->second)));
   return result;
 };
  
/*  withIncrement(adds): wrapper for frontier widening wrt each (add->zbox, add->cpoly) in adds.
  * Like withIncrement(add), it returns a copy of the extrapolateState
  */
  cmaSetConstraintRef withIncrement(const cmaSetConstraintRef& adds) 
  {
    cmaSetConstraintRef result;

    cmaSetConstraintRef::const_iterator cstr=adds.begin();
    assert(cstr!=adds.end());
    for(; cstr!=adds.end();++cstr)
      {
	const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(cstr->getPtr());
	assert(pplAdd);
	withIncrement(pplAdd->zbox, pplAdd->cpoly);
      }
    
    list<ZC>::const_iterator cit=extrapolateState.begin();
    for(; cit!=extrapolateState.end(); ++cit)
      result.insert(cmaConstraintRef(new pplConstraint(cit->first, cit->second)));
    
    return result;
  };

  void clear()
  { extrapolateState.clear(); };

 protected:
  void printOn(std::ostream& o) const {
    o << "H79 widening on closed polyhedra " << std::endl;
  };

 private:

  pplConstraint CollapsedState;

  /* The extrapolateState is a list used to store the widened frontier */
  list<ZC>  extrapolateState;

  /* widens the cAdd part for intersecting zAdd, keep the rest unwidened.
   */
  void withIncrement(const Z_Box& zAdd, const C_Polyhedron& cAdd) 
  {
    assert(zAdd.space_dimension()==pplConstraint::numberOfSharedVariables);
    assert(cAdd.space_dimension()==pplConstraint::numberOfLocalVariables);

    list<ZC> result; /* result is to contain the new value of extrapolateState */

    if(extrapolateState.empty()){
      extrapolateState.push_back(ZC(zAdd,cAdd));     /* first frontier: nothing to widen */
    }
    else{
      /* First negate the box part. */
      list<Z_Box> oldRemaining, newRemaining;
      oldRemaining.push_back(zAdd);
      list<Z_Box> partitionWithZAdd=negate(zAdd);

      list<ZC>::const_iterator eStateit=extrapolateState.begin();
      for(;eStateit!=extrapolateState.end(); ++eStateit)
	{// for each previous frontier eStateit:
	  

	  // if the box of an eStateit intersects zAdd, then widen the cpoly and store in result
	  Z_Box old=eStateit->first;
	  old.intersection_assign(zAdd);
	  if(!old.is_empty()){
	      C_Polyhedron  newPoly(cAdd);
	      newPoly.upper_bound_assign(eStateit->second);
	      newPoly.widening_assign(eStateit->second);
	      // add the intersection and the widened cpoly to result
	      result.push_back(ZC(old,newPoly));
	    }

	  // if the box of an eStateit intersects a complement of zAdd, then store in result 
	  //  restriction of eStateit
	  // on the box while keeping the same cpoly. The widening takes place only on the cpoly, and is only
	  // applied on cpoly associated with intersection boxes.
	  list<Z_Box>::const_iterator pwzait=partitionWithZAdd.begin();
	  for(; pwzait!=partitionWithZAdd.end();++pwzait)
	    {
	      Z_Box cz=*pwzait;
	      cz.intersection_assign(eStateit->first);
	      if(!cz.is_empty())
		{
		  result.push_back(ZC(cz, eStateit->second));
		}
	    }

	  //the part of zAdd that did not intersect any eStateit needs to be added without widening.
	  //this is done by cutting zAdd wrt the negation of eStateit. After having looked at all
	  //eStatie, the small pieces are added to result with cpoly.
	  for(list<Z_Box>::const_iterator rit=oldRemaining.begin(); rit!=oldRemaining.end(); ++rit)
	    {
	      list<Z_Box> oldNegation=negate(eStateit->first);
	      for(list<Z_Box>::const_iterator negation=oldNegation.begin();negation!=oldNegation.end();++negation)
		{
		  Z_Box nremaining=*rit;
		  nremaining.intersection_assign(*negation);
		  if(!nremaining.is_empty())
		    newRemaining.push_back(nremaining);
		}
	    }
	  oldRemaining=newRemaining;
	  newRemaining.clear();
	}
      //Adding, without widening, the parts of zAdd that do not intersect the extrapolateState
      for(list<Z_Box>::const_iterator rit=oldRemaining.begin(); rit!=oldRemaining.end(); ++rit)
	{
	  assert(!rit->is_empty());
	  result.push_back(ZC(*rit, cAdd));
	}
      extrapolateState=result;
    }
    
  };


/*    given a box zAdd, 
 *    returns a list of boxes within the largest box 
 *    such that:
 *    the list together with zAdd form a partition of the largest box. 
 *    the elements of the list are obtained by negating one constraint
 *    at a time in the definition of zAdd
 */
  list<Z_Box> negate(const Z_Box& zAdd) const
    {
      list<Z_Box> partitionWithZAdd;
      Variable::set_output_function(pplConstraint::namingShared);    
      if(pplConstraint::numberOfSharedVariables!=0)
	{
	  Constraint_System zcs = zAdd.minimized_constraints();
	  Z_Box zprevious=pplConstraint::largestBox;
	  zprevious.remove_space_dimensions(pplConstraint::sharedCodomainSet);
	  Constraint_System zcurrent=zprevious.minimized_constraints();
	  for(Constraint_System::const_iterator izcs=zcs.begin(), zcs_end=zcs.end(); izcs!=zcs_end;++izcs){
	    assert(! izcs->is_strict_inequality());
	    Linear_Expression e;
	    for(dimension_type dim=izcs->space_dimension(); dim-->0; )
	      e+=izcs->coefficient(Variable(dim))*Variable(dim);
	    e+=izcs->inhomogeneous_term();
	    if(izcs->is_equality()){
	      Constraint_System zcsi; zcsi.insert(e>=1);
	      Z_Box zcandidate(zcsi);
	      zcandidate.intersection_assign(zprevious);
	      if(!zcandidate.is_empty())
		{
		  partitionWithZAdd.push_back(zcandidate);
		}
	    }
	    Constraint_System zcsi; zcsi.insert(e<=-1);
	    Z_Box zcandidate(zcsi);
	    zcandidate.intersection_assign(zprevious);
	    if(!zcandidate.is_empty())
	      {
		partitionWithZAdd.push_back(zcandidate);
	      }
	    zcurrent.insert(*izcs);
	    zprevious=Z_Box(zcurrent);
	  }
	}
      return partitionWithZAdd;
    }

  /*
    joins the zbox and widens the cpoly
   */
  pplConstraint widen(const pplConstraint& prev, const pplConstraint& add)
  {
    pplConstraint result=prev.join(add);
    (result.cpoly).widening_assign(add.cpoly);
    return result;
  }


  
};














class pplH76BdsExtrapolate : public cmaExtrapolate
{

  typedef pair<Z_Box, BD_Shape<mpq_class> > ZBD;

 public:  
 
 pplH76BdsExtrapolate(){}
  
 cmaSetConstraintRef withIncrement(const cmaConstraintRef& add) 
 {
   cmaSetConstraintRef result;
   const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(add.getPtr());
   assert(pplAdd);
   withIncrement(pplAdd->zbox,pplAdd->cpoly);
   list<ZBD>::const_iterator cit=extrapolateState.begin();
   for(; cit!=extrapolateState.end(); ++cit)
     result.insert(cmaConstraintRef(new pplConstraint(cit->first, C_Polyhedron(cit->second))));
   return result;
 };
  
  cmaSetConstraintRef withIncrement(const cmaSetConstraintRef& adds) 
  {
    cmaSetConstraintRef result;

    cmaSetConstraintRef::const_iterator cstr=adds.begin();
    assert(cstr!=adds.end());
    for(; cstr!=adds.end();++cstr)
      {
	const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(cstr->getPtr());
	assert(pplAdd);
	withIncrement(pplAdd->zbox, pplAdd->cpoly);
      }
    
    list<ZBD>::const_iterator cit=extrapolateState.begin();
    for(; cit!=extrapolateState.end(); ++cit)
      result.insert(cmaConstraintRef(new pplConstraint(cit->first, C_Polyhedron(cit->second))));
    
    return result;
  };

  void clear()
  { extrapolateState.clear(); };

 protected:
  void printOn(std::ostream& o) const {
        o << "H79 widening on BD shapes " << std::endl;
  };

 private:
  list<ZBD>  extrapolateState;

  void withIncrement(const Z_Box& zAdd, const C_Polyhedron& cAdd) 
  {

    assert(zAdd.space_dimension()==pplConstraint::numberOfSharedVariables);
    assert(cAdd.space_dimension()==pplConstraint::numberOfLocalVariables);

    list<ZBD> result;

    if(extrapolateState.empty()){
      extrapolateState.push_back(ZBD(zAdd,BD_Shape<mpq_class>(cAdd)));
    }
    else{
      list<Z_Box> oldRemaining, newRemaining;
      oldRemaining.push_back(zAdd);

      list<Z_Box> partitionWithZAdd=negate(zAdd);

      list<ZBD>::const_iterator cit=extrapolateState.begin();
      for(;cit!=extrapolateState.end(); ++cit)
	{
	  Z_Box old=cit->first;
	  old.intersection_assign(zAdd);
	  //zAdd and cit:
	  if(!old.is_empty())
	    {
	      BD_Shape<mpq_class> newPoly(cAdd);
	      newPoly.upper_bound_assign(cit->second);
	      newPoly.widening_assign(cit->second);
	      result.push_back(ZBD(old,newPoly));
	    }

	  //cit and not zAdd
	  list<Z_Box>::const_iterator pwzait=partitionWithZAdd.begin();
	  for(; pwzait!=partitionWithZAdd.end();++pwzait)
	    {
	      Z_Box cz=*pwzait;
	      cz.intersection_assign(cit->first);
	      if(!cz.is_empty())
		{
		  result.push_back(ZBD(cz, cit->second));
		}
	    }
	  //zAdd and not cit
	  for(list<Z_Box>::const_iterator rit=oldRemaining.begin(); rit!=oldRemaining.end(); ++rit)
	    {
	      list<Z_Box> oldNegation=negate(cit->first);
	      for(list<Z_Box>::const_iterator negation=oldNegation.begin();negation!=oldNegation.end();++negation)
		{
		  Z_Box nremaining=*rit;
		  nremaining.intersection_assign(*negation);
		  if(!nremaining.is_empty())
		    newRemaining.push_back(nremaining);
		}
	    }
	  oldRemaining=newRemaining;
	  newRemaining.clear();
	}
      for(list<Z_Box>::const_iterator rit=oldRemaining.begin(); rit!=oldRemaining.end(); ++rit)
	{
	  assert(!rit->is_empty());
	  result.push_back(ZBD(*rit, BD_Shape<mpq_class>(cAdd)));
	}
      extrapolateState=result;
    }
    
  };


/*    given a box zAdd, 
 *    returns a list of boxes within the largest box 
 *    such that:
 *    the list together with zAdd form a partition of the largest box. 
 *    the elements of the list are obtained by negating one constraint
 *    at a time in the definition of zAdd
 */

  list<Z_Box> negate(const Z_Box& zAdd) const
    {
      list<Z_Box> partitionWithZAdd;
      Variable::set_output_function(pplConstraint::namingShared);    
      if(pplConstraint::numberOfSharedVariables!=0)
	{
	  Constraint_System zcs = zAdd.minimized_constraints();
	  Z_Box zprevious=pplConstraint::largestBox;
	  zprevious.remove_space_dimensions(pplConstraint::sharedCodomainSet);
	  Constraint_System zcurrent=zprevious.minimized_constraints();
	  for(Constraint_System::const_iterator izcs=zcs.begin(), zcs_end=zcs.end(); izcs!=zcs_end;++izcs){
	    assert(! izcs->is_strict_inequality());
	    Linear_Expression e;
	    for(dimension_type dim=izcs->space_dimension(); dim-->0; )
	      e+=izcs->coefficient(Variable(dim))*Variable(dim);
	    e+=izcs->inhomogeneous_term();
	    if(izcs->is_equality()){
	      Constraint_System zcsi; zcsi.insert(e>=1);
	      Z_Box zcandidate(zcsi);
	      zcandidate.intersection_assign(zprevious);
	      if(!zcandidate.is_empty())
		{
		  partitionWithZAdd.push_back(zcandidate);
		}
	    }
	    Constraint_System zcsi; zcsi.insert(e<=-1);
	    Z_Box zcandidate(zcsi);
	    zcandidate.intersection_assign(zprevious);
	    if(!zcandidate.is_empty())
	      {
		partitionWithZAdd.push_back(zcandidate);
	      }
	    zcurrent.insert(*izcs);
	    zprevious=Z_Box(zcurrent);
	  }
	}
      return partitionWithZAdd;
    }

  
};




















/*


class pplH76BdsExtrapolate : public cmaExtrapolate
{

 public:  
 
 pplH76BdsExtrapolate():current(BD_Shape<mpq_class>(2*cmaConstraint::numberOfVariables,EMPTY)){}
  
  cmaConstraintRef withIncrement(const cmaConstraintRef& add) 
  {
    const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(add.getPtr());
    assert(pplAdd);
    BD_Shape<mpq_class> pplBdsAdd=BD_Shape<mpq_class>(pplAdd->cpoly);
    return cmaConstraintRef(new pplConstraint(C_Polyhedron(withIncrement(pplBdsAdd))));
  };
  
  cmaConstraintRef withIncrement(const cmaSetConstraintRef& adds) 
  {
    cmaSetConstraintRef::const_iterator cstr=adds.begin();
    assert(cstr!=adds.end());
    for(; cstr!=adds.end();++cstr)
      {
	const pplConstraint* pplAdd= dynamic_cast<const pplConstraint*>(cstr->getPtr());
	assert(pplAdd);
	BD_Shape<mpq_class> pplBdsAdd=BD_Shape<mpq_class>(pplAdd->cpoly);
	withIncrement(pplBdsAdd);
      } 
      
    return cmaConstraintRef(new pplConstraint(C_Polyhedron(current)));
  };

  void clear(){
    current = BD_Shape<mpq_class>(2*cmaConstraint::numberOfVariables,EMPTY);
  };

 protected:
  void printOn(std::ostream& o) const {
    o << "H79 widening on BD shapes " << std::endl;
  };

 private:
  BD_Shape<mpq_class> current;

  BD_Shape<mpq_class> withIncrement(const BD_Shape<mpq_class>& add) 
  {
    BD_Shape<mpq_class> old=current;  
    current=add;
    current.upper_bound_assign(old);
    current.widening_assign(old);
    return current;
  };

};
*/

#endif
