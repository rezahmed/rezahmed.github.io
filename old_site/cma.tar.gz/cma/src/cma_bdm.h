#ifndef _BDM_H
#define _BDM_H

#include <assert.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <ext/hash_map>

#include "cma_interpolate.h"

using namespace std;

#define MAX_NUM_VARS 30
typedef enum {pre,pos} phi_type;

class cmaBDMInterpolation
{
public:
cmaBDMInterpolation(const string& _pre, const string& _pos, const int& _constant)
: pre(_pre), pos(_pos), full(_pre+", "+_pos), 
	pinf(10000000)//numeric_limits<int>::infinity()),
{


	list<string> vars;
	for(int j,i=0;i<full.length();i++){
		if(isalpha(full[i])){
			for(j=i+1;
			j<full.length()&&(isalnum(full[j])||(full[j]=='_'));
			j++);
			vars.push_back(full.substr(i,j-i));
			i = j;
		}		
	}
	vars.push_back("0");
	vars.unique();
	int n = vars.size();
	assert(n<=MAX_NUM_VARS);
	list<string>::iterator it = vars.begin();
	while(it!=vars.end()){
		n--;	
		name[n] = *it;
		id[*it] = n;
		Variable v(n);
		pplConstraint::nameOfLocalDimension[v.id()]=*it;
		pplConstraint::dimensionOfLocalName[*it]=v.id();
		it++;
	}

/* 	for(int i=0;i<get_num_vars();i++) */
/* 	{ */
/* 		cout<<endl; */
/* 		cout<<"("<<i<<","<<name[i]<<","<<id[name[i]]<<") "; */
/* 	} */
/* 	cout<<endl<<endl; */



	bdm_from_str(pre,phi_plus);

	// phi_plus: "lock - 2 = sread, swrite + 1 <= lock"
/* 	for(int i=0;i<get_num_vars();i++) */
/* 	  for(int j=0;j<get_num_vars();j++) */
/* 	    if(i!=j) phi_plus[i][j] = pinf;  */
/* 	phi_plus[3][2]=2; */
/* 	phi_plus[2][3]=-2; */
/* 	phi_plus[1][3]=-1; */
	
/* 	dump_bdm("phi+:",phi_plus); */
	assert(normalize_assign(phi_plus));
/* 	dump_bdm("phi+ normalized:",phi_plus); */
	
	

	bdm_from_str(pos,phi_minus);
	// phi_minus: "sread + 2 <= swrite" 
/* 	for(int i=0;i<get_num_vars();i++) */
/* 	  for(int j=0;j<get_num_vars();j++) */
/* 	    if(i!=j) phi_minus[i][j] = pinf; 	 */
/* 	phi_minus[2][1]=-2; */
	
/* 	dump_bdm("phi-:",phi_minus); */
	assert(normalize_assign(phi_minus));
/* 	dump_bdm("phi- normalized:",phi_minus); */

	for(int i=0;i<get_num_vars();i++)
	  for(int j=0;j<get_num_vars();j++)
	    if(i!=j && phi_plus[i][j] != pinf & phi_minus[j][i] != pinf)
	      {
		if(phi_plus[i][j] <= _constant  && _constant+phi_minus[j][i] < 0)
		  {
		    ostringstream istream;
		    istream << name[i] << " - " << name[j] << " <= " 
			    << _constant << endl;
		    interpolants.push_back(istream.str());
		  }
		if(_constant!=0 && phi_plus[i][j] <= -_constant  && -_constant+phi_minus[j][i] < 0)
		  {
		    ostringstream istream;
		    istream << name[i] << " - " << name[j] << " <= " 
			    << -_constant << endl;
		    interpolants.push_back(istream.str());
		  }
	      }

	interpolants_iterator=interpolants.begin();

/* 	transpose_assign(phi_minus); */
/* 	//	dump_bdm("phi- transpose:",phi_minus); */

/* 	add_assign_second(phi_plus,phi_minus); */

/* 	dump_bdm("phi+ + transpose phi- :", phi_minus); */

}
~cmaBDMInterpolation(){};

int get_num_vars(){ return id.size(); }

string get_var(int id){ assert(id<get_num_vars()); return name[id]; }


string get(){return *interpolants_iterator; } // get current interpolant

void next(){++interpolants_iterator; } // move to next interpolant

 bool end() { return interpolants_iterator==interpolants.end(); } // is there any interpolant?

protected:

const int pinf;

string pre, pos, full;

int phi_plus[MAX_NUM_VARS][MAX_NUM_VARS]; // BDM for phi_minus
int phi_minus[MAX_NUM_VARS][MAX_NUM_VARS]; // BDM for phi_plus

map<string,int> id;   // get id from name
string name[MAX_NUM_VARS]; // get name from id

 list<string> interpolants;

void bdm_from_str(const string& str, int bdm[MAX_NUM_VARS][MAX_NUM_VARS])
{
	for(int i=0;i<get_num_vars();i++)
		for(int j=0;j<get_num_vars();j++)
			if(i!=j) bdm[i][j] = pinf; 

	for(int i=0,j=0;j<=str.length();j++)
	{
		if(i<j && j==str.length())
			mark(str.substr(i),bdm);
		else
		if(str[j]==',')
		{
			mark(str.substr(i,j-i),bdm);
			i = j + 1;
		}
	}
}

void dump_bdm(const char* msg, int bdm[MAX_NUM_VARS][MAX_NUM_VARS])
{
	ostringstream sout;
	sout<<"echo "<<msg<<"; echo -e \"\n\t";

	for(int i=0;i<get_num_vars();i++)
	{
		if(!i){ 
			sout<<"\\ ";
			for(int k=0;k<get_num_vars();k++) 
				sout<<"\t"<<name[k];
		}
		sout<<"\\n"<<name[i]<<"\t";
		for(int j=0;j<get_num_vars();j++)
		{
			if(i==j) sout<<" *"; else
			if(bdm[i][j]==pinf) sout<<"\tinf"; else
			sout<<"\t"<<bdm[i][j];
		}
	}
	sout<<"\" | column -t; echo;";
	system(sout.str().c_str());
}

bool mark(const string& cnst_str, int bdm[MAX_NUM_VARS][MAX_NUM_VARS])
{
	Constraint* cnst = cmaInterpolate::cnst_from_str(cnst_str);
	//Linear_Expression e;
	ostringstream m,n;
	string a,b,c;
        for (dimension_type i = cnst->space_dimension(); i-->0;)
	{
		m.str("");n.str("");
		m<<cnst->coefficient(Variable(i));
		n<<Variable(i);
		int sign = atoi(m.str().c_str());
		if(sign<0) 
		{
			assert(b.empty());
			//			b = n.str();
			b=pplConstraint::nameOfLocalDimension.find(i)->second;
		}else
		if(sign>0){
			assert(a.empty());
			//			a = n.str();
			a=pplConstraint::nameOfLocalDimension.find(i)->second;
		}
		if(!a.empty()&&!b.empty()) 
			break;
	}
	if(a.empty()) a = "0";
	if(b.empty()) b = "0";
	m.str("");
	m<<(0-cnst->inhomogeneous_term());
	c = m.str();

	int x = id[a];
        int y = id[b];
        int k = 0-atoi(c.c_str());

	// a - b <=> c
//	cout<<"CNST: "<<*cnst<<endl;
//	cout<<"CSTR: "<<cnst_str<<endl;
//	cout<<"TERM: "<<b<<" - "<<a<<" <= "<<k<<endl;

/* 	if (cnst->is_equality()) */
/* 	{ */
/* //		cout<<"TERM: "<<a<<" - "<<b<<" <= "<<k<<endl; */
/* 	} */

	bdm[y][x] = k;
/* 	cout<<"Add: "<<name[y]<<" - "<<name[x]<<" <= "<<k<<endl; */
	if (cnst->is_equality())
	{
/* 		cout<<"Add: "<<name[x]<<" - "<<name[y]<<" <= "<<-k<<endl; */
		bdm[x][y] = -k;
	}
/* 	cout<<endl; */
	delete cnst;
	return true;
};

 bool normalize_assign(int bdm[MAX_NUM_VARS][MAX_NUM_VARS]){
   for(int i=0;i<get_num_vars();i++)
     for(int j=0;j<get_num_vars();j++)
       if(j!=i)
	 {
	   for(int k=0;k<get_num_vars();k++)
	     if(k!=i && k!=j)
	       {
		 if(bdm[i][k]!=pinf && bdm[k][j]!=pinf)
		   {
		     if(bdm[i][k]+bdm[k][j]<bdm[i][j])
		       bdm[i][j]=bdm[i][k]+bdm[k][j];
		   }
	       }
	   if(bdm[i][j] + bdm[j][i] < 0)
	     return false;
	 }
   return true;
 }

 void transpose_assign(int bdm[MAX_NUM_VARS][MAX_NUM_VARS])
 {
   int tmp;
   for(int i=0;i<get_num_vars();i++)
     for(int j=0;j<i;j++)
       {
	 tmp = bdm[i][j];
	 bdm[i][j]=bdm[j][i];
	 bdm[j][i]=tmp;
       }
 }

 void add_assign_second(int first[MAX_NUM_VARS][MAX_NUM_VARS],int second[MAX_NUM_VARS][MAX_NUM_VARS])
 {
   for(int i=0;i<get_num_vars();i++)
     for(int j=0;j<get_num_vars();j++)
       {
	 if(i!=j)
	   {
	     if(first[i][j]==pinf || second[i][j]==pinf)
	       second[i][j]=pinf;
	     else
	       second[i][j]+=first[i][j];
	   }
       }
 }

private:
list<string>::const_iterator interpolants_iterator;

};
#endif
