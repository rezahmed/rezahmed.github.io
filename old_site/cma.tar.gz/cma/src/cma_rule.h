/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file cma_rule.h
 * Header for an abstract rule denoting a possibly infinite set of configurations of the system
 *
 * @author Rezine Ahmed
 */

#ifndef _CMA_RULE_H
#define _CMA_RULE_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <string>

#include "ref.h"
#include "minset.h"
#include "cma_order.h" 
#include "cma_constraint.h"

class cmaRule;

typedef Ref<cmaRule> cmaRuleRef;

class cmaRule
{

  public:

  virtual cmaSetConstraintRef post(const cmaConstraintRef& from)const=0;

  virtual cmaSetConstraintRef pred(const cmaConstraintRef& from)const=0;


  cmaSetConstraintRef post(const cmaSetConstraintRef& set_cstr) const
  {
    cmaSetConstraintRef result;
    for(cmaSetConstraintRef::const_iterator cstr=set_cstr.begin(); cstr!=set_cstr.end(); ++cstr)
      {
	cmaSetConstraintRef lresult = post(*cstr);
	result.insert(lresult.begin(), lresult.end());
      }
    return result;
  };


  cmaSetConstraintRef pred(const cmaSetConstraintRef& set_cstr) const
  {
    cmaSetConstraintRef result;
    for(cmaSetConstraintRef::const_iterator cstr=set_cstr.begin(); cstr!=set_cstr.end(); ++cstr)
      {
	cmaSetConstraintRef lresult = pred(*cstr);
	result.insert(lresult.begin(), lresult.end());
      }
    return result;
  };


  friend std::ostream& operator<< 
    (std::ostream& out, const cmaRuleRef& rule);

  std::string getRuleIdentifier()const{return ruleIdentifier;}

  virtual ~cmaRule(){}

 protected:

  virtual void printOn(std::ostream& o) const = 0;
  std::string ruleIdentifier;
};


class cmaRules;
typedef Ref<cmaRules> cmaRulesRef;

class cmaRules : public std::list<cmaRuleRef>
{

  friend std::ostream& operator<< 
    (std::ostream& out, const cmaRulesRef& rules);
};

inline std::ostream& operator<< 
(std::ostream& o, const cmaRuleRef& rule)
{
  rule->printOn(o);
  return o;
}

inline std::ostream& operator<< 
(std::ostream& o, const cmaRulesRef& rules)
{
  o << "rules: " 
    << std::endl;
  for(std::list<cmaRuleRef>::const_iterator it=rules->begin(); 
      it!=rules->end(); ++it)
      o << "   " << *it << std::endl;

  return o;
}


#endif
