/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/

#include <cstdlib>

#include "cma_bdm.h"
#include "ppl_constraint.h"

map<string, dimension_type> pplConstraint::dimensionOfLocalName;
map<dimension_type, string> pplConstraint::nameOfLocalDimension;


int main (int argc, char ** argv)
{
  if(argc != 4)
    {
      cout << "use: ./test_dbm_interpolant \"phi+\" \"phi-\" k, for example: " 
	   << endl 
	   << "./test_dbm_interpolant \"lock - 2 = sread, swrite + 1 <= lock\" \"sread + 1 <= swrite\" 0 " << endl;
      exit(1);
    }
  string phi_plus_str = string(argv[1]);
  string phi_minus_str = string(argv[2]);
  int constant = strtol(argv[3],0,0);
  cmaBDMInterpolation bdmi(phi_plus_str, phi_minus_str,constant);
  while(!bdmi.end())
    {
      cout << endl << bdmi.get() << endl;
      bdmi.next();
    }
  cout <<  "end of interpolants of the form \"x-y <= [-]" << constant << "\""<< endl << endl;
   return 0;
}
