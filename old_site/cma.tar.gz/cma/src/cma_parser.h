/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOKEN_UNORDERED = 258,
     TOKEN_ORDERED = 259,
     TOKEN_LOCAL = 260,
     TOKEN_SHARED = 261,
     TOKEN_STATES = 262,
     TOKEN_INITIAL = 263,
     TOKEN_BAD = 264,
     TOKEN_PRECEQ = 265,
     TOKEN_RULES = 266,
     TOKEN_LEFT_BRACE = 267,
     TOKEN_RIGHT_BRACE = 268,
     TOKEN_LEFT_BRACKET = 269,
     TOKEN_RIGHT_BRACKET = 270,
     TOKEN_COMMA = 271,
     TOKEN_COLON = 272,
     TOKEN_LESS = 273,
     TOKEN_LARGER = 274,
     TOKEN_EQUAL = 275,
     TOKEN_MINUS = 276,
     TOKEN_PLUS = 277,
     TOKEN_TIMES = 278,
     TOKEN_NEXT = 279,
     TOKEN_H76_POLYHEDRA = 280,
     TOKEN_H76_BD_SHAPES = 281,
     TOKEN_COMMANDS = 282,
     TOKEN_CMD_EXIT = 283,
     TOKEN_CMD_PRINT = 284,
     TOKEN_CMD_CHECK_REACHABILITY = 285,
     TOKEN_CMD_PREDECESSOR = 286,
     TOKEN_CMD_UPWARD_CLOSURE = 287,
     TOKEN_CMD_POST = 288,
     TOKEN_CMD_WITH = 289,
     TOKEN_CMD_EXTRAPOLATE = 290,
     TOKEN_CMD_FIND_BOUNDS = 291,
     ID = 292,
     INT = 293
   };
#endif
/* Tokens.  */
#define TOKEN_UNORDERED 258
#define TOKEN_ORDERED 259
#define TOKEN_LOCAL 260
#define TOKEN_SHARED 261
#define TOKEN_STATES 262
#define TOKEN_INITIAL 263
#define TOKEN_BAD 264
#define TOKEN_PRECEQ 265
#define TOKEN_RULES 266
#define TOKEN_LEFT_BRACE 267
#define TOKEN_RIGHT_BRACE 268
#define TOKEN_LEFT_BRACKET 269
#define TOKEN_RIGHT_BRACKET 270
#define TOKEN_COMMA 271
#define TOKEN_COLON 272
#define TOKEN_LESS 273
#define TOKEN_LARGER 274
#define TOKEN_EQUAL 275
#define TOKEN_MINUS 276
#define TOKEN_PLUS 277
#define TOKEN_TIMES 278
#define TOKEN_NEXT 279
#define TOKEN_H76_POLYHEDRA 280
#define TOKEN_H76_BD_SHAPES 281
#define TOKEN_COMMANDS 282
#define TOKEN_CMD_EXIT 283
#define TOKEN_CMD_PRINT 284
#define TOKEN_CMD_CHECK_REACHABILITY 285
#define TOKEN_CMD_PREDECESSOR 286
#define TOKEN_CMD_UPWARD_CLOSURE 287
#define TOKEN_CMD_POST 288
#define TOKEN_CMD_WITH 289
#define TOKEN_CMD_EXTRAPOLATE 290
#define TOKEN_CMD_FIND_BOUNDS 291
#define ID 292
#define INT 293




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 91 "cma_parser.yy"
{
	int n;
	string* str;
	cmaConstraint* constraint;
	list<cmaConstraintRef>* constraints;
	cmaExtrapolate* extrapolation;
	cmaRule* rule;
	cmaRules* rules;
	cmaUpward* preceq;
	Constraint_System* constraint_system;
	Constraint* atom;
	Linear_Expression* linear_expression;
	dimension_type* variable;
	map<string,unsigned>* values;
	}
/* Line 1529 of yacc.c.  */
#line 141 "cma_parser.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

