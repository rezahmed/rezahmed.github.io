/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/**@file algorithm.h
 * Definition of the reachability algorithm.
 *
 *@author Ahmed Rezine
 */
#ifndef _ALGORITHM_H
#define _ALGORITHM_H

#include <assert.h>
#include <iostream>
#include <stdlib.h>


#include "ref.h"
#include "cma_order.h"
#include "minset.h"
#include "cma_constraint.h"
#include "cma_upward.h"
#include "cma_rule.h"
#include "cma_trace.h" 
#include "cma_sequence.h"
#include "cma_extrapolate.h"


typedef enum {not_reachable, reachable} result;

using namespace std;

class SymbolicFixpoint
{
 public:
 SymbolicFixpoint(const cmaSetConstraintRef& _init, 
		  const cmaRules _rules, 
		  const cmaSetConstraintRef& _bad,
		  const cmaExtrapolateRef& _extrapolate,
		  const cmaUpwardRef& _preceq) 
   : init(_init), rules(_rules), bad(_bad), extrapolate(_extrapolate), preceq0(_preceq)
  {

    cmaSetConstraintRef::iterator i=init.begin();
    for(;i!=init.end();++i)
      (*i)->constraintIdentifier=++cmaConstraint::constraintCounter;

    cmaSetConstraintRef::iterator b=bad.begin();
    for(;b!=bad.end();++b)
      (*b)->constraintIdentifier=++cmaConstraint::constraintCounter;
  }
  
  
  result run(cmaSequenceRef& sequence)
  {
    cmaSetConstraintRef old_set, new_set, backward_reach,image_set,domain_set, frontiers;
    cmaConstraintRef o, i, im, b, approximate_frontier;
    cmaRuleRef r;
    cmaTrace trace;
    cmaUpwardRef preceq=preceq0;

    old_set=bad;
    backward_reach=bad;

    while(true) 
      {
	old_set=bad;	backward_reach=bad;
	trace.clear(); new_set.clear();

	while(!reach(o,old_set,i,init))
	  {
	    if(old_set.empty())
	      {

		cout << "Reached: \n" 
		     << backward_reach << endl;		  
		return not_reachable;
	      }
	    for(cmaRules::const_iterator rule=rules.begin(); 
		rule!=rules.end();++rule)
	      { 
		cmaSetConstraintRef::const_iterator a=old_set.begin();
		for(;a!=old_set.end();++a)
		  {
		    cmaSetConstraintRef pre=(*rule)->pred(*a);
		    cmaSetConstraintRef uppred=preceq->close(pre);		    		
		    cmaSetConstraintRef::iterator aup=uppred.begin();
		    for(;aup!=uppred.end();++aup)
		      {
			(*aup)->constraintIdentifier = ++cmaConstraint::constraintCounter;
			if(backward_reach.insert(*aup))
			  {
			    new_set.insert(*aup,true);			  
			    trace.add(*aup,*rule,*a);
			    
			  }
		      }
		  }
	      }
	    old_set=new_set; new_set.clear();
	  }
      
  	assert(o); 	assert(i);
	image_set.insert(o->intersect(i));
	domain_set.clear();
	sequence->addSetOfConstraints(image_set);
	do
	  {
	    domain_set=image_set;
	    r=trace.generatingRuleOf(o);
	    sequence->addRule(r);
	    o=trace.parentOf(o);
	    image_set=o->intersect(r->post(domain_set));
	    if(reach(im,image_set, b,bad))
	      {
		cmaSetConstraintRef touch;
		touch.insert(im->intersect(b));
		sequence->addSetOfConstraints(touch);
		return reachable ;
	      }
	    sequence->addSetOfConstraints(image_set);
	  }while(!image_set.empty());
	    
	cmaSetConstraintRef::const_iterator d=domain_set.begin();
	assert(d!=domain_set.end());
	for(;d!=domain_set.end();++d)
	  assert(frontiers.insert(*d));
	    

	if(approximate_frontier->doesIntersect(domain_set))
	  {
	    assert(false);
	    extrapolate->clear();
	    //	    preceq=preceq0->constrainWith(frontiers);	    
	    preceq=preceq->constrainWith(frontiers);	    
	  }
	else
	  {
	    approximate_frontier=extrapolate->withIncrement(domain_set);	    
	    //	    preceq=preceq0->constrainWith(approximate_frontier);	    
	    preceq=preceq->constrainWith(approximate_frontier);	    
	  }
      }
  };
  
 private:
  
  cmaSetConstraintRef init, bad;
  cmaRules rules;
  cmaExtrapolateRef extrapolate;
  cmaUpwardRef preceq0;

  static bool reach(cmaConstraintRef a, const cmaSetConstraintRef& A,
		    cmaConstraintRef b, const cmaSetConstraintRef& B){
    for(cmaSetConstraintRef::const_iterator itA=A.begin(); 
	itA!=A.end(); ++itA)
      for(cmaSetConstraintRef::const_iterator itB=B.begin(); 
	  itB!=B.end(); ++itB)
	{
	  cmaConstraintRef c=(*itA)->intersect(*itB);
	  if(!c->isEmpty())
	    {
	      a=*itA;
	      b=*itB;
	      return true;
	    }
	}
    return false;
  }

};
#endif

