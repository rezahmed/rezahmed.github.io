/* Partial_Function class declaration.
   Copyright (C) 2001-2008 Roberto Bagnara <bagnara@cs.unipr.it>

   This file is part of the Parma Polyhedra Library (PPL).

   The PPL is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3 of the License, or (at your
   option) any later version.
   
   The PPL is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
   for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02111-1307, USA.
   
   For the most up-to-date information see the Parma Polyhedra Library
   site: http://www.cs.unipr.it/ppl/ . */

#ifndef _PARTIALFUNCTION_H
#define _PARTIALFUNCTION_H

#include <ppl.hh>
#include <cstddef>
#include <map>
#include <iosfwd>

using namespace Parma_Polyhedra_Library;
using namespace Parma_Polyhedra_Library::IO_Operators;

class PartialFunction 
{
 private:
  typedef Parma_Polyhedra_Library::dimension_type dim_t;

 public:
  PartialFunction();

  bool has_empty_codomain() const;

  dim_t max_in_codomain() const
  {
    if (has_empty_codomain())
      throw std::runtime_error("PartialFunction::max_in_codomain() called"
			       " when has_empty_codomain()");
    return max;
  };

  bool maps(dim_t& x, dim_t& y) const
  {
    if (has_empty_codomain())
      throw std::runtime_error("PartialFunction::maps() called"
			       " when has_empty_codomain()");
    Map::const_iterator i = map.find(x);
    if (i != map.end()) {
      y = (*i).second;
      return true;
    }
    else
      return false;
  };

  void print(std::ostream& s) const
  {
    if (has_empty_codomain())
      s << "empty" << std::endl;
    else
      for (Map::const_iterator i = map.begin(),
	     map_end = map.end(); i != map_end; ++i)
	s << Variable((*i).first) << " --> "
	  << Variable((*i).second)
	  << std::endl;
  };
  
  void insert(dim_t x, dim_t y){ 
    std::pair<Map::iterator, bool> 
      stat = map.insert(Map::value_type(x, y));
    if (!stat.second)
      throw std::runtime_error("PartialFunction::insert(x, y) called"
			       " with `x' already in domain");
    if (y > max)
      max = y;
  }
  
 private:
  
  typedef std::map<dim_t, dim_t, std::less<dim_t> > Map;
  
  Map map;
  
  dim_t max;
};

inline PartialFunction::PartialFunction(): max(0) {}

inline bool PartialFunction::has_empty_codomain() const 
{ return map.empty();}


#endif 
