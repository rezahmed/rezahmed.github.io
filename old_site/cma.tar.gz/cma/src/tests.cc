
#include <config.h>
#include <iostream>
#include <stdlib.h>
#include <ppl.hh>
#include <string>
#include <map>

#include "ref.h"
#include "cma_order.h"
#include "minset.h"
#include "cma_constraint.h"
#include "ppl_constraint.h"
#include "cma_upward.h"
#include "ppl_upward.h"
#include "cma_rule.h"
#include "ppl_rule.h"

#include "cma_extrapolate.h" 
#include "ppl_extrapolate.h"
#include "cma_trace.h"
#include "cma_sequence.h"
#include "cma_algorithm.h"


using namespace Parma_Polyhedra_Library;
using namespace Parma_Polyhedra_Library::IO_Operators;


unsigned cmaConstraint::constraintCounter=0;
unsigned cmaConstraint::numberOfLocalVariables=0;
unsigned cmaConstraint::numberOfSharedVariables=0;
Partial_Function pplConstraint::sharedReverse;
Partial_Function pplConstraint::localReverse;
Variables_Set pplConstraint::localCodomainSet;  
Variables_Set pplConstraint::sharedCodomainSet;  
Variables_Set pplConstraint::localDomainSet;  
Variables_Set pplConstraint::sharedDomainSet;  
using namespace std;


C_Polyhedron get_Eq(const Constraint& c, const dimension_type& spd)
{
  Constraint_System cs; 
  cs.insert(c);
  C_Polyhedron result(cs);
  result.add_space_dimensions_and_embed(spd  - result.space_dimension());
  //  std::cout << "Eq("<< c << ")="<< result << std::endl;
  return result;
}


void naming(std::ostream& s, const Variable& v)
{
  dimension_type varid = v.id();
  switch(varid)
    {
    case 0: s << "x"; break;
    case 1: s << "y1"; break;
    case 2: s << "y2"; break;
    case 3: s << "y3"; break;
    case 4: s << "rx0"; break;
    case 5: s << "rx1"; break;
    case 6: s << "rx2"; break;
    case 7: s << "m1"; break;
    case 8: s << "m2"; break;
    case 9: s << "t"; break;
    default: s << "UNKNOWN"; break;
  }
};

void m1m2()
{

  Variable x(0);
  Variable y1(1);
  Variable y2(2);
  Variable y3(3);
  Variable rx0(4);
  Variable rx1(5);
  Variable rx2(6);
  Variable m1(7);
  Variable m2(8);
  Variable t(9);


  Constraint_System cs3;
  cs3.insert(m1==2); cs3.insert(m2==3);
  //cs3.insert(x==1); //cs3.insert(rx==5);
  cs3.insert(y1==rx2); cs3.insert(y2==rx1); cs3.insert(y3==rx0); 
  cs3.insert(rx2==m1); cs3.insert(rx1==m2);
  C_Polyhedron p3(cs3);
  p3.add_space_dimensions_and_embed(2);
  std::cout << "p3 " << p3 << std::endl;


  // prels
  //
  Constraint_System rx0Et; 
  rx0Et.insert(rx0==t);
  C_Polyhedron rx0EtP(rx0Et);
  rx0EtP.add_space_dimensions_and_embed(p3.space_dimension() - rx0EtP.space_dimension());
  std::cout << "rx0EtP = " << rx0EtP << std::endl;
  //
  Constraint_System rx0Em1pm2; 
  rx0Em1pm2.insert(rx0==m1+m2);
  C_Polyhedron rx0Em1pm2P(rx0Em1pm2);
  rx0Em1pm2P.add_space_dimensions_and_embed(p3.space_dimension() - rx0Em1pm2P.space_dimension());
  std::cout << "rx0Em1pm2P = " << rx0Em1pm2P << std::endl;
  //
  Constraint_System tEm1; 
  tEm1.insert(t==m1);
  C_Polyhedron tEm1P(tEm1);
  tEm1P.add_space_dimensions_and_embed(p3.space_dimension() - tEm1P.space_dimension());
  std::cout << "tEm1P = " << tEm1P << std::endl;
  //
  Constraint_System m2Em1; 
  m2Em1.insert(m2==m1);
  C_Polyhedron m2Em1P(m2Em1);
  m2Em1P.add_space_dimensions_and_embed(p3.space_dimension() - m2Em1P.space_dimension());
  std::cout << "m2Em1P = " << m2Em1P << std::endl;
  //
  Constraint_System tEm2; 
  tEm2.insert(t==m2);
  C_Polyhedron tEm2P(tEm2);
  tEm2P.add_space_dimensions_and_embed(p3.space_dimension() - tEm2P.space_dimension());
  std::cout << "tEm2P = " << tEm2P << std::endl;
  //
  Constraint_System rx0Em2; 
  rx0Em2.insert(rx0==m2);
  C_Polyhedron rx0Em2P(rx0Em2);
  rx0Em2P.add_space_dimensions_and_embed(p3.space_dimension() - rx0Em2P.space_dimension());
  std::cout << "rx0Em2P = " << rx0Em2P << std::endl;
  //
  Constraint_System rx1Et; 
  rx1Et.insert(rx1==t);
  C_Polyhedron rx1EtP(rx1Et);
  rx1EtP.add_space_dimensions_and_embed(p3.space_dimension() - rx1EtP.space_dimension());
  std::cout << "rx1EtP = " << rx1EtP << std::endl;
  //
  Constraint_System rx2Et; 
  rx2Et.insert(rx2==t);
  C_Polyhedron rx2EtP(rx2Et);
  rx2EtP.add_space_dimensions_and_embed(p3.space_dimension() - rx2EtP.space_dimension());
  std::cout << "rx2EtP = " << rx2EtP << std::endl;
  //
  Constraint_System rx2Erx1; 
  rx2Erx1.insert(rx2==rx1);
  C_Polyhedron rx2Erx1P(rx2Erx1);
  rx2Erx1P.add_space_dimensions_and_embed(p3.space_dimension() - rx2Erx1P.space_dimension());
  std::cout << "rx2Erx1P = " << rx2Erx1P << std::endl;
  //
  Constraint_System rx1Erx0; 
  rx1Erx0.insert(rx1==rx0);
  C_Polyhedron rx1Erx0P(rx1Erx0);
  rx1Erx0P.add_space_dimensions_and_embed(p3.space_dimension() - rx1Erx0P.space_dimension());
  std::cout << "rx1Erx0P = " << rx1Erx0P << std::endl;
  //
  Constraint_System y1Erx2; 
  y1Erx2.insert(y1==rx2);
  C_Polyhedron y1Erx2P(y1Erx2);
  y1Erx2P.add_space_dimensions_and_embed(p3.space_dimension() - y1Erx2P.space_dimension());
  std::cout << "y1Erx2P = " << y1Erx2P << std::endl;
  //
  Constraint_System y2Erx1; 
  y2Erx1.insert(y2==rx1);
  C_Polyhedron y2Erx1P(y2Erx1);
  y2Erx1P.add_space_dimensions_and_embed(p3.space_dimension() - y2Erx1P.space_dimension());
  std::cout << "y2Erx1P = " << y2Erx1P << std::endl;
  //
  Constraint_System y3Erx0; 
  y3Erx0.insert(y3==rx0);
  C_Polyhedron y3Erx0P(y3Erx0);
  y3Erx0P.add_space_dimensions_and_embed(p3.space_dimension() - y3Erx0P.space_dimension());
  std::cout << "y3Erx0P = " << y3Erx0P << std::endl;
  
 
  unsigned s=0;
  C_Polyhedron p7old;
  C_Polyhedron p7new(p3.space_dimension(), EMPTY);
  while(true)
    //for(int i=0; i<4; ++i)
  {

    //rx0:=m1+m2
    C_Polyhedron p4(p3);  
    p4.intersection_assign_and_minimize(rx0EtP);     p4.unconstrain(rx0); 
    p4.intersection_assign_and_minimize(rx0Em1pm2P); p4.unconstrain(y3);  
    p4.intersection_assign_and_minimize(y3Erx0P);  p4.unconstrain(t);
    std::cout << "p4 = (p3 with rx0:=m1+m2) = " << p4 << std::endl;

    //m1:=m2
    C_Polyhedron p5(p4);  
    p5.intersection_assign_and_minimize(tEm1P); p5.unconstrain(m1); 
    p5.intersection_assign_and_minimize(m2Em1P); p5.unconstrain(t); 
    std::cout << "p5 = (p4 with m1:=m2) = " << p5 << std::endl;


    //m2:=rx0
    C_Polyhedron p6(p5);  
    p6.intersection_assign_and_minimize(tEm2P); p6.unconstrain(m2); 
    p6.intersection_assign_and_minimize(rx0Em2P); p6.unconstrain(t); 
    std::cout << "p6 = (p5 with m2:=rx) = " << p6 << std::endl;

    // move rx0,rx1,rx2 to the left
    C_Polyhedron p7(p6);
    p7.intersection_assign_and_minimize(rx2EtP);   p7.unconstrain(rx2);
    p7.intersection_assign_and_minimize(rx2Erx1P); p7.unconstrain(t);
    p7.intersection_assign_and_minimize(rx1EtP);   p7.unconstrain(rx1);
    p7.intersection_assign_and_minimize(rx1Erx0P); p7.unconstrain(t);  
    p7.unconstrain(rx0); 
    std::cout << "p7 = (rx:=rx->n : 1) = " << p7 << std::endl;


    p7old=p7new;
    p7new=p7;

    p7new.poly_hull_assign_and_minimize(p7old);
    p7new.BHRZ03_widening_assign(p7old,&s);
    std::cout << "p7new = " << p7new << std::endl;

    p7.unconstrain(y1);    p7.unconstrain(y2);    p7.unconstrain(y3);
    p7.intersection_assign_and_minimize(y1Erx2P);
    p7.intersection_assign_and_minimize(y2Erx1P);
    p7.intersection_assign_and_minimize(y3Erx0P);
    p7.poly_hull_assign_and_minimize(p3);
    p7.BHRZ03_widening_assign(p3,&s);

    std::cout << "p3 = " << p7 << std::endl;

    if(p7old.contains(p7new) && p3.contains(p7))
      break;
    p3=p7;
    std::cout << std::endl;


  }
  

}

void dec()
{

  Variable x(0);
  Variable y1(1);
  Variable y2(2);
  Variable y3(3);
  Variable rx0(4);
  Variable rx1(5);
  Variable rx2(6);
  Variable m1(7);
  Variable m2(8);
  Variable t(9);

  Constraint_System ce4;
  ce4.insert(rx2==m1); ce4.insert(rx1==m2);   ce4.insert(rx0==m2+m1); 
  ce4.insert(m1==0); ce4.insert(m2==1);
  C_Polyhedron e4(ce4);
  e4.add_space_dimensions_and_embed(1);
  std::cout << "e4:" << e4.space_dimension() << ":" << e4 << std::endl;

  Constraint_System cu3;
#ifdef NO_SUCCESSIVE
  cu3.insert(y1<=y2); cu3.insert(y2<=y3);
#else
  cu3.insert(y1+y2==y3);
#endif
  C_Polyhedron u3(cu3);
  u3.add_space_dimensions_and_embed(6);
  std::cout << "u3:" << u3.space_dimension() << ":" << u3 << std::endl;


  unsigned s=1;
  while(true)
    //for(int i=0; i<4; ++i)
  {

    //m1:=m2
    C_Polyhedron e5(e4);  
    e5.intersection_assign_and_minimize(get_Eq(t==m1,e4.space_dimension())); e5.unconstrain(m1); 
    e5.intersection_assign_and_minimize(get_Eq(m2==m1,e4.space_dimension())); e5.unconstrain(t); 
    std::cout << "e5 = (e4 with m1:=m2) = " << e5 << std::endl;


    //m2:=rx0
    C_Polyhedron e6(e5);  
    e6.intersection_assign_and_minimize(get_Eq(t==m2,e4.space_dimension())); e6.unconstrain(m2); 
    e6.intersection_assign_and_minimize(get_Eq(rx0==m2,e4.space_dimension())); e6.unconstrain(t); 
    std::cout << "e6 = (e5 with m2:=rx) = " << e6 << std::endl;

   

    // move rx0,rx1,rx2 to the left
    //existential
    C_Polyhedron e3=e6;  
    e3.intersection_assign_and_minimize(get_Eq(rx2==t,e4.space_dimension()));  e3.unconstrain(rx2);
    e3.intersection_assign_and_minimize(get_Eq(rx2==rx1,e4.space_dimension()));   e3.unconstrain(t);
    e3.intersection_assign_and_minimize(get_Eq(rx1==t,e4.space_dimension()));  e3.unconstrain(rx1);
    e3.intersection_assign_and_minimize(get_Eq(rx1==rx0,e4.space_dimension()));   e3.unconstrain(t);
    e3.unconstrain(rx0);

    //rx0:=m1+m2
    C_Polyhedron e4new(e3);  
    e4new.intersection_assign_and_minimize(get_Eq(rx0==t,e4.space_dimension()));     e4new.unconstrain(rx0); 
    e4new.intersection_assign_and_minimize(get_Eq(rx0==m1+m2,e4.space_dimension()));      e4new.unconstrain(t); 
    std::cout << "e4new = (e3 with rx0:=m1+m2) = " << e4new << std::endl;

    e4new.poly_hull_assign_and_minimize(e4);
    e4new.BHRZ03_widening_assign(e4,&s);
    std::cout << "e4new widened = " << e4new << std::endl;

    //universal
    C_Polyhedron meet(u3);
    meet.intersection_assign_and_minimize(e6);
    std::cout << "meet = " << meet << std::endl;

#ifdef NO_SUCCESSIVE
    C_Polyhedron y3ToLeft(meet);
    y3ToLeft.intersection_assign_and_minimize(y3EtP);   y3ToLeft.unconstrain(y3);
    y3ToLeft.intersection_assign_and_minimize(y3Erx2P);  y3ToLeft.unconstrain(t);
    y3ToLeft.unconstrain(rx0);    y3ToLeft.unconstrain(rx1);    y3ToLeft.unconstrain(rx2);
    y3ToLeft.unconstrain(m1);    y3ToLeft.unconstrain(m2);
    std::cout << "y3ToLeft =  " << y3ToLeft << std::endl;

    C_Polyhedron y2y3ToLeft(meet);
    y2y3ToLeft.intersection_assign_and_minimize(y2EtP);   y2y3ToLeft.unconstrain(y2);
    y2y3ToLeft.intersection_assign_and_minimize(y2Ey3P);  y2y3ToLeft.unconstrain(t);
    y2y3ToLeft.intersection_assign_and_minimize(y3EtP);   y2y3ToLeft.unconstrain(y3);
    y2y3ToLeft.intersection_assign_and_minimize(y3Erx2P);  y2y3ToLeft.unconstrain(t);
    y2y3ToLeft.unconstrain(rx0);    y2y3ToLeft.unconstrain(rx1);    y2y3ToLeft.unconstrain(rx2);
    y2y3ToLeft.unconstrain(m1);    y2y3ToLeft.unconstrain(m2);
    std::cout << "y2y3ToLeft =  " << y2y3ToLeft << std::endl;
    

    C_Polyhedron y1y2y3ToLeft(meet);
    y1y2y3ToLeft.intersection_assign_and_minimize(y1EtP);   y1y2y3ToLeft.unconstrain(y1);
    y1y2y3ToLeft.intersection_assign_and_minimize(y1Ey2P);  y1y2y3ToLeft.unconstrain(t);
    y1y2y3ToLeft.intersection_assign_and_minimize(y2EtP);   y1y2y3ToLeft.unconstrain(y2);
    y1y2y3ToLeft.intersection_assign_and_minimize(y2Ey3P);  y1y2y3ToLeft.unconstrain(t);
    y1y2y3ToLeft.intersection_assign_and_minimize(y3EtP);   y1y2y3ToLeft.unconstrain(y3);
    y1y2y3ToLeft.intersection_assign_and_minimize(y3Erx2P);  y1y2y3ToLeft.unconstrain(t);
     y1y2y3ToLeft.unconstrain(rx0);    y1y2y3ToLeft.unconstrain(rx1);    y1y2y3ToLeft.unconstrain(rx2);
    y1y2y3ToLeft.unconstrain(m1);    y1y2y3ToLeft.unconstrain(m2);
    std::cout << "y1y2y3ToLeft =  " << y1y2y3ToLeft << std::endl;

    C_Polyhedron u3new=y1y2y3ToLeft;
    u3new.poly_hull_assign_and_minimize(y2y3ToLeft);
    u3new.poly_hull_assign_and_minimize(y3ToLeft);
    u3new.poly_hull_assign_and_minimize(u3);
    std::cout << "u3new =  " << u3new << std::endl;
#else
    C_Polyhedron u3new(meet);
    u3new.intersection_assign_and_minimize(get_Eq(y1==t,u3new.space_dimension()));   u3new.unconstrain(y1);
    u3new.intersection_assign_and_minimize(get_Eq(y1==rx2,u3new.space_dimension()));  u3new.unconstrain(t);
    u3new.intersection_assign_and_minimize(get_Eq(y2==t,u3new.space_dimension()));   u3new.unconstrain(y2);
    u3new.intersection_assign_and_minimize(get_Eq(y2==rx1,u3new.space_dimension()));  u3new.unconstrain(t);
    u3new.intersection_assign_and_minimize(get_Eq(y3==t,u3new.space_dimension()));   u3new.unconstrain(y3);
    u3new.intersection_assign_and_minimize(get_Eq(y3==rx0,u3new.space_dimension()));  u3new.unconstrain(t);
    u3new.unconstrain(rx0);    u3new.unconstrain(rx1);    u3new.unconstrain(rx2);
    u3new.unconstrain(m1);    u3new.unconstrain(m2);
    std::cout << "u3new =  " << u3new << std::endl;
#endif
  
    u3new.BHRZ03_widening_assign(u3,&s);
    std::cout << "u3new widened = " << u3new << std::endl;

   

    if(u3.contains(u3new) && e4.contains(e4new))
      break;
    e4=e4new;
    u3=u3new;
    std::cout << std::endl;


  }
  

}

int series()
{

  Variable y1(1);
  Variable y2(2);
  Variable y3(3);


  Constraint_System cs;
  cs.insert(y1==2); cs.insert(y2==3); cs.insert(y3==5); 
  //  BD_Shape<mpq_class> p(essai);
  //BD_Shape<mpq_class> q=p;
  C_Polyhedron p(cs);
  C_Polyhedron q=p;
  std::cout << "p=" << p << std::endl;
  int a=2, b=3, c=5;
  unsigned s=5;
  //  for(int i=0; i<10; ++i)
  while(true)
  {
    std::cout << "p=" << p << std::endl;
    a=b;
    b=c;
    c=a+b;
    std::cout << "a,b,c=" << a << "," << b << "," << c << std::endl;
    Constraint_System exact_cs;
    exact_cs.insert(y1==2); exact_cs.insert(y2==3); exact_cs.insert(y3==5);
    C_Polyhedron exact(exact_cs);

    C_Polyhedron c3(Constraint_System(y3==c));
    c3.add_space_dimensions_and_embed(0);
    C_Polyhedron c2(Constraint_System(y2==b));
    c2.add_space_dimensions_and_embed(1);
    C_Polyhedron c1(Constraint_System(y1==a));
    c1.add_space_dimensions_and_embed(2);

    C_Polyhedron q0(exact);
    q0.unconstrain(y3);
    q0.intersection_assign_and_minimize(c3);
    std::cout << "q0=" << q0 << std::endl;

    C_Polyhedron q1(q0);
    q1.unconstrain(y2);
    q1.intersection_assign_and_minimize(c2);
    std::cout << "q1=" << q1 << std::endl;

    C_Polyhedron q2(q1);
    q2.unconstrain(y1);
    q2.intersection_assign_and_minimize(c1);
    std::cout << "q2=" << q2 << std::endl;

    //    q=BD_Shape<mpq_class>(essai);
    C_Polyhedron q(p);
    q.poly_hull_assign_and_minimize(q0);
    q.poly_hull_assign_and_minimize(q1);
    q.poly_hull_assign_and_minimize(q2);
    std::cout << "q = p U q0 U q1 U q2 = " << q << std::endl;
    //    q.upper_bound_assign(p);

    //    q.widening_assign(p);
    q.H79_widening_assign(p, &s);
    std::cout << "q nabla p=" << q << std::endl;
    if(p.contains(q))
      break;
    p=q;
    std::cout << std::endl;
    }

}

int 
main (void)
{
  std::cout << ("Hello World!") << std::endl;

  cout << "This is " << PACKAGE_STRING << "." << endl;

  Variable::set_output_function(naming);

  //  m1m2();
   dec();
   //series();

return 0;
}


/*void rx()
{


  Variable am4(0); //a-4
  Variable am3(1); //a-3
  Variable am2(2); //a-2
  Variable am1(3); //a-1
  Variable a0(4);  //a0
  Variable a1(5);  //a1
  Variable a2(6);  //a2
  Variable a3(7);  //a3
  Variable a4(8);  //a4

  Variable m1(9);  //m1
  Variable m2(10);  //m2


  //  (1:x).1.2:rx
  C_Polyhedron x1(11);
  x1.add_constraint_and_minimize(a0==1);   
  x1.add_constraint_and_minimize(a1==1);   
  x1.add_constraint_and_minimize(a2==2);   
  x1.add_constraint_and_minimize(m1==1);   
  x1.add_constraint_and_minimize(m2==2);   
  std::cout << "x1 " << x1 << std::endl;


  //  (1:x).1.2.3:rx
  C_Polyhedron x2(11);
  x2.add_constraint_and_minimize(a0==1);   
  x2.add_constraint_and_minimize(a1==1);   
  x2.add_constraint_and_minimize(a2==2);   
  x2.add_constraint_and_minimize(a3==3);   
  x2.add_constraint_and_minimize(m1==2);   
  x2.add_constraint_and_minimize(m2==3);   
  std::cout << "x2 " << x2 << std::endl;

  C_Polyhedron x12=x1;
  x12.poly_hull_assign_and_minimize(x2);
  std::cout << "x12 = (poly hull of x1 and x2) = " << x12 << std::endl;

  C_Polyhedron x2wx1=x12;
  //Q2.BHRZ03_widening_assign(P0);
  x2wx1.H79_widening_assign(x1);
  std::cout << "x2wx1 = (x12.H79_widening_assign(x1)) = " << x2wx1 << std::endl;



  // 1:x.(1).2:rx
  C_Polyhedron xrx1(11);
  xrx1.add_constraint_and_minimize(am1==1);
  xrx1.add_constraint_and_minimize(a0==1);
  xrx1.add_constraint_and_minimize(a1==2);
  xrx1.add_constraint_and_minimize(m1==1);   
  xrx1.add_constraint_and_minimize(m2==2);   
  std::cout << std::endl << "xrx1 " << xrx1 << std::endl;

  // 1:x.(1).2.3:rx
  C_Polyhedron xrx12(11);
  xrx12.add_constraint_and_minimize(am1==1);
  xrx12.add_constraint_and_minimize(a0==1);
  xrx12.add_constraint_and_minimize(a1==2);
  xrx12.add_constraint_and_minimize(a2==3);
  xrx12.add_constraint_and_minimize(m1==2);   
  xrx12.add_constraint_and_minimize(m2==3);   
  std::cout << "xrx12 " << xrx12 << std::endl;

  // 1:x.1.(2).3:rx
  C_Polyhedron xrx22(11);
  xrx22.add_constraint_and_minimize(am2==1);
  xrx22.add_constraint_and_minimize(am1==1);
  xrx22.add_constraint_and_minimize(a0==2);
  xrx22.add_constraint_and_minimize(a1==3);
  xrx22.add_constraint_and_minimize(m1==2);   
  xrx22.add_constraint_and_minimize(m2==3);   
  std::cout << "xrx22 " << xrx22 << std::endl;


  C_Polyhedron xrx12Jxrx1=xrx12;
  xrx12Jxrx1.poly_hull_assign_and_minimize(xrx1);
  std::cout << std::endl << "xrx12Jxrx1 = (poly hull of xrx12 and xrx1) = " << xrx12Jxrx1 << std::endl;

  C_Polyhedron xrx12Wxrx1=xrx12Jxrx1;
  //Q2.BHRZ03_widening_assign(P0);
  xrx12Wxrx1.H79_widening_assign(xrx1);
  std::cout << "xrx12Wxrx1 = (xrx12Jxrx1.H79_widening_assign(xrx1)) = " << xrx12Wxrx1 << std::endl;


  C_Polyhedron xrx22Jxrx1=xrx22;
  xrx22Jxrx1.poly_hull_assign_and_minimize(xrx1);
  std::cout << "xrx22Jxrx1 = (poly hull of xrx22 and xrx1) = " << xrx22Jxrx1 << std::endl;

  C_Polyhedron xrx22Wxrx1=xrx22Jxrx1;
  //Q2.BHRZ03_widening_assign(P0);
  xrx22Wxrx1.H79_widening_assign(xrx1);
  std::cout << "xrx22Wxrx1 = (xrx22Jxrx1.H79_widening_assign(xrx1)) = " << xrx22Wxrx1 << std::endl;

  C_Polyhedron W221JW121=xrx22Wxrx1;
  W221JW121.poly_hull_assign_and_minimize(xrx12Wxrx1);
  std::cout << "W221JW121 = (poly hull of xrx22Wxrx1 and xrx12Xxrx1) = " << W221JW121 << std::endl;

  C_Polyhedron W221WW121=W221JW121;
  //Q2.BHRZ03_widening_assign(P0);
  W221WW121.H79_widening_assign(xrx22Wxrx1);
  std::cout << "W221WW121 = (W221JW121.H79_widening_assign(xrx22Wxrx1)) = " << W221WW121 << std::endl;

  C_Polyhedron W121WW221=W221JW121;
  //Q2.BHRZ03_widening_assign(P0);
  W121WW221.H79_widening_assign(xrx12Wxrx1);
  std::cout << std::endl << "W121WW221 = (W221JW121.H79_widening_assign(xrx12Wxrx1)) = " << W121WW221 << std::endl;





  C_Polyhedron xrx12Jxrx22=xrx12;
  xrx12Jxrx22.poly_hull_assign_and_minimize(xrx22);
  std::cout << "xrx12Jxrx22 = (poly hull of xrx12 and xrx22) = " << xrx12Jxrx22 << std::endl;

  C_Polyhedron xrx12Wxrx22=xrx12Jxrx22;
  //Q2.BHRZ03_widening_assign(P0);
  xrx12Wxrx22.H79_widening_assign(xrx12);
  std::cout << "xrx12Wxrx22 = (xrx12Jxrx22.H79_widening_assign(xrx12)) = " << xrx12Wxrx22 << std::endl;

  C_Polyhedron xrx22Wxrx12=xrx12Jxrx22;
  //Q2.BHRZ03_widening_assign(P0);
  xrx22Wxrx12.H79_widening_assign(xrx22);
  std::cout << "xrx22Wxrx12 = (xrx12Jxrx22.H79_widening_assign(xrx22)) = " << xrx22Wxrx12 << std::endl;

  C_Polyhedron W12JW22=xrx22Wxrx12;
  W12JW22.poly_hull_assign_and_minimize(xrx12Wxrx22);
  std::cout << "W12JW22 = (poly hull of xrx22Wxrx12 and xrx12Wxrx22) = " << W12JW22 << std::endl;



  // 1:x.1.(2:rx)
  C_Polyhedron rx1(11);
  rx1.add_constraint_and_minimize(am2==1);
  rx1.add_constraint_and_minimize(am1==1);
  rx1.add_constraint_and_minimize(a0==2);
  rx1.add_constraint_and_minimize(m1==1);   
  rx1.add_constraint_and_minimize(m2==2);   
  std::cout << std::endl << "rx1 " << rx1 << std::endl;

  // 1:x.1.2.(3:rx)
  C_Polyhedron rx2(11);
  rx2.add_constraint_and_minimize(am3==1);
  rx2.add_constraint_and_minimize(am2==1);
  rx2.add_constraint_and_minimize(am1==2);
  rx2.add_constraint_and_minimize(a0==3);
  rx2.add_constraint_and_minimize(m1==2);   
  rx2.add_constraint_and_minimize(m2==3);   
  std::cout << "rx2 " << rx2 << std::endl;

  C_Polyhedron rx1Jrx2=rx2;
  rx1Jrx2.poly_hull_assign_and_minimize(rx1);
  std::cout << "rx1Jrx2 = (poly hull of rx1 and rx2) = " << rx1Jrx2 << std::endl;

  C_Polyhedron rx2Wrx1=rx1Jrx2;
  //Q2.BHRZ03_widening_assign(P0);
  rx2Wrx1.H79_widening_assign(rx2);
  std::cout << "rx2Wrx1 = (rx2Jrx1.H79_widening_assign(rx2)) = " << rx2Wrx1 << std::endl;



}*/

 /*



void h76_polyhedra()
{


  Variable T(0);
  Variable R(1);
  Variable CR(2);
  Variable W(3);
  Variable CW(4);

  Constraint_System cs1;
  cs1.insert(T>=0); cs1.insert(CR==2); cs1.insert(R==2);
  cs1.insert(W==0); cs1.insert(CW==0);
  C_Polyhedron F1(cs1);
  F1.add_space_dimensions_and_embed(2*cmaConstraint::numberOfLocalVariables - F1.space_dimension());
  std::cout << "F1 " << F1 << std::endl;

  Constraint_System cs2;
  cs2.insert(T>=0); cs2.insert(CR==1); cs2.insert(R==1);
  cs2.insert(W==0); cs2.insert(CW==0);
  C_Polyhedron F2(cs2);
  F2.add_space_dimensions_and_embed(2*cmaConstraint::numberOfLocalVariables - F2.space_dimension());
  std::cout << "F2 " << F2 << std::endl;


  Constraint_System cs3;
  cs3.insert(T>=0); cs3.insert(CR==3); cs3.insert(R==3);
  cs3.insert(W==0); cs3.insert(CW==0);
  C_Polyhedron F3(cs3);
  F3.add_space_dimensions_and_embed(2*cmaConstraint::numberOfLocalVariables - F3.space_dimension());
  std::cout << "F3 " << F3 << std::endl;


  C_Polyhedron hull2=F1;
  hull2.poly_hull_assign_and_minimize(F2);
  std::cout << "hull2 = (poly hull of F1 and F2) = " << hull2 << std::endl;


  C_Polyhedron Q2=hull2;
  //Q2.BHRZ03_widening_assign(P0);
  Q2.H79_widening_assign(F1);
  std::cout << "Q2 = (hull2.H79_widening_assign(F1)) = " << Q2 << std::endl;

  //  C_Polyhedron Q2p=hull2;
  //Q2.BHRZ03_widening_assign(P0);
  //Q2p.H79_widening_assign(F2);
  //std::cout << "Q2p = (hull2.H79_widening_assign(F2)) = " << Q2p << std::endl;


  C_Polyhedron hull3=F3;
  hull3.poly_hull_assign_and_minimize(Q2);
  std::cout << "hull3 = (poly hull of F3 and Q2) = " << hull3 << std::endl;

  
  C_Polyhedron Q3=hull3;
  //Q2.BHRZ03_widening_assign(P0);
  Q3.H79_widening_assign(F2);
  std::cout << "Q3 = (hull3.H79_widening_assign(F2)) = " << Q3 << std::endl;

  //  C_Polyhedron Q3p=hull3;
  //Q2.BHRZ03_widening_assign(P0);
  //Q3p.H79_widening_assign(F3);
  //std::cout << "Q3p = (hull3.H79_widening_assign(F3)) = " << Q3p << std::endl;
}


void xrx()
{


  Variable am4(0); //a-4
  Variable am3(1); //a-3
  Variable am2(2); //a-2
  Variable am1(3); //a-1
  Variable a0(4);  //a0
  Variable a1(5);  //a1
  Variable a2(6);  //a2
  Variable a3(7);  //a3
  Variable a4(8);  //a4

  //  1.(2).4
  C_Polyhedron F1(9);
  F1.add_constraint_and_minimize(am1==1);   
  F1.add_constraint_and_minimize(a0==2);   
  F1.add_constraint_and_minimize(a1==3);   
  std::cout << "F1 " << F1 << std::endl;

  // 1.(2).4.7
  C_Polyhedron F2(9);
  F2.add_constraint_and_minimize(am1==1);
  F2.add_constraint_and_minimize(a0==2);
  F2.add_constraint_and_minimize(a1==3);
  F2.add_constraint_and_minimize(a2==5);                  
  std::cout << "F2 " << F2 << std::endl;

  // 1.2.(4).7
  C_Polyhedron F3(9);
  F3.add_constraint_and_minimize(am2==1);
  F3.add_constraint_and_minimize(am1==2);
  F3.add_constraint_and_minimize(a0==3);
  F3.add_constraint_and_minimize(a1==5);
  std::cout << "F3 " << F3 << std::endl;

  C_Polyhedron hull23=F2;
  hull23.poly_hull_assign_and_minimize(F3);
  std::cout << "hull23 = (poly hull of F2 and F3) = " << hull23 << std::endl;

  C_Polyhedron Q23=hull23;
  //Q2.rxBHRZ03_widening_assign(P0);
  Q23.H79_widening_assign(F3);
  std::cout << "Q23 = (hull23.H79_widening_assign(F3)) = " << Q23 << std::endl;


  C_Polyhedron hull231=F1;
  hull231.poly_hull_assign_and_minimize(Q23);
  std::cout << "hull231 = (poly hull of F1 and Q23) = " << hull231 << std::endl;

  C_Polyhedron Q231=hull231;
  //Q2.BHRZ03_widening_assign(P0);
  Q231.H79_widening_assign(F1);
  std::cout << "Q231 = (hull231.H79_widening_assign(F1)) = " << Q231 << std::endl;

}

void rx()
{


  Variable am4(0); //a-4
  Variable am3(1); //a-3
  Variable am2(2); //a-2
  Variable am1(3); //a-1
  Variable a0(4);  //a0
  Variable a1(5);  //a1
  Variable a2(6);  //a2
  Variable a3(7);  //a3
  Variable a4(8);  //a4

  Variable m1(9);  //m1
  Variable m2(10);  //m2


  //  (1:x).1.2:rx
  C_Polyhedron x1(11);
  x1.add_constraint_and_minimize(a0==1);   
  x1.add_constraint_and_minimize(a1==1);   
  x1.add_constraint_and_minimize(a2==2);   
  x1.add_constraint_and_minimize(m1==1);   
  x1.add_constraint_and_minimize(m2==2);   
  std::cout << "x1 " << x1 << std::endl;


  //  (1:x).1.2.3:rx
  C_Polyhedron x2(11);
  x2.add_constraint_and_minimize(a0==1);   
  x2.add_constraint_and_minimize(a1==1);   
  x2.add_constraint_and_minimize(a2==2);   
  x2.add_constraint_and_minimize(a3==3);   
  x2.add_constraint_and_minimize(m1==2);   
  x2.add_constraint_and_minimize(m2==3);   
  std::cout << "x2 " << x2 << std::endl;

  C_Polyhedron x12=x1;
  x12.poly_hull_assign_and_minimize(x2);
  std::cout << "x12 = (poly hull of x1 and x2) = " << x12 << std::endl;

  C_Polyhedron x2wx1=x12;
  //Q2.BHRZ03_widening_assign(P0);
  x2wx1.H79_widening_assign(x1);
  std::cout << "x2wx1 = (x12.H79_widening_assign(x1)) = " << x2wx1 << std::endl;



  // 1:x.(1).2:rx
  C_Polyhedron xrx1(11);
  xrx1.add_constraint_and_minimize(am1==1);
  xrx1.add_constraint_and_minimize(a0==1);
  xrx1.add_constraint_and_minimize(a1==2);
  xrx1.add_constraint_and_minimize(m1==1);   
  xrx1.add_constraint_and_minimize(m2==2);   
  std::cout << std::endl << "xrx1 " << xrx1 << std::endl;

  // 1:x.(1).2.3:rx
  C_Polyhedron xrx12(11);
  xrx12.add_constraint_and_minimize(am1==1);
  xrx12.add_constraint_and_minimize(a0==1);
  xrx12.add_constraint_and_minimize(a1==2);
  xrx12.add_constraint_and_minimize(a2==3);
  xrx12.add_constraint_and_minimize(m1==2);   
  xrx12.add_constraint_and_minimize(m2==3);   
  std::cout << "xrx12 " << xrx12 << std::endl;

  // 1:x.1.(2).3:rx
  C_Polyhedron xrx22(11);
  xrx22.add_constraint_and_minimize(am2==1);
  xrx22.add_constraint_and_minimize(am1==1);
  xrx22.add_constraint_and_minimize(a0==2);
  xrx22.add_constraint_and_minimize(a1==3);
  xrx22.add_constraint_and_minimize(m1==2);   
  xrx22.add_constraint_and_minimize(m2==3);   
  std::cout << "xrx22 " << xrx22 << std::endl;


  C_Polyhedron xrx12Jxrx1=xrx12;
  xrx12Jxrx1.poly_hull_assign_and_minimize(xrx1);
  std::cout << std::endl << "xrx12Jxrx1 = (poly hull of xrx12 and xrx1) = " << xrx12Jxrx1 << std::endl;

  C_Polyhedron xrx12Wxrx1=xrx12Jxrx1;
  //Q2.BHRZ03_widening_assign(P0);
  xrx12Wxrx1.H79_widening_assign(xrx1);
  std::cout << "xrx12Wxrx1 = (xrx12Jxrx1.H79_widening_assign(xrx1)) = " << xrx12Wxrx1 << std::endl;


  C_Polyhedron xrx22Jxrx1=xrx22;
  xrx22Jxrx1.poly_hull_assign_and_minimize(xrx1);
  std::cout << "xrx22Jxrx1 = (poly hull of xrx22 and xrx1) = " << xrx22Jxrx1 << std::endl;

  C_Polyhedron xrx22Wxrx1=xrx22Jxrx1;
  //Q2.BHRZ03_widening_assign(P0);
  xrx22Wxrx1.H79_widening_assign(xrx1);
  std::cout << "xrx22Wxrx1 = (xrx22Jxrx1.H79_widening_assign(xrx1)) = " << xrx22Wxrx1 << std::endl;

  C_Polyhedron W221JW121=xrx22Wxrx1;
  W221JW121.poly_hull_assign_and_minimize(xrx12Wxrx1);
  std::cout << "W221JW121 = (poly hull of xrx22Wxrx1 and xrx12Xxrx1) = " << W221JW121 << std::endl;

  C_Polyhedron W221WW121=W221JW121;
  //Q2.BHRZ03_widening_assign(P0);
  W221WW121.H79_widening_assign(xrx22Wxrx1);
  std::cout << "W221WW121 = (W221JW121.H79_widening_assign(xrx22Wxrx1)) = " << W221WW121 << std::endl;

  C_Polyhedron W121WW221=W221JW121;
  //Q2.BHRZ03_widening_assign(P0);
  W121WW221.H79_widening_assign(xrx12Wxrx1);
  std::cout << std::endl << "W121WW221 = (W221JW121.H79_widening_assign(xrx12Wxrx1)) = " << W121WW221 << std::endl;





  C_Polyhedron xrx12Jxrx22=xrx12;
  xrx12Jxrx22.poly_hull_assign_and_minimize(xrx22);
  std::cout << "xrx12Jxrx22 = (poly hull of xrx12 and xrx22) = " << xrx12Jxrx22 << std::endl;

  C_Polyhedron xrx12Wxrx22=xrx12Jxrx22;
  //Q2.BHRZ03_widening_assign(P0);
  xrx12Wxrx22.H79_widening_assign(xrx12);
  std::cout << "xrx12Wxrx22 = (xrx12Jxrx22.H79_widening_assign(xrx12)) = " << xrx12Wxrx22 << std::endl;

  C_Polyhedron xrx22Wxrx12=xrx12Jxrx22;
  //Q2.BHRZ03_widening_assign(P0);
  xrx22Wxrx12.H79_widening_assign(xrx22);
  std::cout << "xrx22Wxrx12 = (xrx12Jxrx22.H79_widening_assign(xrx22)) = " << xrx22Wxrx12 << std::endl;

  C_Polyhedron W12JW22=xrx22Wxrx12;
  W12JW22.poly_hull_assign_and_minimize(xrx12Wxrx22);
  std::cout << "W12JW22 = (poly hull of xrx22Wxrx12 and xrx12Wxrx22) = " << W12JW22 << std::endl;



  // 1:x.1.(2:rx)
  C_Polyhedron rx1(11);
  rx1.add_constraint_and_minimize(am2==1);
  rx1.add_constraint_and_minimize(am1==1);
  rx1.add_constraint_and_minimize(a0==2);
  rx1.add_constraint_and_minimize(m1==1);   
  rx1.add_constraint_and_minimize(m2==2);   
  std::cout << std::endl << "rx1 " << rx1 << std::endl;

  // 1:x.1.2.(3:rx)
  C_Polyhedron rx2(11);
  rx2.add_constraint_and_minimize(am3==1);
  rx2.add_constraint_and_minimize(am2==1);
  rx2.add_constraint_and_minimize(am1==2);
  rx2.add_constraint_and_minimize(a0==3);
  rx2.add_constraint_and_minimize(m1==2);   
  rx2.add_constraint_and_minimize(m2==3);   
  std::cout << "rx2 " << rx2 << std::endl;

  C_Polyhedron rx1Jrx2=rx2;
  rx1Jrx2.poly_hull_assign_and_minimize(rx1);
  std::cout << "rx1Jrx2 = (poly hull of rx1 and rx2) = " << rx1Jrx2 << std::endl;

  C_Polyhedron rx2Wrx1=rx1Jrx2;
  //Q2.BHRZ03_widening_assign(P0);
  rx2Wrx1.H79_widening_assign(rx2);
  std::cout << "rx2Wrx1 = (rx2Jrx1.H79_widening_assign(rx2)) = " << rx2Wrx1 << std::endl;



}



void boxes(){

  Z_Box box1(10);
  box1.add_constraint(Variable(0)==1);
  box1.add_constraint(Variable(1)==2);

  cout << "box1 " << box1 << endl;


  Z_Box box2(10, UNIVERSE);
  box2.add_constraint(Variable(1)==1);
  box2.add_constraint(Variable(2)==5);

  cout << "box2 " << box2 << endl;


  box2.intersection_assign(box1);

  cout << "box2 inter box1: " << box2 << endl;


}
*/

/*void preceq(){
  Constraint_System less;
  less.insert(Variable(0)<=Variable(5));
  less.insert(Variable(1)<=Variable(6));
  C_Polyhedron cless(less);
  ph2.add_space_dimensions_and_embed(10-cless.space_dimension());
  cmaUpwardRef preceq0(new pplUpward(cless));

  std::cout << "preceq0: " << preceq0 << std::endl;

  cmaUpwardRef preceq1=preceq0->constrainWith(cstr1);

  std::cout << "preceq1: preceq0 constrained by cstr1" 
	    << preceq1 << std::endl;


  std::cout << "upward closure of cstr1 with respect to preceq0 :" 
	    << std::endl;

  std::cout << preceq0->close(cstr1) << endl;

  std::cout << "upward closure of cstr1 with respect to preceq1 :" 
	    << std::endl;

  std::cout << preceq1->close(cstr1) << endl;


  std::cout << "upward closure of cstr2 with respect to preceq0 :" 
	    << std::endl;

  std::cout << preceq0->close(cstr2) << endl;

  std::cout << "upward closure of cstr2 with respect to preceq1 :" 
	    << std::endl;

  std::cout << preceq1->close(cstr2) << endl;

}

void rule(){


  Constraint_System rulecs;
  rulecs.insert(Variable(0) == 3);  rulecs.insert(Variable(1) == 4);
  rulecs.insert(Variable(2) == 4);  rulecs.insert(Variable(3) == 3);
  cmaRuleRef rule(new pplRule("the rule",C_Polyhedron(rulecs)));

  std::cout << "rule is : " 
	    << rule << std::endl;

  std::cout << "post of cstr2 with respect to rule :" 
	    << std::endl;

  std::cout << rule->post(cstr2) << endl;



}
*/

