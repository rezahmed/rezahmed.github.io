/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file cma_constraint.h
 * Header for an abstract constraint denoting a possibly infinite set of configurations of the system
 *
 * @author Rezine Ahmed
 */

#ifndef _CMA_CONSTRAINT_H
#define _CMA_CONSTRAINT_H

#include <iostream>
#include <stdlib.h>

#include "ref.h"
#include "minset.h"
#include "cma_order.h" 

class cmaConstraint;

typedef Ref<cmaConstraint> cmaConstraintRef;

class cmaSetConstraintRef 
: public MinSet<cmaConstraintRef, entailmentOrder <cmaConstraintRef> >
{
 public:
  inline bool doesIntersect(const cmaSetConstraintRef& set_cstr) const; 
};

class cmaConstraint
{

  public:

  virtual bool entails(const cmaConstraintRef& other)const=0;

  virtual cmaConstraintRef intersect(const cmaConstraintRef& other)const=0;

  bool doesIntersect(const cmaSetConstraintRef& set_cstr) const
  {
    for(cmaSetConstraintRef::const_iterator cstr=set_cstr.begin(); 
	cstr!=set_cstr.end(); ++cstr)
      {
	cmaConstraintRef candidate=intersect(*cstr);
	if(!candidate->isEmpty())
	  return true;
      }
    return false;
  };

  cmaSetConstraintRef intersect(const cmaSetConstraintRef& set_cstr) const
  {
    cmaSetConstraintRef result;
    for(cmaSetConstraintRef::const_iterator cstr=set_cstr.begin(); 
	cstr!=set_cstr.end(); ++cstr)
      {
	cmaConstraintRef candidate=intersect(*cstr);
	if(!candidate->isEmpty())
	  result.insert(candidate);
      }
    return result;
  };

  //  virtual void makeEmpty()=0;

  virtual bool isEmpty()const=0;

  friend std::ostream& operator<< 
    (std::ostream& out, const cmaConstraintRef& cstr);


  virtual ~cmaConstraint(){}

  unsigned constraintIdentifier;

  static unsigned constraintCounter;

  static unsigned numberOfSharedVariables;
  static unsigned numberOfLocalVariables;


 protected:

  virtual void printOn(std::ostream& o) const = 0;
};


bool cmaSetConstraintRef::doesIntersect(const cmaSetConstraintRef& set_cstr) const 
{
  for(cmaSetConstraintRef::const_iterator cstr=begin(); 
      cstr!=end(); ++cstr)
    {
      if((*cstr)->doesIntersect(set_cstr))
	return true;
    }
  return false;
};


inline std::ostream& operator<< 
(std::ostream& o, const cmaConstraintRef& cstr)
{
  cstr->printOn(o);
  return o;
}



#endif
