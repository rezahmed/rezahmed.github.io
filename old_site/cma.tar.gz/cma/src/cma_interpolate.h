/*
    Copyright (C) 2009 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <rezine.ahmed@gmail.com>  
*/


/** @file extrapolate.h
 *
 * @author Rezine Ahmed
 */

#ifndef _CMA_INTERPOLATE_H
#define _CMA_INTERPOLATE_H
#include <assert.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <ppl.hh>

#include "ref.h"
#include "cma_order.h"
#include "minset.h"
#include "cma_constraint.h"
#include "ppl_constraint.h"


using namespace std;

using namespace Parma_Polyhedra_Library;
using namespace Parma_Polyhedra_Library::IO_Operators;


class cmaInterpolate;

class cmaInterpolate
{

 public:  

  cmaInterpolate(){}
  ~cmaInterpolate(){}

  string get_csisat(const string& pre_str, const string& pos_str)
  {
  	string pre(pre_str), pos(pos_str);
  	int count = 0;
  	for(int i=0;i<pre.length();i++)
		if(pre[i]==',')
		{
			pre[i] = ';'; count++;
		}
	for(int i=0;i<pos.length();i++)
		if(pos[i]==',') pos[i] = ';';

	
	ostringstream qry;
	qry << "echo \""<< pre << "; " << pos 
			<< "\" | ./csisat -syntax infix | perl -ne 'if($i++=="
			<< count << "){chomp;print $_}' | sed 's/[)(\\.]//g'";
			
	string qry_str = qry.str();
	string itp_str;
	FILE *ptr;
	char line[1024];

	if((ptr = popen(qry_str.c_str(), "r")) == NULL)
	{
		perror("Couldn't open pipe");
	}	
	while (1)
	{
		if(fgets(line, 256, ptr) == NULL)
			break;
		itp_str += line;
	}
	fclose(ptr); 
	return itp_str;	
  }
  string get_clp(const string& pre_str, const string& pos_str)
  {
	string qry_str = "./clp-prover.run \"" + pre_str + "\" \"" + pos_str + "\"";
	string itp_str;
	FILE *ptr;
	char line[1024];

	if((ptr = popen(qry_str.c_str(), "r")) == NULL)
	{
		perror("Couldn't open pipe");
	}	
	while (1)
	{
		if(fgets(line, 256, ptr) == NULL)
			break;
		itp_str += line;
	}
	fclose(ptr); 
	return itp_str;	
  }
  
  static string get_cnst_str(const cmaSetConstraintRef& cscr)
  {
  	ostringstream ostr;
	ostr << cscr;
	string cstr = ostr.str();
	cstr.erase(cstr.length()-2).erase(0,2);
	int zb = cstr.find(':');
	if(zb!=string::npos) cstr.erase(0,zb+1);
	return cstr;
  }

  string get_itp_str(const string& pre, const string& pos)
  {
	string itp_type("clp");
  	char* env = getenv("ITP");
	if(env) itp_type = env;
  	string msg = "ITP_TYPE: "+itp_type;

	if(itp_type=="clp") return get_clp(pre,pos); 
	if(itp_type=="csisat") return get_csisat(pre,pos);
//	if(itp_type=="foci") return get_foci(pre,pos);
	cout << "ERROR: unknown ITP_TYPE! Termicate."<< endl;
	return get_clp(pre,pos);
  }

  cmaConstraintRef* get_itp(const string& pre, const string& pos)
  {
  	return itp_from_str(get_itp_str(pre,pos));
  }

  cmaConstraintRef* itp_from_str(const string& itp_str)
  {
  	 Constraint* cnstc = cnst_from_str(itp_str);
	 assert(cnstc!=NULL);

	 Constraint_System cs1;
	 Constraint_System cs2;

	 cs2.insert(*cnstc);

	 Z_Box zbox(cs1);
	 C_Polyhedron cpoly(cs2);

 	 int shared=cmaConstraint::numberOfSharedVariables;
	 int local=cmaConstraint::numberOfLocalVariables;
 
	 cpoly.add_space_dimensions_and_embed(local - cpoly.space_dimension());
         zbox.add_space_dimensions_and_embed(shared - zbox.space_dimension());

	 pplConstraint* pplc = new pplConstraint(zbox, cpoly);	
	 cmaConstraintRef* cnst = new cmaConstraintRef(pplc);
	 //cout << endl << "ITP: " << *cnst << endl;

	 return cnst;
  }

  static void normalize_cnst_str(string& cnst_str)
  {
	const int NUM_OP = 5;
	const char ops[NUM_OP][5] = {"+","-",">=","=<","="};
	for(int i=0;i<NUM_OP;i++)
	{
		int j = 0;
		while(1){
			string::size_type pos = cnst_str.find(ops[i],j);
			if(pos==string::npos) break;
			j = pos+1;
			if(cnst_str[pos-1]==' ' 
			|| cnst_str[pos+1]==' '
			|| (ops[i][0]=='-' && (!pos || (cnst_str[pos-1]==' ')))
			) continue;
			cnst_str.insert(pos+strlen(ops[i])," ");
			cnst_str.insert(pos," ");
			
		}
	}
	int i = 0, j = cnst_str.length();
	while(cnst_str[i++]==' ');
	while(cnst_str[--j]==' ');
	cnst_str = cnst_str.substr(i-1,j-i+2);
  }
  static Constraint* cnst_from_str(const string& _cnst_str)
  {
  	istringstream in;
	string cnst_str(_cnst_str);
	string token,op,cmpr;
	Linear_Expression* left = NULL;
	Linear_Expression* right = NULL;
	Linear_Expression* lhs = NULL;
	Linear_Expression* rhs = NULL;
	Constraint* cnstc = NULL;

	normalize_cnst_str(cnst_str);	
	//cout << "NOTICE: cnst_str after normalization: '"<<cnst_str<<"'"<<endl;
	in.clear();
	in.str(cnst_str.c_str());
	string CMPR("<>=");
	string OP("+-");
	
	while(in >> token >> ws){
		//cout << "TOKEN: "<<token<<endl;
		if(CMPR.find(token[0])!=string::npos){
			cmpr = token; 
			//cout<<"CMPR: "<<cmpr<<endl;
			if(left && !lhs) lhs = left;
		}else
		if(OP.find(token[0])!=string::npos && token.length()==1){
			op = token;
		}else
		if(cmpr.empty()){
			if(!op.empty())
			{
				right = get_term(token,left,NULL);
				//cout << "RIGHT: "<<*right<<endl;
	
				if(!left && lhs){
					lhs = get_exp(*lhs, op, *right);
					//cout<<"LHS: "<<*lhs<<endl;
				}
				if(!lhs && left){
					lhs = get_exp(*left, op, *right);
					//cout<<"LHS: "<<*lhs<<endl;
					left = right = NULL;
				}	
				op = "";
			}else{
				left = get_term(token,NULL,NULL);
				//cout << "LEFT: "<<*left<<endl;
			}
		}else{
			if(!op.empty())
			{
				right = get_term(token,left,lhs);
				//cout << "RIGHT: "<<*right<<endl;
	
				if(!left && rhs){
					rhs = get_exp(*rhs, op, *right);
					//cout<<"RHS: "<<*lhs<<endl;
				}
				if(!rhs && left){
					rhs = get_exp(*left, op, *right);
					//cout<<"RHS: "<<*lhs<<endl;
					left = right = NULL;			
				}
				op = "";
			}else{
				left = get_term(token,NULL,lhs);
				//cout << "LEFT: "<<*left<<endl;	
			}
 		}
		if(in.eof()){ 
			if(left && !rhs) rhs = left;
			if(lhs&&rhs)
			{
				cnstc = get_cnst(*lhs, cmpr, *rhs);
				//cout<<"ITPC: "<<*cnstc<<endl;
				break;
			}else
				perror("get_interpolant: illegal cnst_str");
			break;
		}
	}

	 return cnstc;
  }

 protected:
 
  static Linear_Expression* get_exp(const Linear_Expression& left, const string& op, const Linear_Expression& right)
  {
  	Linear_Expression* exp = NULL;
  	if(op=="+") exp = new Linear_Expression(left + right); else
	if(op=="-") exp = new Linear_Expression(left - right); else
	//if(op=="*") exp = new Linear_Expression(left * right); else
	//if(op=="/") exp = new Linear_Expression(left / right); else
	{
		cout << "get_exp: Bad operator '" << left <<" "<< op <<" "<< right <<"'" << endl;
	}
	return exp;
  }
  static Constraint* get_cnst(const Linear_Expression& lhs, const string& cmpr, const Linear_Expression& rhs)
  {
  	Constraint* cnst = NULL;
  	     if(cmpr=="=") cnst = new Constraint(lhs == rhs); else
	     if(cmpr=="=<") cnst = new Constraint(lhs <= rhs); else
	     if(cmpr=="<=") cnst = new Constraint(lhs <= rhs); else
	     if(cmpr==">=") cnst = new Constraint(lhs >= rhs); else
	     if(cmpr=="=>") cnst = new Constraint(lhs >= rhs); else
	     {
	     	cout << "get_cnst: Bad comparator [" << lhs <<"] ["<< cmpr <<"] ["<< rhs <<"]" << endl;
	     }
	return cnst;
  }
  static Linear_Expression* get_term(const string& term_str, Linear_Expression* e1, Linear_Expression* e2)
  {
	Linear_Expression* term = NULL;

  	int i = (term_str[0]=='+' || term_str[0]=='-');

	while(isdigit(term_str[i])) i++;

	if(i>=term_str.length())
		term = new Linear_Expression(atoi(term_str.c_str()));
	else
	if(i && term_str[i]=='*')
	{
		int coeff = atoi(term_str.substr(0,i).c_str());
		term = new Linear_Expression(coeff * Variable(
		pplConstraint::dimensionOfLocalName.find(term_str.substr(i+1))->second));
	}else
	if(i && term_str[i]=='/') // ex. 2/3*sread >= count --> 2*sread >= 3*count
	{
		int j = i+1;
		while(isdigit(term_str[j])) j++;
		assert(term_str[j]=='*');

		int n = atoi(term_str.substr(0,i).c_str());
		int m = atoi(term_str.substr(i+1,j-i-1).c_str());

		if(e1) *e1 *= m;
		if(e2) *e2 *= m;
		term = new Linear_Expression(n * Variable(
		pplConstraint::dimensionOfLocalName.find(term_str.substr(j+1))->second));
	}else
	  {
		term = new Linear_Expression(Variable(
		pplConstraint::dimensionOfLocalName.find(term_str)->second));
	  }
	assert(term!=NULL);
	return term;
  }
};



#endif
