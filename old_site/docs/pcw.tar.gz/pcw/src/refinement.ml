
open Printf

exception Reachable of Dated_constraint.t
exception Not_reachable 
exception Interpolated of int Counters.MP.t

let debug  = Debug.refinement
let debug_long = Debug.refinement_long

module S = Minset.MinSet(Constraint)

let meet sigma a b = 
  let _,minset = S.insert_list_in_minset S.empty (Constraint.meet sigma a b)
  in S.to_list minset

let meet_lists sigma a b = 
  let minset = 
    List.fold_left ( 
      fun acca ae ->
	List.fold_left ( 
	  fun accb be ->
	    let _,result = S.insert_list_in_minset accb (Constraint.meet sigma ae be)
	    in result 
	) acca b
    ) S.empty a
  in S.to_list minset


exception Refinement_do_meet
let do_meet_lists sigma left right = 
  try 
    List.iter ( 
      fun l -> 
	List.iter (
	  fun r ->
	    if Constraint.do_meet sigma l r
	    then raise Refinement_do_meet
	) right
    ) left;
    false
  with 
    | Refinement_do_meet -> true
  

let separate sigma plus minus precision =   
  let abstraction = fun c ->  (Constraint.gamma_counters_cut_off_with_letterwise_max_precision c precision) in
    begin 
      if debug_long
      then begin
	let _plus = List.fold_left (fun acc e -> sprintf "%s %s" acc (Constraint.string_of e)) "" plus in
	let _minus = List.fold_left (fun acc e -> sprintf "%s %s" acc (Constraint.string_of e)) "" minus in
	let _approx = List.fold_left (fun acc e -> sprintf "%s %s" acc (Constraint.string_of (abstraction e))) "" plus in
	let _precision = Counters.MP.fold (fun key bound acc -> sprintf "%s %s->%d" acc (Letter.string_of key) bound) precision ""  in
	let oups = (sprintf "\n\nSeparating\n plus -> %s\n minus: ->%s\n approx:  ->%s\n with precision:\n ->%s\n\n" 
		      _plus _minus _approx _precision) 
	in printf "%s" oups
      end;

      let collection = 
	List.fold_left ( fun accp p ->
			   List.fold_left ( fun accm m ->
					      assert(not(Constraint.do_meet sigma p m));
					      if debug_long then printf "\np:%s\nm:%s" (Constraint.string_of p) (Constraint.string_of m);
					      if (Constraint.do_meet sigma (abstraction p) m)
					      then begin
						let mpcollect = Collection.percolate 
						  (Constraint.collect sigma ~exact:p ~approximated:(abstraction p) ~target:m) 
						in (* if debug  *)
(* 						  then begin printf " intersect because : mpcollect: %s \n\n"  *)
(* 						      (Collection.string_of mpcollect) end; *)
						  Collection.build_and [accm; mpcollect]
					      end
					      else begin
						if debug_long 
						then begin 
						  printf "do not intersect\n" 
						end; 
						accm
					      end
					  ) accp minus
		       ) Collection.true_leaf plus
      in 
      let to_be_augmented = Collection.extract_precision (Collection.percolate collection) in 
      let new_precision = Power_domain.fold (fun key acc -> 
					       let old_bound = 
						 try (Counters.MP.find key precision - 1)
						 with | Not_found -> failwith("partial precision !")
					       in let new_bound = 
						   try Counters.MP.find key to_be_augmented
						   with | Not_found -> -1 
					       in Counters.MP.add key ((max old_bound new_bound)+1) acc) Counters.MP.empty sigma 
      in if debug_long 
	then begin
	  printf "\n\n new precision : %s\n" (Counters.MP.fold (
					   fun key bound acc -> 
					     sprintf "%s %s->%d" acc (Letter.string_of key) bound) new_precision "");
	end;
	raise (Interpolated new_precision)
    end






let parse_trace sigma tr fetch_rule =
  let f r = ( fun direction target -> let post =
		List.fold_left (
		  fun acc xe ->
		    let im = (Arule.next sigma direction (fetch_rule r) (Dated_constraint.Original(xe)))
		    in let _,ims  = S.insert_list_in_minset acc (List.fold_left (fun acc e -> (Dated_constraint.get_head e)::acc) [] im)
		    in  ims ) S.empty target
	      in S.to_list post) 
  in let rec parse_history hist =
      match hist with
	| [] -> failwith("Should not get here when parsing the trace")
	| [(r,c)] -> ([c],[(f r)])
	| (r,c)::tl -> let csts,rls = parse_history tl 
	  in (c::csts,(f r)::rls)
  in match tr with
    | Dated_constraint.Original head -> ([head],[])
    | Dated_constraint.History (head, history) ->
	let cstrs, rules= parse_history history
	in (head::cstrs, rules)
	     

let simulate_trace sigma mode trace cstrs rules seed target precision =
  if debug_long
  then printf "about to simulate trace: \n   -> %s\nwith constraints:\n   -> %s\nand seed: \n   -> %s\nand target: \n   -> %s\n and precision:\n   -> %s\n" (Dated_constraint.verbose_string_of trace) (List.fold_left (fun acc e -> sprintf "%s %s" acc (Constraint.string_of e)) "" cstrs) (List.fold_left (fun acc e -> sprintf "%s %s" acc (Constraint.string_of e)) "" seed) (List.fold_left (fun acc e -> sprintf "%s %s" acc (Constraint.string_of e)) "" target) (Counters.MP.fold (fun key bound acc -> sprintf "%s %s->%d" acc (Letter.string_of key) bound) precision "");
  let abstraction = fun x -> List.fold_left
    (fun acc c ->
       (Constraint.gamma_counters_cut_off_with_letterwise_max_precision c precision)::acc) [] x in
  let other_mode = match mode with | Constraint.Pre -> Constraint.Post | Constraint.Post -> Constraint.Pre in 
  let rec simulate e0 cs rs =
    match cs,rs with
      | [],[] -> if do_meet_lists sigma e0 seed
	then raise (Reachable trace)
	else begin assert(do_meet_lists sigma (abstraction seed) e0); separate sigma seed e0 precision end
      | c1::tlc, r01::tlr -> begin
	  let e1 = meet_lists sigma (r01 other_mode e0) [c1] in
	  match e1 with
	    | [] -> assert (not(do_meet_lists sigma ((r01 mode [c1])) e0)) ; 
		separate sigma (r01 mode [c1]) e0 precision
	    | _ ->  simulate e1 tlc tlr
	end
      | _ -> failwith("simulate should not get here")
  in
    match cstrs with
      | hd::tl -> assert(do_meet_lists sigma [hd] target); simulate (meet_lists sigma [hd] target) tl rules
      | _ -> failwith("simulate trace should not get here")
	  
	  

let analyze_trace sigma mode trace seed target fetch_rule precision = 
  printf "\ngot trace: %s \n" (Dated_constraint.verbose_string_of trace);
  let _seed = List.fold_left (fun acc e -> (Dated_constraint.get_head e)::acc) [] seed in
  let _target = List.fold_left (fun acc e -> (Dated_constraint.get_head e)::acc) [] target in
  let cstrs, rules = parse_trace sigma trace fetch_rule in
    simulate_trace sigma mode trace cstrs rules _seed _target precision
  

let started = ref 0.

let rec refinement_loop sigma mode initials meet_init next bads meet_bad fetch_rule precision fixpoint_cut_off = 
  let loop _precision = begin
    let abstraction = fun c ->  (Dated_constraint.gamma_counters_cut_off_with_letterwise_max_precision c _precision)  in
    let seed,meet_target,target = match mode with 
      | Constraint.Post -> initials, meet_bad,bads
      | Constraint.Pre -> bads, meet_init,initials
    in
      started := Sys.time (); 
      let trace = Fixpoint.run ~init:seed ~next:(next mode) ~gamma:abstraction ~stop:meet_target  ~fixpoint_cut_off:fixpoint_cut_off  
      in printf "\nReachability analysis with precision: \"%s\" \n" (Counters.MP.fold (fun key bound acc -> sprintf "%s %s->%d" acc (Letter.string_of key) bound) _precision "");
	printf "required %f seconds" 
	   (Sys.time () -. !started);
	printf " and generated %d counted word\n\n" 
	  (!Debug.number_of_constraints);
	Debug.number_of_constraints := 0;
	match trace with 
	  | [] -> raise Not_reachable
	  | [tr] -> analyze_trace sigma mode tr seed target fetch_rule precision
	  | _ -> failwith("fixpoint should return at most one constraint")
  end in try 
      loop precision
    with | Interpolated new_precision -> refinement_loop sigma mode initials meet_init next bads meet_bad fetch_rule new_precision fixpoint_cut_off
      
	
