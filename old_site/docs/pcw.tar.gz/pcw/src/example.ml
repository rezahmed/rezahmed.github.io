open Printf

module type Ex =
  sig
    val name: string
    val transformers: Transformer.t list
  end

module Simple : Ex = 
struct
  let name = "simple"
  let transformers = 
    let a = Power_domain.LS.singleton (Letter.create "a") in
    let b = Power_domain.LS.singleton (Letter.create "b") in
    let pa = Power_domain.create_from_set a in
    let pb = Power_domain.create_from_set b in
    let pab = Power_domain.join pa pb in
    [Transformer.from_local(Local_transformer.create pb pab)] 
end


module Complex : Ex =
struct
  let name = "complex"
  let transformers =
    let a = Power_domain.LS.singleton (Letter.create "a") in
    let b = Power_domain.LS.singleton (Letter.create "b") in
    let c = Power_domain.LS.singleton (Letter.create "c") in
    let pa = Power_domain.create_from_set a in
    let pb = Power_domain.create_from_set b in
    let pc = Power_domain.create_from_set c in
      [Transformer.from_local (Local_transformer.create pa pb);
     Transformer.from_universal_left (Universal_transformer.create pb pc pa)]
end



