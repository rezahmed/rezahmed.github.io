
open Printf

type t = string

let create s = s

let string_of s = s

let compare a b = String.compare a b 


