

open Printf

module D = Power_domain 
module C = Constraint



let debug = Debug.dated_constraint
let debug_long = Debug.dated_constraint_long


type t = Original of C.t 
	 | History of (C.t * ((string * C.t) list))


let get_head dcstr =  match dcstr with 
  | Original(cstr)  -> cstr
  | History(cstr,history) -> cstr

let bottom = Original(C.bottom)

let top = Original(C.top)

let is_bottom dcstr = C.is_bottom (get_head dcstr)

let is_top dcstr = C.is_top (get_head dcstr)

let from_context_and_base sigma context base = 
  Original(C.from_context_and_base sigma context base)

let verbose_string_of dcstr = match dcstr with
  | Original(cstr) -> C.string_of cstr
  | History(cstr,history) -> 
      sprintf "\n{{%s %s}}\n" (C.string_of cstr)
	(List.fold_left (fun acc (r,c) -> sprintf "%s --> %s --> %s" 
			acc r (C.string_of c)) "" history)

let string_of dcstr = match dcstr with
  | Original(cstr) -> sprintf "%s\n" (C.string_of cstr)
  | History(cstr,history) -> sprintf "%s\n" (C.string_of cstr)



let entailed ~weak ~strong = 
  C.entailed (get_head weak) (get_head strong)

let local sigma prepost dcstr guard action arule_name = 
  match dcstr with 
    | Original cstr -> let result =  Constraint.local sigma prepost cstr guard action in 
	List.fold_left (fun acc e -> (History(e, [(arule_name,cstr)]))::acc ) [] result
    | History(cstr,history) -> let result = Constraint.local sigma prepost cstr guard action in 
	List.fold_left (fun acc e -> (History(e, (arule_name,cstr)::history))::acc ) [] result

let exists sigma prepost dcstr guard action witness priority arule_name = 
  match dcstr with 
    | Original cstr -> let result =  Constraint.exists sigma prepost cstr guard action witness priority in 
	List.fold_left (fun acc e -> (History(e, [(arule_name,cstr)]))::acc ) [] result
    | History(cstr,history) -> let result = Constraint.exists sigma prepost cstr guard action witness priority in 
	List.fold_left (fun acc e -> (History(e, (arule_name,cstr)::history))::acc ) [] result



let universal sigma prepost dcstr guard action gguard priority arule_name = 
  match dcstr with 
    | Original cstr -> let result =  Constraint.universal sigma prepost cstr guard action gguard priority in 
	List.fold_left (fun acc e -> (History(e, [(arule_name,cstr)]))::acc ) [] result
    | History(cstr,history) -> let result = Constraint.universal sigma prepost cstr guard action gguard priority in 
	List.fold_left (fun acc e -> (History(e, (arule_name,cstr)::history))::acc ) [] result


let max_weight = C.max_weight

let weight dcstr = 
  C.weight (get_head dcstr) 

let gamma_counters_cut_off_with_uniform_max_precision dcstr _max_precision = 
  match dcstr with 
    | Original cstr -> Original(C.gamma_counters_cut_off_with_uniform_max_precision cstr _max_precision)
    | History(cstr,history) -> History(C.gamma_counters_cut_off_with_uniform_max_precision cstr _max_precision, history)

let gamma_counters_cut_off_with_letterwise_max_precision dcstr _letterwise_max_precision = 
  match dcstr with 
    | Original cstr -> Original(C.gamma_counters_cut_off_with_letterwise_max_precision cstr _letterwise_max_precision)
    | History(cstr,history) -> History(C.gamma_counters_cut_off_with_letterwise_max_precision cstr _letterwise_max_precision, history)

let do_meet sigma dcstr1 dcstr2 = C.do_meet sigma (get_head dcstr1) (get_head dcstr2)

let base_length t =  C.base_length (get_head t)
 
