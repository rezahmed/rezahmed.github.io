
open Printf

module MP = Map.Make(struct type t = Letter.t let compare = Letter.compare end) 

module SL = Map.Make(struct type t = Letter.t let compare = Letter.compare end) 

type predicate = Eq of int | Geq of int

type t = predicate MP.t

let debug_long = Debug.counters_long

let print_eq_zero = true
let print_geq_zero = false

let string_of c = 
  let print_predicate _key _predicate space = 
    match _predicate with
      | Eq(i) when (print_eq_zero || not(i=0)) -> sprintf "%s%s=%d" (if space then " " else "") (Letter.string_of _key) i
      | Geq(i) when (print_geq_zero || not(i=0)) -> sprintf "%s%s~%d" (if space then " " else "") (Letter.string_of _key) i
      | _ -> ""
  in
  let (s,_) = MP.fold (fun k d (acc,j) -> 
			  if (j=1)
			  then ((sprintf "%s%s|" acc (print_predicate k d (not(acc="|")) )),j-1)
			  else ((sprintf "%s%s" acc (print_predicate k d (not(acc="|")) )),j-1))  c ("|",MP.cardinal c)
    in s


let zero sigma  =
  Power_domain.fold (fun e acc -> 
		       MP.add e (Eq(0)) acc ) MP.empty sigma

let largest sigma =
  Power_domain.fold (fun e acc -> 
		       MP.add e (Geq(0)) acc ) MP.empty sigma

let inc _counter _key = try match MP.find _key _counter with
  | Eq(i) -> MP.add _key (Eq(i+1)) _counter
  | Geq(i) -> MP.add _key (Geq(i+1)) _counter
with Not_found -> failwith("inc: cannot manipulate a letter that was not added")


let restrict_to_zero _counter _key = try match MP.find _key _counter with
  | Eq(i) when i=0 -> MP.add _key (Eq(0)) _counter
  | Geq(i) when i=0 -> MP.add _key (Eq(0)) _counter
  | _ -> failwith("meet zero cannot apply ")
with Not_found -> failwith("meet zero: cannot manipulate a letter that was not added")

 exception Not_compatible_empty
 let compatible_empty _counter _d = 
   try Power_domain.iter (fun _key -> 
		 try match MP.find _key _counter with 
		   | Eq(i) when i>0 -> raise Not_compatible_empty 
		   | Geq(i) when i>0 -> raise Not_compatible_empty 
		   | _ -> () 
		 with Not_found -> failwith("compatible_empty: cannot manipulate a letter that was not added")
	      ) _d; true
   with Not_compatible_empty -> false




 (* exception Decing_zero *)
 let dec _counter _key = match MP.find _key _counter with 
 (*   | Eq(i) when i=0 -> raise Decing_zero  *)
  | Eq(i)  -> MP.add _key (Eq(i-1)) _counter
  | Geq(i) -> MP.add _key (Geq(max 0 (i-1))) _counter

 let level_up counter level = 
  MP.fold (fun _key _predicate acc -> try 
	     match _predicate, MP.find _key level with
	       | Geq(i), Eq(i') -> MP.add _key (Geq((max i i'))) acc
	       | _ -> MP.add _key _predicate acc
	   with Not_found -> failwith("all counters should have the same Sigma as keys")) counter MP.empty  
   

let dec_positive _counter _key = 
(*   | Eq(i) when i=0 -> raise Decing_zero  *)
let result = match MP.find _key _counter with 
  | Eq(i)   -> MP.add _key (Eq((max 0 (i-1)))) _counter
  | Geq(i) -> MP.add _key (Geq((max 0 (i-1)))) _counter
in if debug_long
  then printf "\ndec_positive: _counter:%s, _key:%s, gives:%s\n" 
    (string_of _counter) (Letter.string_of _key) (string_of result); 
  result

let allows _counter _key = 
(*   printf "allows %s\n" (string_of _counter); *)
  try match MP.find _key _counter with
    | Eq(i) when i=0 -> false
    | Eq(i) when i>0 -> true
    | Geq(i) when i>=0 -> true
    | _ -> failwith("negative counter !")
  with Not_found -> failwith("something is wrong with the alphabet")

let largely_allows _counter _key = 
(*   printf "allows %s\n" (string_of _counter); *)
  try match MP.find _key _counter with
    | Eq(i) when i>=0 -> false
    | Geq(i) when i>=0 -> true
    | _ -> failwith("negative counter !")
  with Not_found -> failwith("something is wrong with the alphabet")
    

exception Do_not_meet
let do_meet ca cb =
  assert(MP.cardinal ca = MP.cardinal cb);
  try
    MP.iter (fun _key _predicate -> try 
	       match _predicate, MP.find _key cb with
		 | Eq(i), Eq(i') when not(i=i') -> raise Do_not_meet 
		 | Eq(i), Geq(i') when i'>i -> raise Do_not_meet 
		 | Geq(i), Eq(i') when i>i' -> raise Do_not_meet
		 | _ -> () 
	     with Not_found -> failwith("all counters should have the same Sigma as keys")) ca; true
  with Do_not_meet -> false



(* assumes low and high do not meet and relaxing low makes it meet high *)
let equalities_in_low_that_need_to_be_relaxed_to_meet_high ~(low:t) ~(high:t) =
  if false
  then printf "\nlow :%s\nhigh:%s\n" (string_of low) (string_of high);
  assert(MP.cardinal low = MP.cardinal high);
  MP.fold (fun _key _predicate acc -> 
	     try 
	       match _predicate, MP.find _key high with
		 | Eq(i), Eq(i') when i'>i -> (_key,i)::acc
		 | Eq(i), Eq(i') when i'=i -> acc
		 | Eq(i), Geq(i') when i'>i -> (_key,i)::acc
		 | Eq(i), Geq(i') when i'=i -> acc
		 | Geq(i), Geq(i') when i'=i -> acc
		 | _ -> printf "low %s was not lower than high %s" (string_of low) (string_of high); failwith("low high problem")
	     with Not_found -> failwith("all counters should have the same Sigma as keys")
	  ) low []
      
let equalities_that_need_to_be_relaxed_to_allow_letter counter key = 
  try match MP.find key counter with 
    | Eq(i) when i>=0 -> [(key,i)]
    | _ -> []
  with Not_found -> failwith("reasons for not allowing says something is wrong with the alphabet")


let add ca cb = 
  assert(MP.cardinal ca = MP.cardinal cb);
  MP.fold (fun _key _predicate acc -> try 
	     match _predicate, MP.find _key cb with
	       | Eq(i), Eq(i') -> MP.add _key (Eq(i+i')) acc
	       | Eq(i), Geq(i') -> MP.add _key (Geq(i+i')) acc
	       | Geq(i), Eq(i') -> MP.add _key (Geq(i+i')) acc
	       | Geq(i), Geq(i') -> MP.add _key (Geq(i+i')) acc
	   with Not_found -> failwith("all counters should have the same Sigma as keys")) ca MP.empty  


let add_positive ca cb = 
  assert(MP.cardinal ca = MP.cardinal cb);
  let result = 
    MP.fold (fun _key _predicate acc -> try 
	       match _predicate, MP.find _key cb with
		 | Eq(i), Eq(i') -> MP.add _key (Eq((max 0 (i+i')))) acc
		 | Eq(i), Geq(i') -> MP.add _key (Geq((max 0 (i+i')))) acc
		 | Geq(i), Eq(i') -> MP.add _key (Geq((max 0 (i+i')))) acc
		 | Geq(i), Geq(i') -> MP.add _key (Geq((max 0 (i+i')))) acc
	     with Not_found -> failwith("all counters should have the same Sigma as keys")) ca MP.empty  
  in if debug_long 
    then printf "positive adding ca=%s and cb=%s gives %s \n" (string_of ca) (string_of cb) (string_of result); 
    result




let join ca cb = 
  assert(MP.cardinal ca = MP.cardinal cb);
  MP.fold (fun _key _predicate acc -> try 
	     match _predicate, MP.find _key cb with
	       | Eq(i), Eq(i') -> MP.add _key (Eq((min i i'))) acc
	       | Eq(i), Geq(i') -> MP.add _key (Geq((min i i'))) acc
	       | Geq(i), Eq(i') -> MP.add _key (Geq((min i i'))) acc
	       | Geq(i), Geq(i') -> MP.add _key (Geq((min i i'))) acc
	   with Not_found -> failwith("all counters should have the same Sigma as keys")) ca MP.empty  

let meet ca cb = 
  assert(MP.cardinal ca = MP.cardinal cb);
  MP.fold (fun _key _predicate acc -> try 
	     match _predicate, MP.find _key cb with
	       | Eq(i), Eq(i') when i=i' -> MP.add _key (Eq(i)) acc
	       | Eq(i), Geq(i') when i>=i' -> MP.add _key (Eq(i)) acc
	       | Geq(i), Eq(i') when i'>=i -> MP.add _key (Eq(i')) acc
	       | Geq(i), Geq(i') -> MP.add _key (Geq((max i i'))) acc
	       | _ -> failwith((sprintf "Counters' meet does not return bottom in %s meets %s" (string_of ca) (string_of cb))) 
	   with Not_found -> failwith("all counters should have the same Sigma as keys")) ca MP.empty  





exception Do_not_entailed
let entailed weak strong =
  assert(MP.cardinal weak = MP.cardinal strong);
  try
    MP.iter (fun _key _predicate -> try 
	       match _predicate, MP.find _key strong with
		 | Eq(i), Eq(i') when not(i=i') -> raise Do_not_entailed 
		 | Eq(i), Geq(i')  -> raise Do_not_entailed
		 | Geq(i), Eq(i') when i>i' -> raise Do_not_entailed
		 | Geq(i), Geq(i') when i>i' -> raise Do_not_entailed
		 | _ -> () 
	     with Not_found -> failwith("all counters should have the same Sigma as key")) weak; true
  with Do_not_entailed -> false



(** Used on ordered counters weaker and stronger. 
    Ordered means: 
     * weaker entailed by stronger, and 
     * there is no counter entailing weaker with one component strictly smaller than the corresponding component in stronger. 
    Returns the largest counter' such that counter'+stronger still entails weaker.   
*)
let ordered_difference weaker stronger = 
  assert(entailed weaker stronger);
  MP.fold (fun _key _predicate acc -> try 
	     match _predicate, MP.find _key stronger with
	       | Eq(i), Eq(i') when i=i' -> MP.add _key (Eq(0)) acc
	       | Geq(i), Eq(i') when i=i' -> MP.add _key (Geq(0)) acc 
	       | Geq(i), Geq(i') when i=i' -> MP.add _key (Geq(0)) acc
	       | _ ->  failwith((sprintf "invalid input for ordered_difference %s - %s!" (string_of weaker) (string_of stronger)))
	   with Not_found -> failwith("all counters should have the same Sigma as keys")) weaker MP.empty  
  



let make_weak _counter _key = try match MP.find _key _counter with
  | Eq(i) -> MP.add _key (Geq(i)) _counter
  | Geq(i) -> MP.add _key (Geq(i)) _counter
with Not_found -> failwith("can not manipulate a letter that was not added")

let contagious_relaxation _counter _source _destination = 
  try match MP.find _source _counter with
      | Eq(i) -> _counter
      | Geq(i) -> begin
	  match MP.find _destination _counter with
	    | Eq(j) -> MP.add _destination (Geq(j)) _counter 
	    | _ -> _counter
	end
  with Not_found -> failwith("something is seriously wrong with the alphabet") 

  
let weaken_counter_wrt_context _counter _context =
  Power_domain.fold (fun _key acc -> make_weak acc _key) _counter _context 

let cut_off_with_uniform_max_precision _counter _max_precision = 
  MP.fold (fun _key _predicate acc -> match _predicate with
	     | Eq(i) when i>=_max_precision -> MP.add _key (Geq(i)) acc
	     | _ -> MP.add _key _predicate acc ) _counter MP.empty


let cut_off_with_letterwise_max_precision _counter _letterwise_max_precision = 
  MP.fold (fun _key _predicate acc -> 
	     let bound = try MP.find _key _letterwise_max_precision with Not_found -> 0
	     in match _predicate with
		 | Eq(i) when i>=bound -> MP.add _key (Geq(i)) acc
		 | _ -> MP.add _key _predicate acc 
	  ) _counter MP.empty
    
let find_letterwise_cut_off_targets _counter _letterwise_max_precision =
  MP.fold (fun _key _predicate _acc -> 
	     let bound = try MP.find _key _letterwise_max_precision with Not_found -> 0
	     in match _predicate with 
	       | Eq(i) when i>=bound -> MP.add _key i _acc
	       | _ -> _acc) _counter MP.empty
