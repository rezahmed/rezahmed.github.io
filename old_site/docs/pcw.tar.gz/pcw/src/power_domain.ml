
open Printf

module LS = Set.Make(struct type t = Letter.t let compare = Letter.compare end)

type t = Bot | Top | Element of LS.t

let fold (f: LS.elt -> 'a -> 'a) (acc:'a) (d:t) =
  match d with
    | Bot -> failwith("Bottom power domains are not to be folded")
    | Top -> failwith("Top power domains are not to be folded")
    | Element(s) -> LS.fold f s acc 

let iter (f: LS.elt -> unit) (d:t) =
  match d with
    | Bot -> failwith("Bottom power domains are not to be iterated")
    | Top -> failwith("Top power domains are not to be iterated")
    | Element(s) -> LS.iter f s  


let well_formed t =
  match t with 
    | Element(ps) when LS.is_empty ps -> false
    | _ -> true

let create_from_set a = 
  assert(not (LS.is_empty a));
  Element(a)

let create_from_letter a = 
  Element(LS.singleton(a))

let difference (plus:t) (minus:t)  =
  match plus, minus with
    | Element(ps),Element(ms) -> Element(LS.filter (fun e -> not(LS.mem e ms)) ps)
    | _ -> failwith("might need to be implemented")

let string_of t = begin
  assert(well_formed t);
  match t with
    | Bot -> "_"
    | Top -> "T"
    | Element(elts) -> 
	let list = LS.elements elts in
	let rec append acc l =
	  match l with
	    | []   -> sprintf "%s>" acc
	    | hd::tl -> let acc'=sprintf "%s,%s" acc (Letter.string_of hd) in append acc' tl
	in
	  match list with
	    | [] -> failwith("empty non bot list")
	    | [hd] -> sprintf "<%s>" (Letter.string_of hd)
	    | hd::tl -> sprintf "<%s%s" (Letter.string_of hd) (append "" tl)
end

let member letter t = match t with 
  | Bot -> false
  | Top -> true
  | Element(elts) -> LS.mem letter elts 

let bottom = Bot

let top = Top 

let is_bottom t = begin 
  assert(well_formed t);
  match t with 
    | Bot -> true
    | _ -> false
end

let is_top t = begin
  assert(well_formed t);
  match t with 
  | Top -> true
  | _ -> false
end


let meet l1 l2 = begin 
  match l1 , l2 with
    | Bot, _   -> Bot
    | _  , Bot -> Bot
    | Top, _   -> l2
    | _  , Top -> l1
    | Element e1 , Element e2 -> let inter = LS.inter e1 e2 in
	if LS.is_empty inter then Bot
	else Element(inter)
end

let join l1 l2 = begin 
  match l1 , l2 with
    | Top , _  -> Top
    | _ , Top  -> Top
    | _ , Bot -> l1
    | Bot , _ -> l2
    | Element e1 , Element e2 -> let inter = LS.union e1 e2 in
	Element(inter)
end
 
let is_not_bottom t = not(is_bottom t)  

let do_meet l1 l2 = is_not_bottom (meet l1 l2)   

let entailed a b = 
  match a,b with
    | Top,_   -> true
    | Element sa, Top -> false (* we assume Sigma includes a symbol that is never used ! *)
    | Element sa, Element sb -> LS.subset sb sa
    | Element sa, Bot -> true 
    | Bot, Bot -> true
    | Bot, _ -> false


