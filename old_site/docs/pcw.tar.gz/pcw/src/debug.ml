
let minset = false

let arule = false

let fixpoint = true
let fixpoint_long = false

let constraint_long = false
let constraint_entail = false
let constraint_meet = false
let constraint_collect = false

let number_of_constraints = ref 0

let dated_constraint = false
let dated_constraint_long = false

let refinement = true
let refinement_long = false

let counters_long = false 

let print args = Printf.kfprintf flush stdout args
