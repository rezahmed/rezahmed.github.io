

open Printf

module D = Power_domain 

module C = Counters

let debug_entail = Debug.constraint_entail
let debug_meet = Debug.constraint_meet
let debug_collect = Debug.constraint_collect

let debug_long = Debug.constraint_long


type prepost = Pre | Post

type priority = Left | Right | LeftRight

type al = C.t * Letter.t * C.t

type t = Bottom | Top | Base of (al list)

(* module S = Minset.MinSet(this) *)



let top = Top

let bottom = Bottom

let _id e = e 

let base_length t =  
  match t with
    | Bottom -> failwith("denotes empty set and base undefined")
    | Top -> failwith("denotes all words and base undefined")
    | Base(b) -> List.length b


let is_bottom t = 
  match t with
    | Bottom -> true
    | _ -> false 
	    
let is_top t = 
  match t with
    | Top -> true
    | _ -> false 
	
(* let create_from_a_letter_among l =  *)
(*   let c = C.zero () in *)
(*     [(c,l,c)] *)

let string_of t = begin
  let s = match t with 
    | Bottom -> "bot\n"
    | Top -> "top\n"
    | Base(lst) -> List.fold_left (fun acc (l,q,r) ->
				       sprintf "%s (%s %s %s)" acc (C.string_of l) (Letter.string_of q) (C.string_of r))
	  "[" lst
  in sprintf "%s]\n" s
end


let from_base sigma _base =
  let zc = C.zero sigma
  in let rec left_to_right _b _c  =
      match _b with
	| [] -> failwith("cannot handle empty base")
	| [hd] -> [(_c,hd,zc)],(C.inc zc hd)
	| hd::tl -> let _b',_c' = left_to_right tl (C.inc _c hd) in
	    ((_c,hd,_c')::_b'),(C.inc _c' hd)
  in match _base with
    | [] -> failwith("cannot make an abstract element out of an empty base, consider splitting on non empty bases")
    | hd::tl -> let _base',_ = left_to_right _base zc in Base(_base')


let from_context_and_base sigma context base =
(*   printf "\n -> context: %s \n -> sigma: %s \n" (D.string_of context) (D.string_of sigma); *)
  assert(Power_domain.entailed sigma context);
  let fbase = from_base sigma base in
(*     printf "fbase %s \n" (string_of fbase); *)
  let add_context e =
    match e with
      | Top -> failwith("should not add context to a top")
      | Bottom -> failwith("should not add context to a bottom")
      | Base(b) -> List.rev(List.fold_left (fun acc (lc,q,rc) -> (C.weaken_counter_wrt_context lc context,q,C.weaken_counter_wrt_context rc context)::acc ) [] b)  
  in Base(add_context fbase)




(** Does not modify a constraint base. It returns true if 
    all counters positive and each one of them allows at least those letters that are explicitely present 
*)
exception Not_well_formed
let well_formed_base sigma _base = 
  let result = 
    try
      let rec check _b _left = 
	match _b with
          | [] -> raise Not_well_formed
          | [(l,q,r)] -> if (C.entailed (C.largest sigma) l) && (C.entailed l _left)
	      && (C.entailed (C.largest sigma) r) && (C.entailed r (C.zero sigma))
  	    then (C.inc (C.zero sigma) q)
  	    else raise Not_well_formed
          | (l,q,r)::tl -> if (C.entailed (C.largest sigma) l) && (C.entailed l _left)
  	    then let _right = check tl (C.inc _left q) in 
	      if (C.entailed (C.largest sigma) r) && (C.entailed r _right)
	      then (C.inc _right q)
  	      else raise Not_well_formed
  	    else raise Not_well_formed
      in let _ = check _base (C.zero sigma)
      in true
    with Not_well_formed -> false
  in 
    if not result
    then printf "\n This base is %b well formed: %s  " result (string_of (Base(_base))); 
    result

let well_formed sigma cstr =
  match cstr with 
    | Top | Bottom -> failwith("we might need to fix these cases") 
    | Base(base) -> well_formed_base sigma base 



(* let find_participating_abstraction exact _letterwise_max_precision = C.MP.empty *)
(*   let rec collect _exact  _result = *)
(*     match _exact with  *)
(*       | [] -> _result  *)
(*       | (l,q,r)::tl -> let left = C.find_letterwise_cut_off_targets l _letterwise_max_precision  *)
(* 	 in let right = C.find_letterwise_cut_off_targets l _letterwise_max_precision  *)
(* 	 in let leftright *)
(* 	 in let local_contribution = C.MP.fold (fun _key _bound _acc ->  *)
(* 						  try  *)
(* 						    let _left bound = C.MP.find _key left  *)
(* 						  with  *)
(* 						      C.MP.add _key _bound _acc) *)
(* 	  right (C.MP.fold (fun _key _bound _acc -> C.MP.add _key _bound _acc ) left _result) *)
(* 	 in collect tl local_contribution *)
(*   in match exact with *)
(*     | Base(base) -> collect base (C.MP.empty) *)
(*     | _ -> failwith("finding participating abstractions for top or bottom is not implemented") *)

(* let rec merge base = *)
(*   match base with  *)
(*     | [] -> D.bottom *)
(*     | (l,q,r)::tl -> D.join (D.create_from_letter q) (merge tl) *)


(* exception Do_meet *)
(* let do_meet a b = *)
(*   if debug_meet *)
(*   then printf "\nmeet a=%s \nand b=%s\n" (string_of a) (string_of b); *)
(*   let rec check head base head' base' = *)
(*     match head,base,head',base' with *)
(* 	(\* both successfuly consumed*\) *)
(*       | _,[],_,[] -> raise Do_meet *)
(* 	  (\* first letter for both words.  *)
(* 	     1) try to consume them synchronously, or *)
(* 	     2) place one of them in the left context of the other *\) *)
(*       | [],(l,q,r)::tl,[],(l',q',r')::tl' ->  *)
(* 	  if (q=q') *)
(* 	  then check [(l,q,r)] tl [(l',q',r')] tl'; *)
(* 	  if (C.allows l q') *)
(* 	  then check []  ((l,q,r)::tl) [(l',q',r')] tl'; *)
(* 	  if (C.allows l' q) *)
(* 	  then check [(l,q,r)] tl [] ((l',q',r')::tl') *)
(* 	    (\* One is still at first letter while the other has already consumed some letters. *)
(* 	       1) try to consume the heads simultaneously, or *)
(* 	       2) place one of the heads to the left of the other*\) *)
(*       | [],(l,q,r)::tl,[(l1',q1',r1')],(l2',q2',r2')::tl' ->  *)
(* 	  if (q=q2') *)
(* 	  then check [(l,q,r)] tl [(l2',q2',r2')] tl'; *)
(* 	  if (C.allows l q2') *)
(* 	  then check []  ((l,q,r)::tl) [(l2',q2',r2')] tl'; *)
(* 	  if (C.allows (C.meet r1' l2') q) *)
(* 	  then check [(l,q,r)] tl [(l1',q1',r1')] ((l2',q2',r2')::tl') *)
(* 	    (\* Symmetrical of the precedent case*\) *)
(*       | [(l1,q1,r1)],(l2,q2,r2)::tl,[],(l',q',r')::tl' ->  *)
(* 	  if (q2=q') *)
(* 	  then check [(l2,q2,r2)] tl [(l',q',r')] tl'; *)
(* 	  if (C.allows l' q2) *)
(* 	  then check [(l2,q2,r2)] tl []  ((l',q',r')::tl'); *)
(* 	  if (C.allows (C.meet r1 l2) q') *)
(* 	  then check [(l1,q1,r1)] ((l2,q2,r2)::tl) [(l',q',r')] tl'  *)
(* 	    (\* Only one was consumed, its right context has to consume the rest of the other *\) *)
(*       | [(l,q,r)],[],_,(l',q',r')::tl' ->  *)
(* 	  if (C.allows r q') *)
(* 	  then check [(l,q,r)] [] [(l',q',r')] tl' *)
(* 	    (\* Symmetrical of the precedent case*\) *)
(*       | _,(l,q,r)::tl,[(l',q',r')],[] ->  *)
(* 	  if (C.allows r' q) *)
(* 	  then check [(l,q,r)] tl [(l',q',r')] []  *)
(* 	    (\* try to consume synchronously or to place one to the left of the other, in which  *)
(* 	       case both left and right contexts are taken into account during the placement *\) *)
(*       | [(l1,q1,r1)],(l2,q2,r2)::tl,[(l1',q1',r1')],(l2',q2',r2')::tl' ->  *)
(* 	  if (q2=q2') *)
(* 	  then check [(l2,q2,r2)] tl [(l2',q2',r2')] tl'; *)
(* 	  if (C.allows (C.meet r1 l2) q2') *)
(* 	  then check [(l1,q1,r1)]  ((l2,q2,r2)::tl) [(l2',q2',r2')] tl'; *)
(* 	  if (C.allows (C.meet r1' l2') q2) *)
(* 	  then check [(l2,q2,r2)] tl [(l1',q1',r1')] ((l2',q2',r2')::tl'); *)
(*       | _ -> failwith("uncaught Meet case !") *)
(*   in *)
(*   let result =  *)
(*     match a,b with *)
(*       | Bottom, _ -> false *)
(*       | _, Bottom -> false *)
(*       | Top, _ -> true *)
(*       | _, Top -> true *)
(*       | Base([]), _ -> failwith("A base cannot be empty") *)
(*       | _, Base([]) -> failwith("A base cannot be empty") *)
(*       | Base(base),Base(base') ->  *)
(* 	  try  *)
(* 	    check [] base [] base'; *)
(* 	    false *)
(* 	  with Do_meet -> true *)
(*   in if debug_meet then printf "%b\n" result; result *)


exception Is_entailed
(** Returns whether the denotation of the weak includes the one of the strong 
    * *)
let entailed ~weak ~strong  =
  let rec check base base' = 
    match base,base' with
      | hd::tl, [] -> ()
      | [(l,q,r)], (l',q',r')::tl' ->  	  
	  if ((C.entailed l l') && q=q' && (C.entailed r r')) 
	  then raise Is_entailed;
	  if (C.entailed  l (C.inc l' q'))
	  then (check base tl')
      | (l,q,r)::tl, (l',q',r')::tl' ->     
	  if ((C.entailed l l') && q=q' && (C.entailed r r')) 
	  then (check tl tl');
	  if (C.entailed  l (C.inc l' q'))
	  then (check base tl' )
      | _ -> failwith("I do not see how we can get here")
  in let result = match weak, strong with
    | Bottom, _ -> false
    | _, Bottom -> true
    | Top, _ -> true
    | _, Top -> false
    | Base([]), _ -> failwith("A base cannot be empty")
    | _, Base([]) -> failwith("A base cannot be empty")
    | Base(base),Base(base') -> 
	try 
	  check base base'; false
	with Is_entailed -> true
  in if debug_entail
    then begin 
      printf "\nwk=%s is %sentailed by\nsg=%s\n" (string_of weak) (if result then " " else "not ") (string_of strong);
    end;
    result

  let rec left_relaxation _base _source _destination= 
    match _base with 
      | [] -> [] (* failwith("the caller should ensure a non empty _suffix to start with") *)
(*       | [(l,q,r)] -> [(C.contagious_relaxation l _source _destination, q, r )] *)
      | (l,q,r)::tl -> (C.contagious_relaxation l _source _destination, q, r )
	  ::(left_relaxation tl _source _destination)

  let rec right_relaxation _base _source _destination= 
    match _base with 
      | [] -> [] (* failwith("the caller should ensure a non empty _suffix to start with") *)
(*       | [(l,q,r)] -> [(l, q, C.contagious_relaxation r _source _destination)] *)
      | (l,q,r)::tl -> (l, q, C.contagious_relaxation r _source _destination)
	  ::(right_relaxation tl _source _destination)

(** Apply pointwise _ladj,_radj: counter-> counter to each counter in _base
*)
  let rec propagate_counter_adjustment _base _ladj _radj =
(*     printf "prpagate base=%s ladj=%s radj=%s " (string_of (Base(_base))) (C.string_of (_ladj(C.zero()))) (C.string_of (_radj(C.zero()))); *)
    let result =  
      match _base with
	| [] -> [] 
	| (l, q, r)::tl -> (_ladj l, q, _radj r)::(propagate_counter_adjustment tl _ladj _radj)
    in result
(*     in begin  *)
(* 	printf "gives %s" (string_of (Base(result)));  *)
(* 	result *)
(*       end *)


  
  (**  Goes through all positions in _suffix@_prefix, and 
       changes position from _q to _q' and propagates 
       (_q--,_q'++) to the right counters of the position prefix 
       and to the left counters of the position suffix
  *)
  let rec operate sigma _prefix _suffix _q _q'=
    match _suffix with 
      | [] -> [] 
      | (l,q,r)::tl when (q = _q)  -> 
	  let _adj = (fun c -> let rslt = C.add_positive c (C.dec (C.inc (C.zero sigma) _q') _q) 
		      in (if not(C.entailed (C.largest sigma) rslt)
			  then begin
			    printf "operate pref=%s, suf=%s, q=%s, q'=%s, uses rslt=%s\n" 
			      (string_of (Base(_prefix))) 
			       (string_of (Base(_suffix))) 
			      (Letter.string_of _q) 
			      (Letter.string_of _q') 
			      (C.string_of rslt);
			    assert(false)
			  end); 
			rslt )
	  in 
	    ((propagate_counter_adjustment _prefix _id _adj)@((l,_q',r)::(propagate_counter_adjustment tl _adj _id)))
	    :: operate sigma (_prefix@[(l,q,r)]) tl _q _q'
      | hd::tl -> operate sigma (_prefix@[hd]) tl _q _q'


(** Gets a base ([] [] _base) and a witness _w, and returns all possible triples (left,_w,right) 
    whether _w  is concretely in base or in a context allowed by the counters.
*)
let rec concretize _prefix _prev _suffix _w allow_context =
  let wplus = (fun c -> (C.inc c _w))  in
    match _prev, _suffix with
      | [], [] -> []
      | [], (l,q,r)::tl -> 
	  let concrete = if (q = _w)
	  then [([],(l,q,r),tl)]
	  else [] in
	  let context = if (C.largely_allows l _w) && allow_context 
	  then [([], ( l, _w, C.inc r q), (propagate_counter_adjustment _suffix wplus _id))] 
	  else [] 
	  in concrete @ context @ (concretize [] [(l,q,r)] tl _w allow_context)
      | [(l,q,r)], [] ->
	  if (C.largely_allows r _w) && allow_context
	  then [((propagate_counter_adjustment (_prefix@[(l,q,r)]) _id wplus),(C.inc l q,_w, r),[])]
	  else []
      | [(l,q,r)], (l',q',r')::tl ->
	  let concrete = if (q' = _w)
	  then [(_prefix@[(l,q,r)],(l',q',r'),tl)]
	  else [] in	    
	  let context = if (C.largely_allows r _w) && (C.largely_allows l' _w) && allow_context
	  then [((propagate_counter_adjustment (_prefix@[(l,q,r)]) _id wplus),
		 ( l', _w , r ),
		 (propagate_counter_adjustment _suffix wplus _id))]
	  else [] in
	    concrete @ context @ (concretize (_prefix@[(l,q,r)]) [(l',q',r')] tl _w allow_context)
      | _ -> failwith("should not have gotten here")
	  

let local sigma _prepost cstr _grd _act = 
  if debug_long
  then printf "local:post=%b,guard=%s,action=%s on cstr=%s" (match _prepost with | Pre -> false | Post -> true)
    (D.string_of _grd) (D.string_of _act) (string_of cstr) ;
  let grd,act = match _prepost with
    | Post -> _grd,_act
    | Pre -> _act,_grd
  in
  let result = begin
    match cstr with
      | Bottom -> []
      | Top -> D.fold (fun q acc -> (from_context_and_base sigma sigma [q])::acc ) [] act
      | Base([]) -> failwith("A base cannot be empty")
      | Base(base) -> assert(well_formed_base sigma base);
	  let adjust _src _dest = (fun c -> 
				     let rslt = C.add_positive c (C.dec (C.inc (C.zero sigma) _dest) _src) in 
				       begin
					 assert (C.entailed (C.largest sigma) rslt);
					 rslt
				       end )
	  in let brut = 
	      D.fold ( 
		fun src acc' ->
		  let triplets = (concretize [] [] base src true) in
		    List.fold_left (
		      fun acctriplet (left,(l,q,r),right) -> 
			D.fold (
			  fun dest acc -> 
 			    incr Debug.number_of_constraints;
			    let _base = ((propagate_counter_adjustment left _id (adjust src dest))
					 @((l,dest,r)::(propagate_counter_adjustment right (adjust src dest) _id)))
			    in begin
				assert(well_formed_base sigma _base);
				if entailed cstr (Base(_base))
				then acc 
				else (Base(_base)):: acc 
			      end
			) acctriplet act
		    ) acc' triplets  
	      ) [] grd    
	  in brut (* List.fold_left (fun acc _base -> assert(well_formed_base sigma _base);Base(_base)::acc) [] brut *)
  end
  in if debug_long
    then printf " gives:\n%s\n" (List.fold_left (fun acc e -> assert(well_formed sigma e); sprintf "%s %s" acc (string_of e)) "" result);
    result










let concretize_and_print _prefix _prev _suffix _w allow_context =
  printf "concretizing _prefix=%s _prev=%s _suffix=%s _w=%s gives:\n" (string_of (Base(_prefix))) (string_of (Base(_prev))) (string_of (Base(_suffix))) (Letter.string_of _w);
  let rec print_result triplets = 
    match triplets with 
      | [] -> ""
      | (pref,witness,suff)::tl -> sprintf "%s\n:%s" (string_of (Base((pref@(witness::suff))))) (print_result tl)
  in 
  let result = concretize _prefix _prev _suffix _w allow_context in 
    printf ":%s" (print_result result);
    result
    

let reverse _base =
(*   printf "\nreverse input: %s \n" (string_of (Base(_base))); *)
  let brut = List.rev _base 
  in let rec pivot _brut =
      match _brut with 
	| [] -> []
	| (l,q,r)::tl -> (r,q,l)::(pivot tl)
  in let result = pivot brut
  in   (* printf "\n reverse output: %s \n" (string_of (Base(result))); *)
    result
  

let based_reverse cstr =
  match cstr with 
    | Base(base) -> Base(reverse base)
    | _ -> failwith("no top or bottom allowed here")


let exists sigma _prepost cstr _guard _action witness prior =  
  if debug_long
  then printf "\nexists:prior=%s,post=%b,guard=%s,action=%s,witness=%s on cstr=%s " 
    (match prior with | Left -> "left" | LeftRight -> "leftright" | Right -> "right" ) (match _prepost with | Pre -> false | Post -> true)
    (D.string_of _guard) (D.string_of _action) (D.string_of witness) (string_of cstr);
  let guard,action = match _prepost with
    | Post -> _guard,_action
    | Pre -> _action,_guard
  in match cstr with
      | Bottom -> []
      | Top -> failwith ("might not need to implement this")
      | Base([]) -> failwith("a base cannot be empty")
      | Base(base) -> assert(well_formed_base sigma base);
	  let adjust _src _dest = (fun c -> C.add_positive c (C.dec (C.inc (C.zero sigma) _dest) _src)) 
	  in let leftresult _base = begin 
	      let w_triplets = D.fold (fun w acc_witness -> (concretize [] [] _base w true) @ acc_witness) [] witness
	      in List.fold_left (
		  fun acc_w_triplet (w_left,(w_l,w_q,w_r),w_right) -> acc_w_triplet @
		    D.fold ( 
		      fun src acc_src -> acc_src @
			begin 
			  let src_triplets = (concretize w_left [(w_l,w_q,w_r)] w_right src true) 
			  in (* printf "concretize src %s for: \n wleft: %s : w : %s : wright: %s : \n %s\n"  *)(* 					     (Letter.string_of src) (string_of (Base(w_left)))  *)(* 					     (string_of (Base([(w_l,w_q,w_r)]))) (string_of (Base(w_right))) *)(* 					     (List.fold_left *)(* 						(fun acc (left,(l,q,r),right) -> *)(* 						     (string_of (Base(right)))  ) "" src_triplets); *)
			    D.fold ( 
			      fun dest acc_dest -> acc_dest @ 
				List.fold_left(
				  fun acc_src_triplet (left,(l,q,r),right) ->
				    incr Debug.number_of_constraints;
				    (Base((propagate_counter_adjustment left _id (adjust src dest))
					  @((l,dest,r)::(propagate_counter_adjustment right (adjust src dest) _id))))::acc_src_triplet
				) [] src_triplets
			    ) [] action
			end
		    ) [] guard
		) [] w_triplets
	    end	      
	  in let result = match prior with
	    | Left -> leftresult base 
	    | Right -> List.fold_left (fun acc lrslt -> (based_reverse lrslt) :: acc ) [] (leftresult (reverse base))
	    | LeftRight -> (leftresult base)
		@ (List.fold_left (fun acc lrslt -> (based_reverse lrslt) :: acc ) [] (leftresult (reverse base)))
	  in let filtered = List.filter (fun e -> not(entailed cstr e)) result 
	  in if debug_long
	    then printf " gives:\n%s\n" 
	      (List.fold_left (fun acc e -> let str = sprintf "%s %s" acc (string_of e)in 
				 assert(well_formed sigma e);
				 str) "" filtered);
	    filtered
	      

let rec ensure_strengthen word =
  let rec strengthen ahead base =
    match ahead, base with
      | [], [] -> ([], false)
      | [], [hd] -> (base, false)
      | [], (l',q',r')::((l'',q'',r'')::tl) -> (* strengthening l' using l'' - q' and r' using l'' - lq' + qr'' *)
	  let otl'' = C.dec l'' q' in 
	  let sl' = (C.meet l' otl'') in 
	  let lq' = C.inc l' q' in 	    
	  let rq'' = C.inc r'' q'' in 
	  let otr'' = C.add rq'' (C.ordered_difference l'' (C.meet l'' lq')) in
	  let sr' = (C.meet r' otr'') in 
	  let schange = not(C.entailed sl' l') || not(C.entailed sr' r') in 
	  let _base, _change = (strengthen [(sl',q',sr')] ((l'',q'',r'')::tl)) in 
	    _base,(schange || _change)
      | [(l,q,r)], [(l',q',r')] -> (* strengthening l' using lq + r - qr' and r' using r' - q *)
	  let lq = C.inc l q in 
	  let rq' = C.inc r' q' in 
	  let otl = C.add lq (C.ordered_difference r (C.meet r rq')) in 
	  let sl' = (C.meet l' otl) in 
	  let otr = C.dec r q' in 
	  let sr' = (C.meet r' otr) in 
	  let schange = not(C.entailed sl' l') || not(C.entailed sr' r') in 
	    ((l,q,r)::[(sl',q',sr')]), schange
      | [(l,q,r)], (l',q',r')::((l'',q'',r'')::tl) -> 
	  (** strengthen l' using lq + r - rq' and l'' - q' 
	      and strengthening r' using r - q' and rq'' + l'' - lq' *)
	  let lq = C.inc l q in 
	  let rq' = C.inc r' q' in 
	  let otl = C.add lq (C.ordered_difference r (C.meet r rq')) in 
	  let otl'' = C.dec l'' q' in 
	  let sl' = (C.meet l'  (C.meet otl otl'')) in 
	  let lq' = C.inc l' q' in 	    
	  let rq'' = C.inc r'' q'' in 
	  let otr'' = C.add rq'' (C.ordered_difference l'' (C.meet l'' lq')) in
	  let otr = C.dec r q' in 
	  let sr' = (C.meet r'  (C.meet otr otr'')) in 
	  let schange = not(C.entailed sl' l') || not(C.entailed sr' r') in 
	  let _base, _change = (strengthen [(sl',q',sr')] ((l'',q'',r'')::tl)) in 
	    ((l,q,r)::_base),(schange || _change)
      | _, _ -> failwith("I do not see how we could get here")
  in 
    if false
    then printf "ensuring strength of %s" (string_of (Base(word)));
    let result, change = (strengthen [] word) in
      if change 
      then  begin 
	assert (not(result=word)); 
	(ensure_strengthen result) 
      end
      else begin if false
      then printf "gives %s" (string_of (Base(result)));
      result
      end

	


exception GlobalGuardViolation

let universal sigma _prepost cstr _guard _action gguard prior = 
  if debug_long
  then printf "\nuniversal:prior=%s,post=%b,guard=%s,action=%s,gguard=%s on cstr=%s " 
    (match prior with | Left -> "left" | LeftRight -> "leftright" | Right -> "right" ) (match _prepost with | Pre -> false | Post -> true)
    (D.string_of _guard) (D.string_of _action) (D.string_of gguard) (string_of cstr);
  let guard,action = match _prepost with
    | Post -> _guard,_action
    | Pre -> _action,_guard
  in match cstr with
    | Bottom -> []
    | Top -> failwith ("might not need to implement this")
    | Base([]) -> failwith("a base cannot be empty")
    | Base(base) -> assert(well_formed_base sigma base);
	let zero_counters c = D.fold (fun _key acc -> if D.member _key gguard 
				      then acc 
				      else (C.restrict_to_zero acc _key) ) c sigma 
	in
	let rec operate src dest triplets = 
	  begin
	    let dest_src c = C.add_positive c (C.dec (C.inc (C.zero sigma) dest) src )
	    in match triplets with 
	      | [] -> []
	      | (prefix,(l,q,r),suffix)::tl -> 
		  begin
		    match prior with 
		      | Right -> if C.compatible_empty r (D.difference sigma gguard)
			then let _prefix = propagate_counter_adjustment prefix _id dest_src  in
			let _suffix = propagate_counter_adjustment suffix dest_src zero_counters in
			let _base = (ensure_strengthen (((_prefix@[(l,dest, zero_counters r)])) @ ((_suffix))))
			in incr Debug.number_of_constraints; 
			  if entailed cstr (Base(_base))
			  then (operate src dest tl)
			  else _base :: (operate src dest tl)
			else operate src dest tl
		      | Left -> if C.compatible_empty l (D.difference sigma  gguard)
			then let _prefix = propagate_counter_adjustment prefix zero_counters dest_src in 
			let _suffix = propagate_counter_adjustment suffix dest_src _id  in
			let _base =  (ensure_strengthen (((_prefix)) @ (((zero_counters l,dest,r)::_suffix))))
			in incr Debug.number_of_constraints;
			  if entailed cstr (Base(_base))
			  then  operate src dest tl
			  else _base :: operate src dest tl
			else operate src dest tl
		      | LeftRight ->  if (C.compatible_empty l (D.difference sigma  gguard))
			  && (C.compatible_empty r (D.difference sigma  gguard))
			then begin 
			  let _prefix = (propagate_counter_adjustment prefix zero_counters 
					   (fun c -> dest_src (zero_counters c))) in 
			  let _suffix = (propagate_counter_adjustment suffix 
					   (fun c -> dest_src(zero_counters c)) zero_counters) in 
			  let _base = (ensure_strengthen (_prefix @ ((zero_counters l,dest,zero_counters r)::_suffix))) 
			  in incr Debug.number_of_constraints;
			    if entailed cstr (Base(_base))
			    then operate src dest tl
			    else _base :: operate src dest tl
			end
			else operate src dest tl
		  end
	  end
	in 
	let bases = 
	    D.fold (fun src accsrc -> 
		      ( D.fold ( fun dest accdest -> (operate src dest (concretize [] [] base src true))@accdest
			       ) [] action)@accsrc 
		   ) [] guard
	in 
	let result = List.fold_left (fun acc e -> assert(well_formed_base sigma e); Base(e)::acc) [] bases
	in if debug_long
	  then printf " gives:\n%s\n" 
	    (List.fold_left (fun acc e -> assert(well_formed sigma e); sprintf "%s %s" acc (string_of e)) "" result);
	  result








(* Used as a weight in Fixpoint. All those abstract elements whose weight (ex. base length) is longer than max_weight will be assigned the same
   priority by the fixpoint*)
let max_weight = 100

let weight cstr = 
    match cstr with
      | Bottom -> max_weight
      | Top -> 0 
      | Base([]) -> failwith("A base cannot be empty")
      | Base(base) -> let length = List.length base in 
	  min length max_weight



let level_up_counters_wrt_base sigma word =
  if debug_meet 
  then printf "level up %s" (string_of (Base(word)));
  let rec level_up word left = 
    match word with 
      | [] -> failwith("yet another base that should not be empty")
      | [(l,q,r)] -> [(C.level_up l left,q,r)],(C.inc (C.zero sigma) q)
      | (l,q,r)::tl -> let result,right = level_up tl (C.inc left q)
	in (((C.level_up l left), q, (C.level_up r right))::result, (C.inc right q))
  in let _result,_ = level_up word (C.zero sigma)
  in if debug_meet
    then printf "\t -> %s" (string_of (Base(_result)));
    _result

exception First_meet of t list
let stopable_meet sigma a b stop_at_first = 
  if debug_meet
  then printf "\nmeet a=%s \nand b=%s\n" (string_of a) (string_of b);
  let rec build result tentative head base head' base' =
    match head,base,head',base' with
	(* both successfuly consumed*)
      | _,[],_,[] -> if stop_at_first 
	then (raise (First_meet [(Base(ensure_strengthen (level_up_counters_wrt_base sigma tentative)))]))
	else (Base(ensure_strengthen (level_up_counters_wrt_base sigma tentative)))::result

      (* first letter for both words. 
	 1) try to consume them synchronously, or
	 2) place one of them in the left context of the other *)
      | [],(l2,q2,r2)::tl,[],(l2',q2',r2')::tl' -> 
	  (* consuming (l2,q2,r2) and (l2',q2',r2') synchronously *)
	  let synch = if (q2=q2') && (C.do_meet l2 l2') && (C.do_meet r2 r2')
	  then let l2l2' = C.meet l2 l2' in 
	  let r2r2' = C.meet r2 r2' 
	  in (build result (tentative@[(l2l2',q2,r2r2')]) [(l2,q2,r2)] tl [(l2',q2',r2')] tl') 
	  else [] 
	  in (* consuming (l2',q2',r2') and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 = 
	    if (C.largely_allows l2 q2')
	    then (build result [(l2',q2',r2')] []  ((l2,q2,r2)::tl) [(l2',q2',r2')] tl')
	    else []
	  in (* consuming (l2,q2,r2) and placing it between (l1',q1',r1') and (l2',q2',r2') *)
	  let overlap2 = 
	    if (C.largely_allows l2' q2)
	    then (build result (tentative@[(l2,q2,r2)]) [(l2,q2,r2)] tl []  ((l2',q2',r2')::tl'))
	    else []
	  in result @ synch @ overlap1 @ overlap2

      | [],(l2,q2,r2)::tl,[(l1',q1',r1')],(l2',q2',r2')::tl' -> 
	  (* consuming (l2,q2,r2) and (l2',q2',r2') synchronously *)
	  let synch = if (q2=q2') && (C.do_meet l2 l2') && (C.do_meet r2 r2')
	  then let l2l2' = C.meet l2 l2' in 
	  let r2r2' = C.meet r2 r2' 
	  in (build result (tentative@[(l2l2',q2,r2r2')]) [(l2,q2,r2)] tl [(l2',q2',r2')] tl') 
	  else [] 
	  in (* consuming (l2',q2',r2') and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 = 
	    if (C.largely_allows l2 q2')
	    then (build result (tentative@[(l2',q2',r2')]) []  ((l2,q2,r2)::tl) [(l2',q2',r2')] tl')
	    else []
	  in (* consuming (l2,q2,r2) and placing it between (l1',q1',r1') and (l2',q2',r2') *)
	  let overlap2 = 
	    if (C.largely_allows r1' q2) && (C.largely_allows l2' q2)
	    then (build result (tentative@[(l2,q2,r2)]) [(l2,q2,r2)] tl [(l1',q1',r1')]  ((l2',q2',r2')::tl'))
	    else []
	  in result @ synch @ overlap1 @ overlap2

      | [(l1,q1,r1)],(l2,q2,r2)::tl,[],(l2',q2',r2')::tl' -> 
	  (* consuming (l2,q2,r2) and (l2',q2',r2') synchronously *)
	  let synch = if (q2=q2') && (C.do_meet l2 l2') && (C.do_meet r2 r2')
	  then let l2l2' = C.meet l2 l2' in 
	  let r2r2' = C.meet r2 r2' 
	  in (build result (tentative@[(l2l2',q2,r2r2')]) [(l2,q2,r2)] tl [(l2',q2',r2')] tl') 
	  else [] 
	  in (* consuming (l2',q2',r2') and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 = 
	    if (C.largely_allows r1 q2') && (C.largely_allows l2 q2')
	    then (build result (tentative@[(l2',q2',r2')]) [(l1,q1,r1)]  ((l2,q2,r2)::tl) [(l2',q2',r2')] tl')
	    else []
	  in (* consuming (l2,q2,r2) and placing it between (l1',q1',r1') and (l2',q2',r2') *)
	  let overlap2 = 
	    if (C.largely_allows l2' q2)
	    then (build result (tentative@[(l2,q2,r2)]) [(l2,q2,r2)] tl []  ((l2',q2',r2')::tl'))
	    else []
	  in result @ synch @ overlap1 @ overlap2

      | [(l1,q1,r1)], [], _, (l2',q2',r2')::tl' -> 
	  let overlap1 = 
	    if (C.largely_allows r1 q2') 
	    then (build result (tentative@[(l2',q2',r2')]) [(l1,q1,r1)]  [] [(l2',q2',r2')] tl')
	    else []
	  in result @ overlap1 

      | _,(l2,q2,r2)::tl,[(l1',q1',r1')],[] -> 
	  let overlap2 = 
	    if (C.largely_allows r1' q2) 
	    then (build result (tentative@[(l2,q2,r2)]) [(l2,q2,r2)] tl [(l1',q1',r1')]  [])
	    else []
	  in result @ overlap2

      | [(l1,q1,r1)],(l2,q2,r2)::tl,[(l1',q1',r1')],(l2',q2',r2')::tl' -> 
	  (* consuming (l2,q2,r2) and (l2',q2',r2') synchronously *)
	  let synch = if (q2=q2') && (C.do_meet l2 l2') && (C.do_meet r2 r2')
	  then let l2l2' = C.meet l2 l2' in 
	  let r2r2' = C.meet r2 r2' 
	  in (build result (tentative@[(l2l2',q2,r2r2')]) [(l2,q2,r2)] tl [(l2',q2',r2')] tl') 
	  else [] 
	  in (* consuming (l2',q2',r2') and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 = 
	    if (C.largely_allows r1 q2') && (C.largely_allows l2 q2')
 	    then (build result (tentative@[(l2',q2',r2')]) [(l1,q1,r1)]  ((l2,q2,r2)::tl) [(l2',q2',r2')] tl')
	    else []
	  in (* consuming (l2,q2,r2) and placing it between (l1',q1',r1') and (l2',q2',r2') *)
	  let overlap2 = 
	    if (C.largely_allows r1' q2) && (C.largely_allows l2' q2)
	    then (build result (tentative@[(l2,q2,r2)]) [(l2,q2,r2)] tl [(l1',q1',r1')]  ((l2',q2',r2')::tl'))
	    else []
	  in result @ synch @ overlap1 @ overlap2
      | _ -> failwith("uncaught Meet case !")
  in let result = 
      match a,b with
	| Bottom, _ -> []
	| _, Bottom -> []
	| Top, _ -> [b] 
	| _, Top -> [a]
	| Base([]), _ -> failwith("A base cannot be empty")
	| _, Base([]) -> failwith("A base cannot be empty")
	| Base(base),Base(base') -> build [] [] [] base [] base' 
  in if debug_meet 
    then printf "%s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "->" result); 
    result


let meet sigma a b = 
  try stopable_meet sigma a b false
  with | First_meet _ -> failwith("Error in stopable meet") 

let do_meet sigma a b = 
  try let meet = stopable_meet sigma a b true
  in match meet with 
    | [] -> false
    | _ -> failwith("Stopable meet did not stop")
  with | First_meet _ -> true




let collect sigma ~exact ~approximated ~target  =
  if debug_collect
  then printf "\ncollect differences that make approximated meet target but not exact, where\n target=%s\napprox=%s \nexact =%s\n" (string_of target) (string_of approximated) (string_of exact);
  let rec build_collection m_head m_base t_head t_base n_head n_base =
    match m_head,m_base,t_head,t_base,n_head,n_base with
	(* both successfuly consumed*)
      | _,[],_,[],_,[] -> Collection.false_leaf

      (* first letter for both words.
	 1) try to consume them synchronously, or
	 2) place one of them in the left context of the other *)
      | [],(ml2,mq2,mr2)::mtl,[],(tl2,tq2,tr2)::ttl,[],(nl2,nq2,nr2)::ntl ->
	  (* consuming (ml2,mq2,mr2) and (tl2,tq2,tr2) synchronously *)
	  let synch = if (mq2=tq2) && (C.do_meet ml2 tl2) && (C.do_meet mr2 tr2)
	  then let ml2tl2 = C.meet ml2 tl2 in
	  let mr2tr2 = C.meet mr2 tr2 in 
	  let left = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nl2 ~high:ml2 in 
	  let right = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nr2 ~high:mr2 in
	  let current = (build_collection [(ml2tl2,mq2,mr2tr2)] mtl [(ml2tl2,tq2,mr2tr2)] ttl [nl2,nq2,nr2] ntl) 
	  in Collection.percolate (Collection.build_or [left; right; current])
	  else Collection.true_leaf
	  in (* consuming (tl2,tq2,tr2) and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 =
	    if (C.largely_allows ml2 tq2)
	    then let reason = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nl2 tq2 in
	    let current = (build_collection [] ((ml2,mq2,mr2)::mtl) [(tl2,tq2,tr2)] ttl [] ((nl2,nq2,nr2)::ntl)) 
	    in Collection.percolate (Collection.build_or [current;reason])
	    else Collection.true_leaf
	  in (* consuming (l2,q2,r2) and placing it between (l1',q1',r1') and (tl2,tq2,tr2) *)
	  let overlap2 =
	    if (C.largely_allows tl2 mq2)
	    then (build_collection [(ml2,mq2,mr2)] mtl []  ((tl2,tq2,tr2)::ttl) [(nl2,nq2,nr2)] ntl)
	    else Collection.true_leaf
	  in let res = Collection.percolate (Collection.build_and [synch; overlap1; overlap2])
	  in (* printf "\n1:\nm=%s   %s\nt=%s  %s\nn=%s   %s\nsynch=%s\nover1=%s\nover2=%s\n\n" *)
(* 	       (string_of (Base(m_head))) (string_of (Base(m_base))) (string_of (Base(t_head))) (string_of (Base(t_base))) (string_of (Base(n_head)))(string_of (Base(n_base))) (Collection.string_of synch) (Collection.string_of overlap1) (Collection.string_of overlap2); *)
	    res

      | [],(ml2,mq2,mr2)::mtl,[(tl1,tq1,tr1)],(tl2,tq2,tr2)::ttl,[],(nl2,nq2,nr2)::ntl ->
	  (* consuming (ml2,mq2,mr2) and (tl2,tq2,tr2) synchronously *)
	  let synch = if (mq2=tq2) && (C.do_meet ml2 tl2) && (C.do_meet mr2 tr2)
	  then let ml2tl2 = C.meet ml2 tl2 in
	  let mr2tr2 = C.meet mr2 tr2 in 
	  let left = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nl2 ~high:ml2 in 
	  let right = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nr2 ~high:mr2 in
	  let current = (build_collection [(ml2tl2,mq2,mr2tr2)] mtl [(ml2tl2,tq2,mr2tr2)] ttl [(nl2,nq2,nr2)] ntl)
	  in Collection.percolate(Collection.build_or [left;right;current])
	  else Collection.true_leaf
	  in (* consuming (tl2,tq2,tr2) and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 =
	    if (C.largely_allows ml2 tq2)
	    then let reason = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nl2 tq2 in 
	    let current = (build_collection []  ((ml2,mq2,mr2)::mtl) [(tl2,tq2,tr2)] ttl [] ((nl2,nq2,nr2)::ntl)) 
	    in Collection.percolate(Collection.build_or [current;reason])
	    else Collection.true_leaf
	  in (* consuming (l2,q2,r2) and placing it between (tl1,tq1,tr1) and (tl2,tq2,tr2) *)
	  let overlap2 =
	    if (C.allows tr1 mq2) && (C.largely_allows tl2 mq2)
	    then (build_collection  [(ml2,mq2,mr2)] mtl [(tl1,tq1,tr1)] ((tl2,tq2,tr2)::ttl) [(nl2,nq2,nr2)] ntl)
	    else Collection.true_leaf
	  in let res = Collection.percolate(Collection.build_and [synch; overlap1; overlap2])
	  in (* printf "\n2:\nm=%s   %s\nt=%s   %s\n=%s   %s\nsynch=%s\nover1=%s\nover2=%s\n\n" *)
(* 	       (string_of (Base(m_head))) (string_of (Base(m_base))) (string_of (Base(t_head))) (string_of (Base(t_base))) (string_of (Base(n_head)))(string_of (Base(n_base))) (Collection.string_of synch) (Collection.string_of overlap1) (Collection.string_of overlap2); *)
	    res
	      
      | [(ml1,mq1,mr1)],(ml2,mq2,mr2)::mtl,[],(tl2,tq2,tr2)::ttl,[(nl1,nq1,nr1)],(nl2,nq2,nr2)::ntl ->
	  (* consuming (l2,q2,r2) and (tl2,tq2,tr2) synchronously *)
	  let synch = if (mq2=tq2) && (C.do_meet ml2 tl2) && (C.do_meet mr2 tr2)
	  then let ml2tl2 = C.meet ml2 tl2 in
	  let mr2tr2 = C.meet mr2 tr2 in
	  let left = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nl2 ~high:ml2 in
	  let right = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nr2 ~high:mr2 in
	  let current = (build_collection [(ml2tl2,mq2,mr2tr2)] mtl [(ml2tl2,tq2,mr2tr2)] ttl [(nl2,nq2,nr2)] ntl)
	  in Collection.percolate(Collection.build_or [left;right;current])
	  else Collection.true_leaf
	  in (* consuming (tl2,tq2,tr2) and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 =
	    if (C.allows mr1 tq2) && (C.largely_allows ml2 tq2)
	    then let left = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nl2 tq2 in 
	    let right = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nr2 tq2 in 
	    let current = (build_collection [(ml1,mq1,mr1)] ((ml2,mq2,mr2)::mtl) [(tl2,tq2,tr2)] ttl [(nl1,nq1,nr1)] ((nl2,nq2,nr2)::ntl)) 
	    in Collection.percolate(Collection.build_or [current;left;right])
	    else Collection.true_leaf
	  in (* consuming (l2,q2,r2) and placing it between (tl1,tq1,tr1) and (tl2,tq2,tr2) *)
	  let overlap2 =
	    if (C.largely_allows tl2 mq2)
	    then (build_collection  [(ml2,mq2,mr2)] mtl [] ((tl2,tq2,tr2)::ttl) [(nl2,nq2,nr2)] ntl)
	    else Collection.true_leaf
	  in let res = Collection.percolate(Collection.build_and [synch; overlap1; overlap2])
	  in (* printf "\n3:\nm=%s   %s\nt=%s   %s\nn=%s   %s\nsynch=%s\nover1=%s\nover2=%s\n\n" *)
(* 	       (string_of (Base(m_head))) (string_of (Base(m_base))) (string_of (Base(t_head))) (string_of (Base(t_base))) (string_of (Base(n_head)))(string_of (Base(n_base))) (Collection.string_of synch) (Collection.string_of overlap1) (Collection.string_of overlap2); *)
	    res 
	      

      | [(ml1,mq1,mr1)], [], _, (tl2,tq2,tr2)::ttl, [(nl1,nq1,nr1)], [] ->
	  let res = if (C.allows mr1 tq2)
	  then let reason = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nr1 tq2 in
	  let current = (build_collection [(ml1,mq1,mr1)] [] [(tl2,tq2,tr2)] ttl [(nl1,nq1,nr1)] [])
	  in Collection.percolate(Collection.build_or [reason;current])
	  else Collection.true_leaf in 
	    (* printf "\n4:\nm=%s   %s\nt=%s   %s\nn=%s   %s\nres=%s\n\n" *)
(* 	      (string_of (Base(m_head))) (string_of (Base(m_base))) (string_of (Base(t_head))) (string_of (Base(t_base))) (string_of (Base(n_head)))(string_of (Base(n_base))) (Collection.string_of res); *)
	    res
	      
      | _,(ml2,mq2,mr2)::mtl,[(tl1,tq1,tr1)],[],_,(nl2,nq2,nr2)::ntl ->
	  let res = if (C.allows tr1 mq2)
	  then (build_collection [(ml2,mq2,mr2)] mtl [(tl1,tq1,tr1)] [] [(nl2,nq2,nr2)] ntl)
	  else Collection.true_leaf
	  in (* printf "\n5:\nm=%s   %s\nt=%s   %s\nn=%s   %s\nres=%s\n\n" *)
(* 	       (string_of (Base(m_head))) (string_of (Base(m_base))) (string_of (Base(t_head))) (string_of (Base(t_base))) (string_of (Base(n_head)))(string_of (Base(n_base))) (Collection.string_of res); *)
	    res
	      
      | [(ml1,mq1,mr1)],(ml2,mq2,mr2)::mtl,[(tl1,tq1,tr1)],(tl2,tq2,tr2)::ttl, [(nl1,nq1,nr1)],(nl2,nq2,nr2)::ntl ->
	  (* consuming (l2,q2,r2) and (tl2,tq2,tr2) synchronously *)
	  let synch = if (mq2=tq2) && (C.do_meet ml2 tl2) && (C.do_meet mr2 tr2)
	  then let ml2tl2 = C.meet ml2 tl2 in
	  let mr2tr2 = C.meet mr2 tr2 in 
	  let left = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nl2 ~high:ml2 in 
	  let right = Collection.disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low:nr2 ~high:mr2 in
	  let current =  (build_collection [(ml2tl2,mq2,mr2tr2)] mtl [(ml2tl2,tq2,mr2tr2)] ttl [(nl2,nq2,nr2)] ntl)
	  in Collection.percolate(Collection.build_or [left;right;current])
	  else Collection.true_leaf
	  in (* consuming (tl2,tq2,tr2) and placing it between (l1,q1,r1) and (l2,q2,r2) *)
	  let overlap1 =
	    if (C.allows mr1 tq2) && (C.largely_allows ml2 tq2)
 	    then let right = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nr1 tq2 in 
	    let left = Collection.disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter nl2 tq2 in 
	    let current = (build_collection [(ml1,mq1,mr1)]  ((ml2,mq2,mr2)::mtl) [(tl2,tq2,tr2)] ttl [(nl1,nq1,nr1)]  ((nl2,nq2,nr2)::ntl))
	    in Collection.percolate(Collection.build_or [current;left;right])
	    else Collection.true_leaf
	  in (* consuming (l2,q2,r2) and placing it between (l1',q1',r1') and (tl2,tq2,tr2) *)
	  let overlap2 =
	    if (C.allows tr1 mq2) && (C.largely_allows tl2 mq2)
	    then (build_collection [(ml2,mq2,mr2)] mtl [(tl1,tq1,tr1)]  ((tl2,tq2,tr2)::ttl) [(nl2,nq2,nr2)] ntl)
	    else Collection.true_leaf
	  in let res = Collection.percolate(Collection.build_and [synch;overlap1;overlap2] )
	  in (* printf "\n6:\nm=%s  %s\nt=%s  %s\nn=%s  %s\nsynch=%s\nover1=%s\nover2=%s\n\n" *)
(* 	       (string_of (Base(m_head))) (string_of (Base(m_base))) (string_of (Base(t_head))) (string_of (Base(t_base))) (string_of (Base(n_head)))(string_of (Base(n_base))) (Collection.string_of synch) (Collection.string_of overlap1) (Collection.string_of overlap2); *)
	    res

      | _ -> failwith("uncaught Meet case !")
  in let result =
      match approximated,target,exact with
	| Base(mbase),Base(tbase),Base(nbase) -> build_collection [] mbase [] tbase [] nbase
	| _ -> failwith("not implemented")
  in if debug_meet
    then printf "result: %s\n" (Collection.string_of result);
    result

let gamma_counters_cut_off_with_uniform_max_precision cstr _max_precision = begin
  let result =  match cstr with 
    | Bottom -> Bottom
    | Top -> Top
    | Base(base) -> let _base = List.fold_left ( fun acc (lc,q,rc) -> acc@[(C.cut_off_with_uniform_max_precision lc _max_precision, q, C.cut_off_with_uniform_max_precision rc _max_precision)]) [] base
      in Base( ensure_strengthen _base )
  in if false
    then printf "cutt off=%d, \ncstr=%s\nis  =%s\n" _max_precision (string_of cstr) (string_of result);
    result
end

let gamma_counters_cut_off_with_letterwise_max_precision cstr _letterwise_max_precision = begin
  let result =  match cstr with 
    | Bottom -> Bottom
    | Top -> Top
    | Base(base) -> let _base = List.fold_left ( fun acc (lc,q,rc) -> acc@[(C.cut_off_with_letterwise_max_precision lc _letterwise_max_precision, q, C.cut_off_with_letterwise_max_precision rc _letterwise_max_precision)]) [] base
      in Base( ensure_strengthen _base )
  in if false
    then printf "cutt off=%s\n\tcstr=%s\n\t  =%s\n" (C.MP.fold (fun _key _bound acc -> (sprintf "%s %s:%d " acc (Letter.string_of _key) _bound)) _letterwise_max_precision "") (string_of cstr) (string_of result);
    result
end
