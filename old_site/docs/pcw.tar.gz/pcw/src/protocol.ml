open Printf



module type Protocol_sig =
sig
  val sigma: Power_domain.t
  val get_init: Dated_constraint.t list
  val get_bad: Dated_constraint.t list
  val meet_init: Dated_constraint.t -> bool 
  val meet_bad: Dated_constraint.t -> bool 
(*   val letterwise_max_precision: int Counters.MP.t *)
  val string_of: string
  val next: Constraint.prepost -> Dated_constraint.t -> Dated_constraint.t list
  val fetch_rule: string -> Arule.t
  val coarsest_precision: int Counters.MP.t
end


module Make (R:Rules_set.Rules_Set_sig) : Protocol_sig =
struct

  let sigma = R.sigma

  let get_init = R.init

(*   let letterwise_max_precision= R.letterwise_max_precision *)

  let get_bad = R.bad


  exception Meet
  let meet e set = 
    try
      List.iter (fun b -> if (Dated_constraint.do_meet sigma e b)
		 then raise Meet ) set; false
    with Meet -> true


  let meet_bad e = meet e R.bad 

  let meet_init e = meet e R.init

  let coarsest_precision = R.coarsest_precision

  let string_of =
    begin
      sprintf "%s:\ninitialy:%s\n%s\n" 
	R.name 
	(List.fold_left (fun acc i -> sprintf "%s %s" acc (Dated_constraint.string_of i)) "" R.init)
	(List.fold_left (fun acc r ->
			   sprintf "%s\n %s" acc (Arule.string_of r))
	   "" R.rules_set)
    end
      
  let next _prepost dcstr  = begin
    List.fold_left (fun acc r -> (Arule.next R.sigma _prepost r dcstr)@acc )  [] R.rules_set
  end

  exception Found_rule of Arule.t
  let fetch_rule name =
    try
      List.iter (fun e -> 
		   if (name = (Arule.string_of e)) 
		   then raise (Found_rule e)) R.rules_set;
      failwith(sprintf "Unknown rule in the caught trace: %s !" name)
    with | Found_rule e -> e
      
      
end

