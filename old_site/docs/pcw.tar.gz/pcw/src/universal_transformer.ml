open Printf

type t = {
  guard: Power_domain.t;
  action: Power_domain.t;
  gguard: Power_domain.t;
}


let create g a gg = begin
  { guard = g; action = a; gguard = gg  }
end


let string_of t = begin
  sprintf "Un[%s] %s -> %s" (Power_domain.string_of t.gguard) (Power_domain.string_of t.guard) (Power_domain.string_of t.action)
end

let next sigma _prepost t dcstr priority rule_name = begin
  Dated_constraint.universal sigma _prepost dcstr t.guard t.action t.gguard priority rule_name
end
