open Printf

let debug = Debug.fixpoint

let debug_long = Debug.fixpoint_long

module S = Minset.MinSet(Dated_constraint)



exception ReachedStopWitness of Dated_constraint.t
  (** Repeatedly apply (_gamma o _next) starting from _init
      untill no new constraints are generated or a constraint satisfying stop is reached, or (if _cut_off >= 0) there
      has been _cut_off applications of (_gamma o _next)  *)
let run ~init ~next ~gamma ~stop ~fixpoint_cut_off (* ~policy *) = begin
  if debug then printf "\nStarting Fixpoint\n";
  try
    if debug then printf "\n*********iteration=0**********\n";
    let _init = List.fold_left (fun acc i -> 
				  let gi = gamma i in
				  if stop gi then raise (ReachedStopWitness gi);
				  let _result,_,_,_ = S.insert acc gi
				  in _result) S.empty init in
    let working, visited = ref _init, ref _init in
(*       if debug then printf "initial working=%s\n     visited=%s" (S.string_of !working) (S.string_of !visited); *)
      if debug then printf "initial working=%d,     visited=%d \n" (S.size !working) (S.size !visited);
      let iterations_left = ref (fixpoint_cut_off) in 
	while (not(!iterations_left = 0) && not(S.is_empty !working)) do
(* 	  if debug then printf "\n*********iteration=%d**********\nworking=%s\nvisited=%s\n" (1+(fixpoint_cut_off) - !iterations_left) (S.string_of !working)(S.string_of !visited); *)
	  if debug then printf "\n*********iteration=%d**********\nworking=%d\nvisited=%d\ngenerated=%d\n" (1+(fixpoint_cut_off) - !iterations_left) (S.size !working)(S.size !visited)(!Debug.number_of_constraints);
	  iterations_left := !iterations_left - 1 ;
	  if debug_long then printf "\nworking before pop=%s " (S.string_of !working);
	  let current,_working = S.pop !working in 
	    working := _working;
	    if debug_long then printf "working after pop=%s\n" (S.string_of !working);
(* 	    if debug then printf "fixpoint current= %s\n" (Dated_constraint.string_of current);     *)
	    let _next = List.fold_left (fun acc e -> (gamma e)::acc) [] (next current) in
(* 	      if debug then printf "next of current= %s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (Dated_constraint.string_of e)) "" _next); *)
	      if debug then printf "next of current= %d\n" (List.length _next);
	      (List.iter (fun e ->
			    if not(Dated_constraint.entailed current e)
			    then begin
			      if stop e then raise (ReachedStopWitness e);
			      if debug_long then printf "inserting e=%s in visited=%s gives " (Dated_constraint.string_of e)(S.string_of !visited);
			      let _visited,inserted,removed,killer = S.insert !visited e (* policy *) in
				visited := _visited;
				if debug_long then printf "visted'=%s inserted=%b removed={%s} killer=%s\n" (S.string_of !visited)(inserted)(List.fold_left (fun acc e -> sprintf "%s %s" acc (Dated_constraint.string_of e))"" removed)(Dated_constraint.string_of killer);
				if inserted
				then begin
				  if not(List.mem e removed)
				  then let _working = S.blind_insert !working e in
				    working := S.filter_out (fun z -> List.mem z removed ) _working
				end
			    end
			 ) _next)
	done;
	(* 	  S.to_list !visited *)
	[]
  with ReachedStopWitness(witness) -> [witness]
end



  
