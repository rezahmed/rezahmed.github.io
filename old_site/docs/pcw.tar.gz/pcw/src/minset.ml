open Printf

(* type insert_policy = Entailment | Equality *)

module type Ordered = 
sig
  type t
(*   val equals: weak:t -> strong:t -> bool *)
  val entailed: weak:t -> strong:t -> bool
  val string_of: t -> string
  val weight: t -> int
end

(* ========================================================================================================= *)
(* =====================             Set of minimal elements                        ======================== *)
(* ========================================================================================================= *)

module type MinSet_sig = 
sig
  type elt
  type t
  val empty: t
  val is_certainly_included: t -> elt -> bool
  val size: t -> int
  val is_empty: t -> bool
  val string_of: t -> string
(*  val insert: t -> elt -> insert_policy -> t * bool * elt list * elt*)
  val insert: t -> elt -> t * bool * elt list * elt
  val blind_insert: t -> elt -> t
  val to_list: t -> elt list
  val iter: (elt -> unit) -> t -> unit
  val filter_out: (elt -> bool) -> t -> t
  val fold: ('a -> elt -> 'a) -> 'a -> t  -> 'a
(*   val clear: t -> unit *)
  val pop: t -> elt * t
(*  val insert_list_in_minset: t -> elt list -> insert_policy -> bool * t*)
  val insert_list_in_minset: t -> elt list -> bool * t
end


module MinSet (Elt:Ordered) : MinSet_sig with type elt = Elt.t = 
struct

    let debug = Debug.minset

    type elt = Elt.t

    type t = elt list
	  
    let empty = []

    let size (ms:t) = List.length ms

    let is_empty (ms:t) = match ms with [] -> true | _ -> false

    let string_of (ms:t) : string =
      sprintf "%s }\n" (List.fold_left (fun acc cons -> sprintf "%s %s" acc (Elt.string_of cons)) "{" ms)

    let blind_insert (ms:t) (element:elt) = begin
      let rec split_on_length (smaller:elt list) (larger:elt list) = begin
	match smaller,larger with
	  | _,hd::tl when (Elt.weight hd < Elt.weight element) -> split_on_length (smaller@[hd]) tl
	  | _ -> (smaller,larger)
      end in
      let before,after= split_on_length [] ms in 
	before@(element::after);
    end

    let pop (ms:t) = begin
      let rec lighter  prefix e suffix =
	match prefix, suffix with 
	  | _, [] -> e, prefix
	  | prefix, hd::tl -> if (Elt.weight hd < Elt.weight e)
	    then lighter (e::prefix) hd tl
	    else lighter (prefix@[hd]) e tl
      in lighter [] (List.hd ms) (List.tl ms)
    end
      
    exception EntailsSomeElement 
    let is_certainly_included (ms:t) (candidate:elt) = begin
      try
	List.iter (fun e -> if (Elt.entailed ~weak:e ~strong:candidate) 
		   then raise EntailsSomeElement) ms;
	false
      with EntailsSomeElement -> true
    end
      
    exception KilledBy of Elt.t
    (** insertion of an element is possible if it does not entail any memebr of the set, and results in 
	removing those entailing the element (i.e. those stronger).
	In this procedure, if the element was entailed by a member, then it can not entail any element as the set
	is supposed to be minimal to start with. In this case, we use "can be killed=false" to avoid, once the element
	has killed (i.e. was entailed by) a member, checking if it can be killed by (i.e., can entail) another member. 
	We also report on the (non empty If can be killed becomes false) list of killed members.
	If the element entails (i.e., is killed by) a member, then it is thrown away, and we report on the member.*)
    let insert (ms:t) (element:elt) (* (policy:insert_policy) *) : t * bool * elt list * elt = begin
      if debug
      then printf "*** inserting %s ****" (Elt.string_of element);
(*       let order = match policy with *)
(* 	| Entailment -> Elt.entailed *)
(* 	| equals -> Elt.equals *)
(*       in *)

      let order = Elt.entailed in

      let can_be_killed = ref true in
      let to_remove = ref [] in
	
      let inspect (acc:elt list) (current:elt) = begin
	if false then begin
	  Debug.print "\t\t\tcur:[1]%s | element:[2]%s | Can be killed: %B | 1 < 2: %B | 2 < 1: %B\n"
	    (Elt.string_of current) (Elt.string_of element) !can_be_killed
	    (order ~weak:current ~strong:element)
	    (order ~weak:element ~strong:current)
	end;

	if !can_be_killed && order ~weak:current ~strong:element then raise (KilledBy current);
	(* to be fixed: this second tour is useless for policy = equality*)
	if order ~weak:element ~strong:current
	then begin
	  can_be_killed := false;
	  if false then Debug.print "\t\t\t\t%s kills %s, I'm not keeping %s then \n" (Elt.string_of element) (Elt.string_of current) (Elt.string_of current);
	  to_remove := current::!to_remove;
 	  acc
	end else current::acc
      end in
	try
	  let result = element::(List.rev (List.fold_left inspect [] ms)) in
	    if debug then Debug.print "\t\t\t%s got inserted\n" (Elt.string_of element);
	    result,true,!to_remove, element
	with KilledBy killer ->
	  if debug then Debug.print "\t\t\t%s got killed by %s\n" (Elt.string_of element) (Elt.string_of killer);
	  match !to_remove with
	    | [] -> ms,false, !to_remove , killer 
	    | _  -> failwith("The minset was not minimal as an element entailed by some members turned out to entail another member!")
    end

    let iter (f: elt -> unit) (ms:t) = List.iter f ms

    let filter_out (rem: elt -> bool) (ms:t) = (List.filter (fun e -> not(rem e)) ms) 

    let fold (f: 'a -> elt -> 'a) (acc:'a) (ms:t)  =
      List.fold_left f acc ms
      
    let to_list (ms:t) = ms

(*     let clear (ms:t) : unit = begin *)
(*       ms.content <- []; *)
(*     end *)

    let insert_list_in_minset minset list (* policy *) =  
      begin 
	let inserted,resulting_minset = 
	  List.fold_left (fun (status,ms) e -> 
			    let new_minset,f,_,_ = insert ms e (*policy*)
			    in ((status || f),new_minset) ) (false,minset) list 
	in 
	  (inserted, resulting_minset)
      end 

  end
