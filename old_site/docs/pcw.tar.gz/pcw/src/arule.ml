open Printf

let debug = Debug.arule

type t = | Local of Local_transformer.t 
	 | Universal_left of Universal_transformer.t
	 | Universal_right of Universal_transformer.t
	 | Universal of Universal_transformer.t
	 | Existential_left of Existential_transformer.t
	 | Existential_right of Existential_transformer.t
	 | Existential of Existential_transformer.t


let from_local lt = Local(lt)

let from_universal_left ult = Universal_left(ult)
let from_universal_right ult = Universal_right(ult)
let from_universal ult = Universal(ult)
let from_existential_left ult = Existential_left(ult)
let from_existential_right ult = Existential_right(ult)
let from_existential ult = Existential(ult)


let string_of t = begin
  match t with 
    | Local(tr) -> Local_transformer.string_of tr
    | Universal_left(tr) -> sprintf "L%s" (Universal_transformer.string_of tr)
    | Universal_right(tr) -> sprintf "R%s" (Universal_transformer.string_of tr)
    | Universal(tr) -> sprintf "LR%s" (Universal_transformer.string_of tr)
    | Existential_left(tr) -> sprintf "L%s" (Existential_transformer.string_of tr)
    | Existential_right(tr) -> sprintf "R%s" (Existential_transformer.string_of tr)
    | Existential(tr) -> sprintf "LR%s" (Existential_transformer.string_of tr)
end


let next sigma _prepost t dcstr = begin
  if debug then 
    printf "\nfwd with %s\n    on %s\n" (string_of t) (Dated_constraint.string_of dcstr);
  let res = 
    match t with 
	Local(l) -> Local_transformer.next sigma _prepost l dcstr (string_of t)
      | Universal_left(l) -> Universal_transformer.next sigma _prepost l dcstr Constraint.Left (string_of t)
      | Universal_right(l) -> Universal_transformer.next sigma _prepost l dcstr Constraint.Right (string_of t)
      | Universal(l) -> Universal_transformer.next sigma _prepost l dcstr Constraint.LeftRight (string_of t)
      | Existential_left(l) -> Existential_transformer.next sigma _prepost l dcstr Constraint.Left (string_of t)
      | Existential_right(l) -> Existential_transformer.next sigma _prepost l dcstr Constraint.Right (string_of t)
      | Existential(l) -> Existential_transformer.next sigma _prepost l dcstr Constraint.LeftRight (string_of t)
  in
    if debug 
    then 
      begin
	printf "    arule gives: %s\n\n" 
	  (List.fold_left (fun acc e -> 
			     sprintf "%s %s" acc (Dated_constraint.string_of e)) 
	     "" res);
      end;
    res
end


