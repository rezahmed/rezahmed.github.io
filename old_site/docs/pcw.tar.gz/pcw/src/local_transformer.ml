open Printf

type t = {
  guard: Power_domain.t;
  action: Power_domain.t;
}



let create g a = begin
  { guard = g; action = a  }
end


let string_of t = begin
  sprintf "Lc: %s -> %s" (Power_domain.string_of t.guard) 
    (Power_domain.string_of t.action)
end

let next sigma _prepost t dcstr rule_name = begin
  Dated_constraint.local sigma _prepost dcstr t.guard t.action rule_name
end
