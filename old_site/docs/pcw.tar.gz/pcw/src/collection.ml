
open Printf

type t =  False
	  | True
	  | Node of (Letter.t * int) 
	  | And of (t list)
	  | Or of (t list)
	      

let debug = false

let rec string_of c = 
  match c with
    | True -> "T"
    | False -> "F"
    | Node (l,d) -> sprintf "<%s,%d>" (Letter.string_of l) d
    | And (lst) -> sprintf "(&%s)" (List.fold_left (fun acc e -> sprintf "%s%s" acc (string_of e)) "" lst)
    | Or (lst) -> sprintf "{|%s}" (List.fold_left (fun acc e -> sprintf "%s%s" acc (string_of e)) "" lst)



exception Absorbant

let rec percolate _c = 
  if debug 
  then printf "\n percolate input: %s" (string_of _c);
  let rec prune liste = 
    match liste with 
      | [] -> []
      | [hd] -> [hd]
      | hd::tl -> hd::(prune (List.filter (fun e -> not(e=hd)) tl))
  in
  let rec repeat c  = 
(*     printf "\n repeat = %s \n " (string_of c); *)
    match c with
      | False -> False, false (* false leaf in the and/or tree*)
      | True -> True, false (* true leaf in the tree*)
      | Node (l,d) -> Node (l,d),false  (* leaf in the tree*)
      | And (lst) -> begin 
	  try 
	    let filtered, changed  = 
	      List.fold_left (fun (acc,ch) e -> 
				match e with 
				  | False -> raise Absorbant
				  | True -> acc,true
				  | Node _ -> e::acc,ch
				  | And (and_list) -> 
				      ((List.fold_left (fun _acc _e -> (let _re,_ = repeat(_e) in _re::_acc)) [] and_list)@acc),true
				  | Or _  -> let _re, _ch = repeat(e)
				    in _re::acc,_ch || ch
			     ) ([],false) (prune lst)
	    in begin 
		match filtered with 
		  | [] -> True,true
		  | [hd] -> hd,true 
		  | _ -> And(filtered),changed 
	      end
	  with | Absorbant -> False,true
	end
      | Or (lst) -> begin 
	  try 
	    let filtered,changed  = 
	      List.fold_left ( fun (acc,ch) e -> 
				 match e with 
				   | False -> acc,true
				   | True -> raise Absorbant
				   | Node _ -> e::acc,ch
				   | Or (or_list) -> ((List.fold_left (fun _acc _e -> let _re,_= repeat(_e) in _re::_acc) [] or_list)@acc),true
				   | And _ -> let _re, _ch = repeat(e) in _re::acc, ch||_ch
			     ) ([],false) (prune lst)
	    in begin match filtered with 
	      | [] -> False,true
	      | [hd] -> hd,true 
	      | _ -> Or(filtered),changed 
	      end
	  with | Absorbant -> True,true
	end
  in let rslt,changed = repeat _c 
  in if changed 
    then percolate rslt
    else begin 
      if debug then printf "\n percolate output: %s\n" (string_of rslt);
      rslt
    end


let extract_precision _collection = 
  if debug 
  then printf "\n extract_precision input: %s " (string_of _collection);
  let weight precision = 
    Counters.MP.fold (fun _ bound acc -> acc + bound) precision 0
  in let rec pick collection = 
      match collection with 
	| Node (key,bound) -> Counters.MP.add key bound (Counters.MP.empty)
	| Or disjunction -> 
	    begin 
	      let possibilities = (List.fold_left (fun acc e -> (pick e)::acc) [] disjunction)
	      in match possibilities with 
		| [] -> failwith("empty disjuction after percolation")
		| hd::tl -> List.fold_left (fun acc e -> if weight(e) < weight(acc)
					    then e else acc ) hd tl
	    end
	| And conjunction -> 
	    begin
	      let requirements = (List.fold_left (fun acc e -> (pick e)::acc) [] conjunction)
	      in List.fold_left (
		  fun precision_accumulator req ->
		    Counters.MP.fold (
		      fun key bound acc -> 
			let max =  (List.fold_left (
				     fun bound_acc _req ->
				       try let _rbound = Counters.MP.find key _req
				       in if _rbound <= bound_acc
				       then bound_acc else _rbound
				       with | Not_found -> bound_acc
				   ) bound requirements)
			in Counters.MP.add key max precision_accumulator
		    ) req precision_accumulator
		) Counters.MP.empty requirements
	    end
	| _ -> failwith("non percolated collection") 
  in let result = pick _collection
  in if debug 
  then begin printf "\n extract_precision output: %s " (Counters.MP.fold (
					   fun key bound acc -> 
					     sprintf "%s %s->%d" acc (Letter.string_of key) bound) result "") end;
    result

	    


let disjunction_of_equalities_in_low_that_need_to_be_relaxed_to_meet_high ~low ~high = 
  let reasons = Counters.equalities_in_low_that_need_to_be_relaxed_to_meet_high low high 
  in  Or (List.fold_left (fun acc e -> (Node(e))::acc) [] reasons)


let disjunction_of_equalities_that_need_to_be_relaxed_to_allow_letter counter letter = 
  let reasons = Counters.equalities_that_need_to_be_relaxed_to_allow_letter counter letter
  in  Or (List.fold_left (fun acc e -> Node(e)::acc) [] reasons)


let false_leaf = False

let true_leaf = True

let build_or lst = Or (lst)

let build_and lst = And (lst)



(* (& (| (| (b,0)) *)
(*       (| (b,1)) *)
(*       (| (| (| (b,1)) *)
(*             (| (b,0)) *)
(*             1) *)
(*          11)) *)
(*    (| (& (| (| (b,0)) *)
(*          (| (b,1)) *)
(*          (| (| (| (b,1)) *)
(*                (| (b,0)) *)
(*                0) *)
(*             11)) *)
(*          (| (& 1  *)
(*                (| 1  *)
(*                   (| (b,0))) *)
(*                1) *)
(*             (| (b,0))) *)
(*          1) *)
(*        (| (b,0))) *)
(*     1) *)

