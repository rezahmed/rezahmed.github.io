open Printf

module D = Power_domain
module CSRT = Constraint
module LT = Local_transformer 
module UT = Universal_transformer
module ET = Existential_transformer
module DCSRT = Dated_constraint



module type Rules_Set_sig =
sig
  val name: string 
  val sigma: D.t
  val init: DCSRT.t list
  val bad: DCSRT.t list
  val rules_set: Arule.t list
  val coarsest_precision: int Counters.MP.t
end


module Simple : Rules_Set_sig = 
struct
  let a = Letter.create "a"
  let pa = D.create_from_set (D.LS.singleton a) 

  let b = Letter.create "b"
  let pb = D.create_from_set (D.LS.singleton b) 

  let c = Letter.create "c"
  let pc = D.create_from_set (D.LS.singleton c) 

  let sigma = D.join pc (D.join pa pb)

  let name = "simple"
  let init = [DCSRT.from_context_and_base sigma (D.join pa pc) [b;b] ]
  let bad = [DCSRT.from_context_and_base sigma (D.join pa pc) [b;b;b] ]
  let rules_set =
    [(* Arule.from_local(LT.create pa pb); *)
     Arule.from_local(LT.create pb pc)] 

    let precise = List.fold_left (fun acc e -> D.LS.add e acc ) D.LS.empty []    

    let coarsest_precision = 
      D.fold (fun _key m -> if D.LS.mem _key precise
	      then Counters.MP.add _key 1 m
	      else Counters.MP.add _key 0 m) Counters.MP.empty sigma
end



module Burns : Rules_Set_sig =
struct
    let _10 = D.create_from_set (D.LS.singleton (Letter.create "10")) 
    let _20 = D.create_from_set (D.LS.singleton (Letter.create "20")) 
    let _30 = D.create_from_set (D.LS.singleton (Letter.create "30")) 
    let _40 = D.create_from_set (D.LS.singleton (Letter.create "40")) 
    let _50 = D.create_from_set (D.LS.singleton (Letter.create "50")) 
    let _60 = D.create_from_set (D.LS.singleton (Letter.create "60")) 
    let _70 = D.create_from_set (D.LS.singleton (Letter.create "70")) 
    let _11 = D.create_from_set (D.LS.singleton (Letter.create "11")) 
    let _21 = D.create_from_set (D.LS.singleton (Letter.create "21")) 
    let _31 = D.create_from_set (D.LS.singleton (Letter.create "31")) 
    let _41 = D.create_from_set (D.LS.singleton (Letter.create "41")) 
    let _51 = D.create_from_set (D.LS.singleton (Letter.create "51")) 
    let _61 = D.create_from_set (D.LS.singleton (Letter.create "61")) 
    let _71 = D.create_from_set (D.LS.singleton (Letter.create "71")) 
    let _1 = D.join _10 _11 
    let _3 = D.join _30 _31 
    let _6 = D.join _60 _61 
    let _X1 = D.join _11 (D.join _21 (D.join _31 (D.join _41 (D.join _51 (D.join _61 _71))))) 
    let _X0 = D.join _10 (D.join _20 (D.join _30 (D.join _40 (D.join _50 (D.join _60 _70))))) 
    let sigma = D.join _X0 _X1

    let name = "burns"
    let bad = let _6161 = DCSRT.from_context_and_base sigma sigma [(Letter.create "61");(Letter.create "61")] 
    in [_6161] 
    let init = [DCSRT.from_context_and_base sigma _10 [(Letter.create "10")]]
    let rules_set = 
      [
	Arule.from_local (LT.create _1 _20);
	Arule.from_existential_left(ET.create _20 _10 _11);
	Arule.from_universal_left(UT.create _20 _30 _X0 );
	Arule.from_local (LT.create _3 _41);
	Arule.from_existential_left(ET.create _41 _11 _X1);
	Arule.from_universal_left(UT.create _41 _51 _X0 );
	Arule.from_universal_right(UT.create _51 _61 _X0 );
	Arule.from_local (LT.create _6 _70);
        Arule.from_local (LT.create _70 _10)
      ]

    let precise = List.fold_left (fun acc e -> D.LS.add e acc ) D.LS.empty []    
    let coarsest_precision = 
      D.fold (fun _key m -> if D.LS.mem _key precise
	      then Counters.MP.add _key 1 m
	      else Counters.MP.add _key 0 m) Counters.MP.empty sigma
end


module Szymanski : Rules_Set_sig =
struct
  (*pc.a.w.s*)
  let _0000 = Letter.create "0000"
  let _1100 = Letter.create "1100"
  let _2100 = Letter.create "2100"
  let _3111 = Letter.create "3111"
  let _4110 = Letter.create "4110"
  let _5101 = Letter.create "5101"
  let _6101 = Letter.create "6101"
  let _7101 = Letter.create "7101"


  let d_0000 = D.create_from_set (D.LS.singleton _0000)
  let d_1100 = D.create_from_set (D.LS.singleton _1100)
  let d_2100 = D.create_from_set (D.LS.singleton _2100)
  let d_3111 = D.create_from_set (D.LS.singleton _3111)
  let d_4110 = D.create_from_set (D.LS.singleton _4110)
  let d_5101 = D.create_from_set (D.LS.singleton _5101)
  let d_6101 = D.create_from_set (D.LS.singleton _6101)
  let d_7101 = D.create_from_set (D.LS.singleton _7101)

  let d_s0 = D.join (D.join d_0000 d_1100) (D.join d_2100 d_4110)
  let d_s1 = D.join (D.join d_3111 d_5101) (D.join d_6101 d_7101)

  let d_w1 = D.join d_3111 d_4110
  let d_w0 = D.join (D.join (D.join d_0000 d_1100) (D.join d_2100 d_5101)) (D.join d_6101 d_7101)

  let d_a0 = d_0000
  let d_a1 = D.join (D.join (D.join (D.join d_1100 d_2100) (D.join d_3111 d_4110)) (D.join d_5101 d_6101)) d_7101  

  let sigma = D.join d_s0 d_s1


  let name = "szymanski"
  let bad = let c_7101_7101 = DCSRT.from_context_and_base sigma sigma [_7101;_7101] 
  in [c_7101_7101] 
  let init = [DCSRT.from_context_and_base sigma d_0000 [_0000]]
  let rules_set = 
    [
      Arule.from_local (LT.create d_0000 d_1100); (*t1*)
      Arule.from_universal(UT.create d_1100 d_2100 d_s0); (*t2*)
      Arule.from_local (LT.create d_2100 d_3111); (*t3*)
      Arule.from_universal(UT.create d_3111 d_5101 (D.join d_a0 d_w1)); (*t6*)
      Arule.from_existential(ET.create d_3111 d_4110 (D.meet d_a1 d_w0)); (*t4*)
      Arule.from_existential(ET.create d_4110 d_5101 (D.meet d_s1 d_w0)); (*t5*)
      Arule.from_universal(UT.create d_5101 d_6101 d_w0); (*t7*)
      Arule.from_universal_left(UT.create d_6101 d_7101 d_s0); (*t8*)
      Arule.from_local (LT.create d_7101 d_0000) (*t9*)
      ]

    let precise = List.fold_left (fun acc e -> D.LS.add e acc ) D.LS.empty []    
    let coarsest_precision = 
      D.fold (fun _key m -> if D.LS.mem _key precise
	      then Counters.MP.add _key 1 m
	      else Counters.MP.add _key 0 m) Counters.MP.empty sigma

end


module RSzymanski : Rules_Set_sig =
struct
    let _0 = D.create_from_set (D.LS.singleton (Letter.create "0")) 
    let _1 = D.create_from_set (D.LS.singleton (Letter.create "1")) 
    let _2 = D.create_from_set (D.LS.singleton (Letter.create "2")) 
    let _3 = D.create_from_set (D.LS.singleton (Letter.create "3")) 
    let _4 = D.create_from_set (D.LS.singleton (Letter.create "4")) 
    let _5 = D.create_from_set (D.LS.singleton (Letter.create "5")) 
    let _6 = D.create_from_set (D.LS.singleton (Letter.create "6")) 
    let _7 = D.create_from_set (D.LS.singleton (Letter.create "7")) 
    let _8 = D.create_from_set (D.LS.singleton (Letter.create "8")) 
    let _9 = D.create_from_set (D.LS.singleton (Letter.create "9")) 
    let _10 = D.create_from_set (D.LS.singleton (Letter.create "10")) 
    let _11 = D.create_from_set (D.LS.singleton (Letter.create "11")) 
    let _f0 = D.join _0 _1 
    let _f1 = D.join _2 _3 
    let _f2 = D.join _7 _8
    let _f3 = D.join (D.join _4 _5) _6
    let _f4 = D.join (D.join _9 _10) _11 
    let _f01 = D.join _f0 _f1
    let _f012 = D.join _f01 _f2
    let _f014 = D.join _f01 _f4
    let _f0234 = D.join (D.join _f0 _f2) (D.join _f3 _f4)
    let sigma = D.join _f1 _f0234

    let name = "RSzymanski"
    let bad = let _1010 = DCSRT.from_context_and_base sigma sigma [(Letter.create "10");(Letter.create "10")] 
    in [_1010] 
    let init = [DCSRT.from_context_and_base sigma _0 [(Letter.create "0")]]
    let rules_set = 
      [
	Arule.from_local (LT.create _0 _1);
	Arule.from_local (LT.create _1 _2);
	Arule.from_universal(UT.create _2 _3 _f012);
	Arule.from_local (LT.create _3 _4);
	Arule.from_existential(ET.create _4 _6 _f1);
	Arule.from_local (LT.create _6 _7);
	Arule.from_existential(ET.create _7 _8 _f4);
	Arule.from_local (LT.create _8 _9);
	Arule.from_universal(UT.create _4 _5 _f0234);
	Arule.from_local (LT.create _5 _9);
	Arule.from_universal_left(UT.create _9 _10 _f01);
	Arule.from_universal_right(UT.create _10 _11 _f014);
	Arule.from_local (LT.create _11 _0);
      ]

    let precise = List.fold_left (fun acc e -> D.LS.add e acc ) D.LS.empty []    
    let coarsest_precision = 
      D.fold (fun _key m -> if D.LS.mem _key precise
	      then Counters.MP.add _key 1 m
	      else Counters.MP.add _key 0 m) Counters.MP.empty sigma

end


module GZenner : Rules_Set_sig =
struct
    let _1 = D.create_from_set (D.LS.singleton (Letter.create "1")) 
    let _2 = D.create_from_set (D.LS.singleton (Letter.create "2")) 
    let _3 = D.create_from_set (D.LS.singleton (Letter.create "3")) 
    let _4 = D.create_from_set (D.LS.singleton (Letter.create "4")) 
    let _5 = D.create_from_set (D.LS.singleton (Letter.create "5")) 
    let _6 = D.create_from_set (D.LS.singleton (Letter.create "6")) 
    let _7 = D.create_from_set (D.LS.singleton (Letter.create "7")) 
    let _8 = D.create_from_set (D.LS.singleton (Letter.create "8")) 
    let _9 = D.create_from_set (D.LS.singleton (Letter.create "9")) 
    let _10 = D.create_from_set (D.LS.singleton (Letter.create "10")) 
    let _11 = D.create_from_set (D.LS.singleton (Letter.create "11")) 
    let _12 = D.create_from_set (D.LS.singleton (Letter.create "12")) 
    let _13 = D.create_from_set (D.LS.singleton (Letter.create "13")) 
    let _1_2_3_4_7_8 = D.join (D.join (D.join _1 _2)  (D.join _3 _4)) (D.join _7 _8)
    let _3_4_10_11_12_13 = D.join (D.join (D.join _3 _4) (D.join _10 _11)) (D.join _12 _13)
    let _10_11_12_13 = D.join (D.join _10 _11) (D.join _12 _13)
    let _1_2_5_6_7_8_9 = D.join (D.join (D.join _1 _2) (D.join _5 _6)) (D.join (D.join _7 _8) _9)
    let _1_2_3_4_10_11_12_13 = D.join (D.join (D.join _1 _2) (D.join _3 _4)) (D.join (D.join _10 _11) (D.join _12 _13))
    let _1_2_3_4_7_8 = D.join (D.join (D.join _1 _2) (D.join _3 _4)) (D.join _7 _8)

    let sigma = D.join _1_2_3_4_10_11_12_13 _1_2_5_6_7_8_9
      
    let name = "GZenner"
    let bad = let _1212 = DCSRT.from_context_and_base sigma sigma [(Letter.create "12");(Letter.create "12")] 
    in [_1212] 
    let init = [DCSRT.from_context_and_base sigma _1 [(Letter.create "1")]]
    let rules_set = 
      [
	Arule.from_local (LT.create _1 _2);
	Arule.from_local (LT.create _2 _3);
	Arule.from_universal(UT.create _3 _4 _1_2_3_4_7_8);
	Arule.from_local (LT.create _4 _5);
	Arule.from_existential(ET.create _5 _6 _3_4_10_11_12_13);
	Arule.from_local (LT.create _6 _7);
	Arule.from_existential(ET.create _7 _8 _10_11_12_13);
	Arule.from_local (LT.create _8 _9);
	Arule.from_universal(UT.create _5 _9 _1_2_5_6_7_8_9);
	Arule.from_local (LT.create _9 _10);
	Arule.from_universal(UT.create _10 _11 _1_2_3_4_10_11_12_13);
	Arule.from_universal_left(UT.create _11 _12 _1_2_3_4_7_8);
	Arule.from_local (LT.create _12 _13);
	Arule.from_local (LT.create _13 _1);
      ]

    let precise = List.fold_left (fun acc e -> D.LS.add e acc ) D.LS.empty [Letter.create "3"; Letter.create "4";
									    Letter.create "5"; Letter.create "6";
									    Letter.create "7"; Letter.create "8";
									    Letter.create "9"; Letter.create "10"; 
									    Letter.create "11";Letter.create "12"]    
    let coarsest_precision = 
      D.fold (fun _key m -> if D.LS.mem _key precise
	      then Counters.MP.add _key 0 m
	      else Counters.MP.add _key 0 m) Counters.MP.empty sigma
end


