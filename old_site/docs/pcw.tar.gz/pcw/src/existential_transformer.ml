open Printf

type t = {
  guard: Power_domain.t;
  action: Power_domain.t;
  witness: Power_domain.t;
}


let create g a w = begin
  { guard = g; action = a; witness = w  }
end


let string_of t = begin
  sprintf "Ex[%s] %s -> %s" (Power_domain.string_of t.witness)(Power_domain.string_of t.guard) (Power_domain.string_of t.action)
end


let next sigma _prepost t cstr prior rule_name = begin
  Dated_constraint.exists sigma _prepost cstr t.guard t.action t.witness prior rule_name
end


