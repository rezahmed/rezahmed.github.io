
open Printf 

let say_not_reachable bads inits name = 
  printf "The set %s is not reachable from %s in the protocol %s\n" 
    (List.fold_left (fun acc e -> sprintf "%s %s" acc (Dated_constraint.string_of e)) "" bads) 
    (List.fold_left (fun acc e -> sprintf "%s %s" acc (Dated_constraint.string_of e)) "" inits) 
    name


let say_reachable bads inits name trace = 
  printf "The set %s is reachable from %s in the protocol %s through %s\n" 
    (List.fold_left (fun acc e -> sprintf "%s %s" acc (Dated_constraint.string_of e)) "" bads) 
    (List.fold_left (fun acc e -> sprintf "%s %s" acc (Dated_constraint.string_of e)) "" inits) 
    name trace 

  
let _ = 
  let treat name sigma mode init meet_init next bad meet_bad coarsest fetch_rule intbound = begin
(*     let coarsest = Power_domain.fold (fun _key m -> Counters.MP.add _key 0 m) Counters.MP.empty (sigma) in *)
      try 
	match mode with 
	  | "Post" -> Refinement.refinement_loop (sigma) (Constraint.Post) (init) (meet_init) (next) (bad) (meet_bad) (fetch_rule) (coarsest) (intbound) 
	  | "Pre" ->  Refinement.refinement_loop (sigma) (Constraint.Pre) (init) (meet_init) (next) (bad) (meet_bad) (fetch_rule) (coarsest) (intbound) 
	  | _ -> 	raise (Invalid_argument "")
      with | Refinement.Not_reachable -> say_not_reachable (bad) (init) name
	| Refinement.Reachable dcstr -> say_reachable (bad) (init) name (Dated_constraint.string_of dcstr)
  end
  in try
      match Sys.argv.(1), Sys.argv.(2), Sys.argv.(3) with
	| "Simple", bound, mode -> let module Prt = Protocol.Make(Rules_set.Simple) 
	  in treat (Sys.argv.(1)) (Prt.sigma) (mode) (Prt.get_init) (Prt.meet_init) 
	       (Prt.next) (Prt.get_bad) (Prt.meet_bad) (Prt.coarsest_precision) (Prt.fetch_rule) (int_of_string bound)
	| "Burns", bound, mode -> let module Prt = Protocol.Make(Rules_set.Burns) 
	  in treat (Sys.argv.(1)) (Prt.sigma) (mode) (Prt.get_init) (Prt.meet_init) 
	       (Prt.next) (Prt.get_bad) (Prt.meet_bad) (Prt.coarsest_precision) (Prt.fetch_rule) (int_of_string bound)
	| "Szymanski", bound, mode -> let module Prt = Protocol.Make(Rules_set.Szymanski) 
	  in treat (Sys.argv.(1)) (Prt.sigma) (mode) (Prt.get_init) (Prt.meet_init) 
	       (Prt.next) (Prt.get_bad) (Prt.meet_bad) (Prt.coarsest_precision) (Prt.fetch_rule) (int_of_string bound)
	| "RSzymanski", bound, mode -> let module Prt = Protocol.Make(Rules_set.RSzymanski) 
	  in treat (Sys.argv.(1)) (Prt.sigma) (mode) (Prt.get_init) (Prt.meet_init) 
	       (Prt.next) (Prt.get_bad) (Prt.meet_bad) (Prt.coarsest_precision) (Prt.fetch_rule) (int_of_string bound)
	| "GZenner", bound, mode -> let module Prt = Protocol.Make(Rules_set.GZenner) 
	  in treat (Sys.argv.(1)) (Prt.sigma) (mode) (Prt.get_init) (Prt.meet_init) 
	       (Prt.next) (Prt.get_bad) (Prt.meet_bad) (Prt.coarsest_precision) (Prt.fetch_rule) (int_of_string bound)
	| _ -> 	raise (Invalid_argument "")
    with
      | Invalid_argument s ->
	  print_string "syntax :  ./pcw prgName bound mode
             use -1 as bound for a bound free analysis
             prgName in {Simple,Burns,Szymanski,RSzymanski,GZenner}
             mode in {Post,Pre}
             e.g. \"./pcw Burns -1 Post\" \n"
	    




