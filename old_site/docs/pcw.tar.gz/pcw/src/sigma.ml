
(**
   run with:
   let c = V.get_base ()  in
   V.nextc c; 
   V.nextc c; 
   let c' = V.get_base () in
   V.nextc c'; 
   V.nextc c; 
   V.nextc c; 
   V.next ();  
   V.next ();
   V.next ();
   V.next ();
*)

open Printf

module D = Power_domain 

module type SIGMA_sig =
sig
  val set: D.t -> unit
  val reset: unit
  val get: unit -> D.t
  val add: Letter.t -> unit
end


module S:SIGMA_sig =
struct 
  type t  = {mutable base:D.t}
  let base = {base=D.bottom}
  let set x = base.base <- x
  let reset  = base.base <- D.bottom
  let get () = base.base
  let base_to_string x = D.string_of x.base
  let add l = base.base <- D.join base.base (D.create_from_letter l)
end




  
