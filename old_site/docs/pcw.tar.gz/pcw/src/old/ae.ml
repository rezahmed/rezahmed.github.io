
open Printf

module D = Power_domain 

module C = Counters

let debug_entail = Debug.constraint_entail
let debug_meet = Debug.constraint_meet

let debug_long = Debug.constraint_long


(* type prepost = Pre | Post *)

(* type priority = Left | Right | LeftRight *)

type al = C.t * Letter.t * C.t

type t = Bottom | Top | Base of (al list)

let _top = Top

let _bottom = Bottom

let base_length t =  
  match t with
    | Bottom -> failwith("denotes empty set and base undefined")
    | Top -> failwith("denotes all words and base undefined")
    | Base(b) -> List.length b


let is_bottom t = 
  match t with
    | Bottom -> true
    | _ -> false 
	    
let is_top t = 
  match t with
    | Top -> true
    | _ -> false 
	
let create_from_a_letter_among l s = 
  let c = C.all_zero () in
    [(c,l,c)]

let from_base _base =
  let zc = C.all_zero () 
  in let rec left_to_right _b _c  =
      match _b with
	| [] -> failwith("cannot handle empty base")
	| [hd] -> [(_c,hd,zc)],(C.increment zc hd)
	| hd::tl -> let _b',_c' = left_to_right tl (C.increment _c hd) in
	    ((_c,hd,_c')::_b'),(C.increment _c' hd)
  in match _base with
    | [] -> failwith("cannot make an abstract element out of an empty base, consider splitting on non empty bases")
    | hd::tl -> let _base',_ = left_to_right _base zc in Base(_base')
								  

let from_context_and_base context base =
  assert(Power_domain.entailed (Sigma.S.get()) context);
  let fbase = from_base base in
  let add_context e =
    match e with
      | Top -> failwith("should not add context to a top")
      | Bottom -> failwith("should not add context to a bottom")
      | Base(b) -> List.fold_left (fun acc (lc,q,rc) -> (C.add_context lc context,q,C.add_context rc context)::acc ) [] b  
  in Base(add_context fbase)




let string_of t = begin
  let s = match t with 
    | Bottom -> "bot\n"
    | Top -> "top\n"
    | Base(lst) -> List.fold_left (fun acc (l,q,r) ->
				       sprintf "%s (%s %s %s)" acc (C.string_of l) (Letter.string_of q) (C.string_of r))
	  "[" lst
  in sprintf "%s]\n" s
end

let gamma_counters_cut_off cstr k = begin
  match cstr with 
    | Bottom -> Bottom
    | Top -> Top
    | Base(base) -> Base(List.fold_left (fun acc (lc,q,rc) -> (C.cut_off lc k, q, C.cut_off rc k)::acc ) [] base)
end

let do_meet a b =
  if debug_meet
  then printf "\nmeet a=%s \nand b=%s\n" (string_of a) (string_of b);
  let rec check base base' =
    match base,base' with
      | [(l,q,r)], [(l',q',r')] ->  	  
	  ( ((C.do_meet l l') && q=q' && (C.do_meet r r')) ||
	      ((C.do_meet (C.increment l q) l') && (C.do_meet r (C.increment r' q'))) ||
	      ((C.do_meet (C.increment l' q') l) && (C.do_meet r' (C.increment r q))) )
      | (l,q,r)::tl, [(l',q',r')] ->     
	  ( ((C.do_meet l l') && q=q' && (C.do_meet r r')) ||
	      ((C.do_meet (C.increment l q) l') && (C.do_meet r (C.increment r' q')) && check tl base') )
      | [(l,q,r)], (l',q',r')::tl' ->     
	  ( ((C.do_meet l l') && q=q' && (C.do_meet r r')) ||
	      ((C.do_meet (C.increment l' q') l) && (C.do_meet r' (C.increment r q)) && check base tl') )
      | (l,q,r)::tl, (l',q',r')::tl' ->     
	  ( ((C.do_meet l l') && q=q' && (C.do_meet r r') && check tl tl') ||
	      ((C.do_meet (C.increment l q) l') && (C.do_meet r (C.increment r' q')) && check tl base') ||
	      ((C.do_meet (C.increment l' q') l) && (C.do_meet r' (C.increment r q)) && check base tl') )
      | _ -> failwith("I do not see how we can get here")
  in
    match a,b with
      | Bottom, _ -> false
      | _, Bottom -> false
      | Top, _ -> true
      | _, Top -> true
      | Base([]), _ -> failwith("A base cannot be empty")
      | _, Base([]) -> failwith("A base cannot be empty")
      | Base(base),Base(base') -> check base base'


(** Returns whether there exists an injection from the weak to the strong
    * *)
let rec entailed ~weak ~strong  =
  if debug_entail
  then printf "\nentailed weak=%s \nby strong=%s\n" (string_of weak) (string_of strong);
  let rec check base base' = 
    match base,base' with
      | [(l,q,r)], [(l',q',r')] ->  	  
	  ( ((C.entailed l l') && q=q' && (C.entailed r r')) ||
	      ((C.entailed (C.increment l q) l') && (C.entailed r (C.increment r' q'))) ||
	      ((C.entailed l (C.increment l' q')) && (C.entailed (C.increment r q) r')) )
      | (l,q,r)::tl, [(l',q',r')] ->     
	  ( ((C.entailed l l') && q=q' && (C.entailed r r')) ||
	      ((C.entailed (C.increment l q) l') && (C.entailed r (C.increment r' q')) && check tl base') )
      | [(l,q,r)], (l',q',r')::tl' ->     
	  ( ((C.entailed l l') && q=q' && (C.entailed r r')) ||
	      ((C.entailed l (C.increment l' q')) && (C.entailed (C.increment r q) r') && check base tl') )
      | (l,q,r)::tl, (l',q',r')::tl' ->     
	  ( ((C.entailed l l') && q=q' && (C.entailed r r') && check tl tl') ||
	      ((C.entailed (C.increment l q) l') && (C.entailed r (C.increment r' q')) && check tl base') ||
	      ((C.entailed l (C.increment l' q')) && (C.entailed (C.increment r q) r') && check base tl') )
      | _ -> failwith("I do not see how we can get here")
  in match weak, strong with
    | Bottom, _ -> false
    | _, Bottom -> true
    | Top, _ -> true
    | _, Top -> false
    | Base([]), _ -> failwith("A base cannot be empty")
    | _, Base([]) -> failwith("A base cannot be empty")
    | Base(base),Base(base') -> check base base'


let local _prepost cstr _grd _act = 
  if debug_long
  then printf "local:post=%b,guard=%s,action=%s on cstr=%s" (match _prepost with | Constraint.Pre -> false | Constraint.Post -> true)
    (D.string_of _grd) (D.string_of _act) (string_of cstr) ;
  let grd,act = match _prepost with
    | Constraint.Post -> _grd,_act
    | Constraint.Pre -> _act,_grd
  in let _zadj e = e  
  in let rec propagate_counter_adjustment _base _ladj _radj =
      match _base with
	| [] -> failwith("I do not see how we could get here")
	| [(l, q, r)] -> [(_ladj l, q, _radj r)]
	| (l, q, r)::tl -> (_ladj l, q, _radj r)::(propagate_counter_adjustment tl _ladj _radj)
  in let rec operate _prefix _suffix =
      match _suffix with 
	| [] -> failwith("I do not see how we could get here")
	| [(l,q,r)] when D.member q grd -> D.fold (fun q' acc -> [(l,q',r)]::acc ) [] act
	| (l,q,r)::tl when D.member q grd -> 
	    D.fold (fun q' acc -> let _adj z = (C.decrement (C.increment z q') q) 
		    in  ((propagate_counter_adjustment _prefix _zadj _adj)@((l,q',r)::(propagate_counter_adjustment tl _adj _zadj)))::acc
		   ) [] act
	| hd::tl -> operate (_prefix@[hd]) tl
  in
  let result =
    match cstr with
      | Bottom -> []
      | Top -> D.fold (fun q acc -> (from_context_and_base (Sigma.S.get()) [q])::acc ) [] act
      | Base([]) -> failwith("A base cannot be empty")
      | Base(base) -> let brut = operate [] base in List.fold_left (fun acc _base -> Base(_base)::acc) [] brut
  in
    if debug_long
    then printf " gives: \n %s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" result);
    result

let exists _prepost cstr _guard _action witness prior = 
  local _prepost cstr _guard _action

let universal _prepost cstr _guard _action gguard prior = 
  local _prepost cstr _guard _action

(* Used as a weight in Fixpoint. All those abstract elements whose weight (ex. base length) is longer than max_weight will be assigned the same
   priority by the fixpoint*)
let max_weight = 100

let weight cstr = 
    match cstr with
      | Bottom -> max_weight
      | Top -> 0 
      | Base([]) -> failwith("A base cannot be empty")
      | Base(base) -> let length = List.length base in 
	  min length max_weight

(* let appendContent t elt ctxt =   *)
(*   if is_bottom t then bottom *)
(*   else (t@[elt]@[ctxt]) *)

(* let merge t = List.fold_left (fun acc e -> match e with  *)
(* 				| Content(ct) -> D.join acc ct *)
(* 				| Context(cx) -> D.join acc cx ) (D.bottom) t *)

(* let gamma_one_context cstr = begin *)
(*   let context = merge cstr in *)
(*   let rec replace c =  *)
(*     match c with  *)
(*       | [Context(d)] -> [Context(context)] *)
(*       | hd::tl ->  *)
(* 	  begin   *)
(* 	    match hd,tl with *)
(* 	      | Context(cx),hd'::tl' ->  *)
(* 		  begin  *)
(* 		    match hd' with  *)
(* 		      | Content(ct) -> Context(context)::(Content(ct)::(replace tl')) *)
(* 		      | _ -> failwith("malformed constraint passed to gamma_one_context approximation") *)
(* 		  end *)
(* 	      | _ -> failwith("malformed constraint passed to gamma_one_context approximation") *)
(* 	  end *)
(*       | _ -> failwith("malformed constraint passed to gamma_one_context approximation") *)
(*   in *)
(*     replace cstr *)
(* end *)



(* let rec merge_base cstr =  *)
(*   assert(well_formed cstr); *)
(*   if is_bottom cstr || is_top cstr then D.bottom *)
(*   else *)
(*     match cstr with *)
(*       | [Context(cx)] -> D.bottom *)
(*       | Context(cx)::tl ->  *)
(* 	  begin  *)
(* 	    match tl with *)
(* 	      | Content(ct)::tl' -> D.join ct (merge_base tl') *)
(* 	      | _ -> failwith("should not have gotten here") *)
(* 	  end *)
(*       | _ -> failwith("should not have gotten here") *)
      

(* let rec do_meet a b = *)
(*   if debug_meet  *)
(*   then printf "\nmeet a=%s \nand b=%s\n" (string_of a) (string_of b); *)
(*   assert(well_formed a); *)
(*   assert(well_formed b); *)
(*   let result =  *)
(*     if is_bottom a || is_bottom b then false *)
(*     else if is_top a || is_top b then true *)
(*     else begin *)
(*       match a,b with *)
(* 	| [Context(cxa)],[Context(cxb)] -> D.do_meet cxa cxb  *)
(* 	| [Context(cxa)],hdb::tlb -> D.entailed cxa (merge_base b) *)
(* 	| hda::tla,[Context(cxb)] -> D.entailed (merge_base a) cxb  *)
(* 	| Context(cxa)::tla,Context(cxb)::tlb -> *)
(* 	    begin *)
(* 	      match tla,tlb with *)
(* 		| Content(cta)::tla', Content(ctb)::tlb' -> *)
(* 		    begin *)
(* 		      ((D.do_meet cta cxb) && (do_meet tla' b)) *)
(* 		      || *)
(* 			((D.do_meet cta ctb) && (do_meet tla' tlb')) *)
(* 		      || *)
(* 			((D.do_meet cxa ctb) && (do_meet a tlb')) *)
(* 		    end *)
(* 		| _ -> failwith("should not have gotten here") *)
(* 	    end *)
(* 	| _ -> failwith("should not have gotten here") *)
(*     end *)
(*   in  *)
(*     if debug_meet *)
(*     then printf "gives %b\n" result; *)
(*     result *)


(* (\** Returns whether there exists an injection from the weak to the strong  *)
(*     * weak: x0c1x1...xn, strong: x0'c1'...xm' *)
(*     * *\) *)
(* let rec entailed ~weak ~strong  =  *)
(*   if debug_entail  *)
(*   then printf "\nentailed weak=%s \nby strong=%s\n" (string_of weak) (string_of strong); *)
(*   assert(well_formed weak); *)
(*   assert(well_formed strong); *)
(*   let result =  *)
(*     if is_bottom strong || is_top weak then true *)
(*     else if List.length strong < List.length weak then false (\* no possible injection *\) *)
(*     else  *)
(*       begin *)
(* 	match weak,strong with *)
(* 	  | [Context(hx)], _ -> D.entailed hx (merge strong) (\*  *\) *)
(* 	  | Context(hx)::_,Context(hx')::_ when not(D.entailed hx hx') -> false (\* x0' not in x0 *\) *)
(* 	  | Context(hx)::tlx,hx'::tlx' -> begin *)
(* 	      match tlx,tlx' with *)
(* 		| Content(hc)::tlc,Content(hc')::tlc'-> (  *)
(* 		    ((D.entailed hc hc') && (entailed ~weak:tlc ~strong:tlc'))  *)
(* 		    || ((D.entailed hx hc') && (entailed ~weak:weak ~strong:tlc')) )  *)
(* 		| _ -> failwith("I do not see how we can get here in the entailment") *)
(* 	    end *)
(* 	  | _ -> failwith("I do not see how we can get here in the entailment") *)
(*       end *)
(*   in  *)
(*     if debug_entail *)
(*     then printf " is %b\n\n" result; *)
(*     result *)

(* let equals ~weak ~strong = (entailed weak strong) && (entailed strong weak) *)
      

(* let local _prepost cstr _grd _act = begin *)
(*   assert(well_formed cstr); *)
(*   if false *)
(*   then printf "local:post=%b,guard=%s,action=%s on cstr=%s" (match _prepost with | Pre -> false | _ -> true)  *)
(*     (D.string_of _grd) (D.string_of _act) (string_of cstr) ; *)
(*   if is_bottom cstr then [] *)
(*   else  *)
(*     let grd,act = match _prepost with *)
(*       | Post -> _grd,_act *)
(*       | Pre -> _act,_grd *)
(*     in *)
(*     let rec left_to_right pref suff = begin *)
(*       match suff with *)
(* 	| [] -> [] *)
(* 	| hd::tl -> begin  *)
(* 	    match hd with *)
(* 	      | Content(ct) when D.do_meet grd ct ->  *)
(* 		  ((pref@[Content(act)])@tl) *)
(* 		  :: left_to_right (pref@[hd]) tl *)
(* 	      | Context(cx) when D.do_meet grd cx ->  *)
(* 		  let jn = D.join (D.join act cx) act *)
(* 		  in (pref@(Context(jn)::tl)) *)
(* 		     ::left_to_right (pref@[hd]) tl *)
(* 	      | Context(cx)  ->  *)
(* 		  if false *)
(* 		  then printf "\ngrd does not meet cx. cx=%s,grd=%s,act=%s\n" (D.string_of cx) (D.string_of grd) (D.string_of act); *)
(* 		  left_to_right (pref@[hd]) tl *)
(* 	      | Content(ct)  ->  *)
(* 		  if false *)
(* 		  then printf "\ngrd does not meet ct. ct=%s,grd=%s,act=%s\n" (D.string_of ct) (D.string_of grd) (D.string_of act); *)
(* 		  left_to_right (pref@[hd]) tl *)
(* 	  end *)
(*     end *)
(*     in  *)
(*     let res = left_to_right [] cstr *)
(*     in *)
(*       if false  *)
(*       then printf "gives: \n %s" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" res); *)
(*       res *)
(* end *)

(****)

(* let exists _prepost cstr _guard _action witness prior = begin *)
(*   assert(well_formed cstr); *)
(*   if is_bottom cstr then [] *)
(*   else *)
(*     let guard,action = match _prepost with *)
(*       | Post -> _guard,_action *)
(*       | Pre -> _action,_guard *)
(*     in *)
(*     let rec find_witnesses pref suff =  *)
(*       begin *)
(* 	match suff with  *)
(* 	  | [] -> [] *)
(* 	  | hd::tl ->  *)
(* 	      begin *)
(* 		match hd with  *)
(* 		  | Content(ct) when D.do_meet witness ct ->  *)
(* 		      (pref,Content(D.meet witness ct),tl)::(find_witnesses (pref@[hd]) tl) *)
(* 		  | Context(cx) when D.do_meet witness cx ->  *)
(* 		      ( pref@[Context(cx)], Content(D.meet witness cx), (Context(cx))::tl )::(find_witnesses (pref@[hd]) tl) *)
(* 		  | _ -> find_witnesses (pref@[hd]) tl *)
(* 	      end *)
(*       end *)
(*     in *)
(*     let cstrs_with_witnesses = find_witnesses [] cstr in *)
(*       if debug_long  *)
(*       then printf "find_witnesses:\n %s" (List.fold_left (fun acc e -> *)
(* 							    match e with  *)
(* 							      | (_left,Content(_witness),_right) -> *)
(* 								  sprintf  "%s\n\n left:%s witness:%s\n right:%s\n" acc  *)
(* 								    (string_of _left)  *)
(* 								    (D.string_of _witness)  *)
(* 								    (string_of _right) *)
(* 							      | _ -> failwith("witness should be put as content") *)
(* 							 ) "" cstrs_with_witnesses *)
(* 					 ); *)
(*       List.fold_left (fun acc (w1,e,w2) ->  *)
(* 			begin *)
(* 			  let res1 = begin *)
(* 			    match prior with *)
(* 			      | Left -> [] *)
(* 			      | _ -> let post1 = local Post w1 guard action in List.fold_left (fun acc1 r1 -> (r1@(e::w2))::acc1 ) [] post1 *)
(* 			  end *)
(* 			  in *)
(* 			    if debug_long  *)
(* 			    then printf "res1: %s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" res1); *)
(* 			    let res2 = begin  *)
(* 			      match prior with  *)
(* 			      | Right -> []  *)
(* 			      | _ -> let post2 = local Post w2 guard action in  *)
(* 				  List.fold_left (fun acc2 r2 -> (w1@(e::r2))::acc2 ) [] post2  *)
(* 			    end *)
(* 			    in *)
(* 			    if debug_long  *)
(* 			    then printf "res2: %s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" res2); *)
(* 			      acc@res1@res2 *)
(* 			end *)
(* 		     ) [] cstrs_with_witnesses *)
(* end *)



(* exception GlobalGuardViolation *)

(* let universal _prepost cstr _guard _action gguard prior = begin *)
(*   assert(well_formed cstr); *)
(* (\*   if true *\) *)
(* (\*   then printf "guard%s, action%s, on%s\n" (D.string_of guard) (D.string_of action) (string_of cstr); *\) *)
(*   if is_bottom cstr then [] *)
(*   else *)
(*     let guard,action = match _prepost with  *)
(*       | Post -> _guard,_action *)
(*       | Pre -> _action,_guard *)
(*     in *)
(*     (\** Given a word = w1w2... with wi being C(ci) where C either Content or Context,  *)
(* 	* filter_with_global_guard word gives a word' = w1'w2'... with wi'=C(ci meets gguard) *)
(* 	* but raises an exception in case it encounters a Content(ci) with ci meets gguard =bottom *\) *)
(*     let rec filter_with_global_guard word = *)
(*       begin *)
(* 	match word with  *)
(* 	  | [] -> [] *)
(* 	  | hd::tl -> *)
(* 	      begin *)
(* 		match hd with  *)
(* 		  | Content(ct) when (D.do_meet ct gguard) -> Content(D.meet ct gguard)::(filter_with_global_guard tl) *)
(* 		  | Context(cx) -> Context(D.meet cx gguard)::(filter_with_global_guard tl) *)
(* 		  | _ -> raise GlobalGuardViolation *)
(* 	      end *)
(*       end *)
(*     in *)
(*     let rec apply pref suff = *)
(*       begin *)
(* 	try  *)
(* 	  let filtered_pref = match prior with | Right -> pref | _ -> filter_with_global_guard pref   in *)
(* 	    match suff with  *)
(* 	      | [] -> [] *)
(* 	      | hd::tl -> *)
(* 		  begin *)
(* 		    try *)
(* 		      let filtered_gtl = match prior with | Left -> tl | _ -> filter_with_global_guard tl  in *)
(* 			match hd with *)
(* 			  | Content(ct) when (D.do_meet ct guard) ->  *)
(* 			      (filtered_pref@((Content(action))::filtered_gtl))::(apply (pref@[hd]) tl) *)
(* 			  | Context(cx) when (D.do_meet cx guard) (\*C and Q'*\) ->  *)
(* 			      let cx_and_gguard = D.meet cx gguard (\*C and P*\) in *)
(* 			      let action_and_gguard = D.meet action gguard (\*Q and P*\) in *)
(* 			      let action_or_cxAndgguard = D.join action cx_and_gguard in *)
(* 			      let actionAndgguard_or_cxAndgguard = D.join action_and_gguard cx_and_gguard in *)
(* 				if D.do_meet guard cx_and_gguard (\*Q' and C and P*\) *)
(* 				then  *)
(* 				  begin  *)
(* 				    let addition =  match prior with *)
(* 				      | Left -> [(filtered_pref@[Context(action_or_cxAndgguard)]@[Content(action)]@ *)
(* 						    [Context(cx)]@filtered_gtl)] *)
(* 					  @[(filtered_pref@[Context(action_or_cxAndgguard)]@filtered_gtl)] *)
(* 				      | Right -> [(filtered_pref@[Context(cx)]@[Content(action)]@ *)
(* 						     [Context(action_or_cxAndgguard)]@filtered_gtl)] *)
(* 					  @[(filtered_pref@[Context(action_or_cxAndgguard)]@filtered_gtl)] *)
(* 				      | LeftRight -> [(filtered_pref@[Context(actionAndgguard_or_cxAndgguard)]@ *)
(* 							 [Content(action)]@[Context(actionAndgguard_or_cxAndgguard)]@ *)
(* 							 filtered_gtl)] *)
(* 					  @[(filtered_pref@[Context(actionAndgguard_or_cxAndgguard)]@filtered_gtl)] *)
(* 				    in *)
(* 				      addition@(apply (pref@[hd]) tl) *)
(* 				  end *)
(* 				else *)
(* 				  let addition = match prior with *)
(* 				    | Left -> (filtered_pref@[Context(actionAndgguard_or_cxAndgguard)]@[Content(action)]@[Context(cx)]@filtered_gtl)  *)
(* 				    | Right -> (filtered_pref@[Context(cx)]@[Content(action)]@[Context(actionAndgguard_or_cxAndgguard)]@filtered_gtl) *)
(* 				    | LeftRight -> (filtered_pref@[Context(cx_and_gguard)]@[Content(action)]@[Context(cx_and_gguard)]@filtered_gtl) *)
(* 				  in  *)
(* 				    addition::(apply (pref@[hd]) tl) *)
(* 			  | _ -> apply (pref@[hd]) tl *)
(* 		    with GlobalGuardViolation -> (apply (pref@[hd]) tl) *)
(* 		  end *)
(* 	with GlobalGuardViolation -> [] *)
(*       end *)
(*     in *)
(*       apply [] cstr *)
(* end *)


(* let weight cstr = List.length cstr  *)
