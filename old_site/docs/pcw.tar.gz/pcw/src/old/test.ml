
(* module type Ex = *)
(*   sig *)
(*     val name: string  *)
(*   end *)

module Example = 
struct
  let name = "Test"
end
