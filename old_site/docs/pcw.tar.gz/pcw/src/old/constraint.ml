
open Printf

module D = Power_domain 

let debug_entail = Debug.constraint_entail
let debug_meet = Debug.constraint_meet

let debug_long = Debug.constraint_long

type prepost = Pre | Post

type priority = Left | Right | LeftRight

type cc = Content of D.t | Context of D.t

type t = cc list

let pbot = D.bottom
let ptop = D.top

let base_length t = ((List.length t) - 1) / 2


let bottom = [Context(pbot)]

let is_bottom t = 
  match t with
    | [Context(d)]  when (D.is_bottom d) -> true
    | _ -> false 
	    
let top = [Context(ptop)]

let is_top t = 
  match t with
    | [Context(d)] when (D.is_top d) -> true
    | _ -> false 

let rec well_formed t = 
  if (is_bottom t) || (is_top t) then true
  else
  match t with
    | [] -> false
    | [Context(cx)] when D.is_not_bottom cx -> true
    | Context(cx)::tl when D.is_not_bottom cx -> 
	begin
	  match tl with
	    | Content(ct)::tl' when D.is_not_bottom ct 
		-> well_formed tl'
	    | _ -> false
	end
    | _ -> false


let create_from_context c = [Context(c)]

let from_context_and_base context base = 
  let rec append _base =
    match _base with 
      | [] -> [Context(context)]
      | hd::tl -> Context(context)::(Content(hd)::(append tl))
  in
    append base

let appendContent t elt ctxt =  
  if is_bottom t then bottom
  else (t@[elt]@[ctxt])

let string_of t = begin
(* assert(well_formed t); *)
  let print_element e = begin 
    match e with 
      | Content(d) -> sprintf "c:%s" (D.string_of d) 
      | Context(d) -> sprintf "x:%s" (D.string_of d) 
  end in 
  let s = List.fold_left (fun acc e -> 
			    sprintf "%s %s" acc (print_element e)) 
	  "[" t 
	in sprintf "%s]\n" s
end

let merge t = List.fold_left (fun acc e -> match e with 
				| Content(ct) -> D.join acc ct
				| Context(cx) -> D.join acc cx ) (D.bottom) t

let gamma_one_context cstr = begin
  let context = merge cstr in
  let rec replace c = 
    match c with 
      | [Context(d)] -> [Context(context)]
      | hd::tl -> 
	  begin  
	    match hd,tl with
	      | Context(cx),hd'::tl' -> 
		  begin 
		    match hd' with 
		      | Content(ct) -> Context(context)::(Content(ct)::(replace tl'))
		      | _ -> failwith("malformed constraint passed to gamma_one_context approximation")
		  end
	      | _ -> failwith("malformed constraint passed to gamma_one_context approximation")
	  end
      | _ -> failwith("malformed constraint passed to gamma_one_context approximation")
  in
    replace cstr
end

let rec merge_base cstr = 
  assert(well_formed cstr);
  if is_bottom cstr || is_top cstr then D.bottom
  else
    match cstr with
      | [Context(cx)] -> D.bottom
      | Context(cx)::tl -> 
	  begin 
	    match tl with
	      | Content(ct)::tl' -> D.join ct (merge_base tl')
	      | _ -> failwith("should not have gotten here")
	  end
      | _ -> failwith("should not have gotten here")
      

let rec do_meet a b =
  if debug_meet 
  then printf "\nmeet a=%s \nand b=%s\n" (string_of a) (string_of b);
  assert(well_formed a);
  assert(well_formed b);
  let result = 
    if is_bottom a || is_bottom b then false
    else if is_top a || is_top b then true
    else begin
      match a,b with
	| [Context(cxa)],[Context(cxb)] -> D.do_meet cxa cxb 
	| [Context(cxa)],hdb::tlb -> D.entailed cxa (merge_base b)
	| hda::tla,[Context(cxb)] -> D.entailed (merge_base a) cxb 
	| Context(cxa)::tla,Context(cxb)::tlb ->
	    begin
	      match tla,tlb with
		| Content(cta)::tla', Content(ctb)::tlb' ->
		    begin
		      ((D.do_meet cta cxb) && (do_meet tla' b))
		      ||
			((D.do_meet cta ctb) && (do_meet tla' tlb'))
		      ||
			((D.do_meet cxa ctb) && (do_meet a tlb'))
		    end
		| _ -> failwith("should not have gotten here")
	    end
	| _ -> failwith("should not have gotten here")
    end
  in 
    if debug_meet
    then printf "gives %b\n" result;
    result


(** Returns whether there exists an injection from the weak to the strong 
    * weak: x0c1x1...xn, strong: x0'c1'...xm'
    * *)
let rec entailed ~weak ~strong  = 
  if debug_entail 
  then printf "\nentailed weak=%s \nby strong=%s\n" (string_of weak) (string_of strong);
  assert(well_formed weak);
  assert(well_formed strong);
  let result = 
    if is_bottom strong || is_top weak then true
    else if List.length strong < List.length weak then false (* no possible injection *)
    else 
      begin
	match weak,strong with
	  | [Context(hx)], _ -> D.entailed hx (merge strong) (*  *)
	  | Context(hx)::_,Context(hx')::_ when not(D.entailed hx hx') -> false (* x0' not in x0 *)
	  | Context(hx)::tlx,hx'::tlx' -> begin
	      match tlx,tlx' with
		| Content(hc)::tlc,Content(hc')::tlc'-> ( 
		    ((D.entailed hc hc') && (entailed ~weak:tlc ~strong:tlc')) 
		    || ((D.entailed hx hc') && (entailed ~weak:weak ~strong:tlc')) ) 
		| _ -> failwith("I do not see how we can get here in the entailment")
	    end
	  | _ -> failwith("I do not see how we can get here in the entailment")
      end
  in 
    if debug_entail
    then printf " is %b\n\n" result;
    result

(* let equals ~weak ~strong = (entailed weak strong) && (entailed strong weak) *)
      

let local _prepost cstr _grd _act = begin
  assert(well_formed cstr);
  if false
  then printf "local:post=%b,guard=%s,action=%s on cstr=%s" (match _prepost with | Pre -> false | _ -> true) 
    (D.string_of _grd) (D.string_of _act) (string_of cstr) ;
  if is_bottom cstr then []
  else 
    let grd,act = match _prepost with
      | Post -> _grd,_act
      | Pre -> _act,_grd
    in
    let rec left_to_right pref suff = begin
      match suff with
	| [] -> []
	| hd::tl -> begin 
	    match hd with
	      | Content(ct) when D.do_meet grd ct -> 
		  ((pref@[Content(act)])@tl)
		  :: left_to_right (pref@[hd]) tl
	      | Context(cx) when D.do_meet grd cx -> 
		  let jn = D.join (D.join act cx) act
		  in (pref@(Context(jn)::tl))
		     ::left_to_right (pref@[hd]) tl
	      | Context(cx)  -> 
		  if false
		  then printf "\ngrd does not meet cx. cx=%s,grd=%s,act=%s\n" (D.string_of cx) (D.string_of grd) (D.string_of act);
		  left_to_right (pref@[hd]) tl
	      | Content(ct)  -> 
		  if false
		  then printf "\ngrd does not meet ct. ct=%s,grd=%s,act=%s\n" (D.string_of ct) (D.string_of grd) (D.string_of act);
		  left_to_right (pref@[hd]) tl
	  end
    end
    in 
    let res = left_to_right [] cstr
    in
      if false 
      then printf "gives: \n %s" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" res);
      res
end

let exists _prepost cstr _guard _action witness prior = begin
  assert(well_formed cstr);
  if is_bottom cstr then []
  else
    let guard,action = match _prepost with
      | Post -> _guard,_action
      | Pre -> _action,_guard
    in
    let rec find_witnesses pref suff = 
      begin
	match suff with 
	  | [] -> []
	  | hd::tl -> 
	      begin
		match hd with 
		  | Content(ct) when D.do_meet witness ct -> 
		      (pref,Content(D.meet witness ct),tl)::(find_witnesses (pref@[hd]) tl)
		  | Context(cx) when D.do_meet witness cx -> 
		      ( pref@[Context(cx)], Content(D.meet witness cx), (Context(cx))::tl )::(find_witnesses (pref@[hd]) tl)
		  | _ -> find_witnesses (pref@[hd]) tl
	      end
      end
    in
    let cstrs_with_witnesses = find_witnesses [] cstr in
      if debug_long 
      then printf "find_witnesses:\n %s" (List.fold_left (fun acc e ->
							    match e with 
							      | (_left,Content(_witness),_right) ->
								  sprintf  "%s\n\n left:%s witness:%s\n right:%s\n" acc 
								    (string_of _left) 
								    (D.string_of _witness) 
								    (string_of _right)
							      | _ -> failwith("witness should be put as content")
							 ) "" cstrs_with_witnesses
					 );
      List.fold_left (fun acc (w1,e,w2) -> 
			begin
			  let res1 = begin
			    match prior with
			      | Left -> []
			      | _ -> let post1 = local Post w1 guard action in List.fold_left (fun acc1 r1 -> (r1@(e::w2))::acc1 ) [] post1
			  end
			  in
			    if debug_long 
			    then printf "res1: %s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" res1);
			    let res2 = begin 
			      match prior with 
			      | Right -> [] 
			      | _ -> let post2 = local Post w2 guard action in 
				  List.fold_left (fun acc2 r2 -> (w1@(e::r2))::acc2 ) [] post2 
			    end
			    in
			    if debug_long 
			    then printf "res2: %s\n" (List.fold_left (fun acc e -> sprintf "%s %s" acc (string_of e)) "" res2);
			      acc@res1@res2
			end
		     ) [] cstrs_with_witnesses
end



exception GlobalGuardViolation

let universal _prepost cstr _guard _action gguard prior = begin
  assert(well_formed cstr);
(*   if true *)
(*   then printf "guard%s, action%s, on%s\n" (D.string_of guard) (D.string_of action) (string_of cstr); *)
  if is_bottom cstr then []
  else
    let guard,action = match _prepost with 
      | Post -> _guard,_action
      | Pre -> _action,_guard
    in
    (** Given a word = w1w2... with wi being C(ci) where C either Content or Context, 
	* filter_with_global_guard word gives a word' = w1'w2'... with wi'=C(ci meets gguard)
	* but raises an exception in case it encounters a Content(ci) with ci meets gguard =bottom *)
    let rec filter_with_global_guard word =
      begin
	match word with 
	  | [] -> []
	  | hd::tl ->
	      begin
		match hd with 
		  | Content(ct) when (D.do_meet ct gguard) -> Content(D.meet ct gguard)::(filter_with_global_guard tl)
		  | Context(cx) -> Context(D.meet cx gguard)::(filter_with_global_guard tl)
		  | _ -> raise GlobalGuardViolation
	      end
      end
    in
    let rec apply pref suff =
      begin
	try 
	  let filtered_pref = match prior with | Right -> pref | _ -> filter_with_global_guard pref   in
	    match suff with 
	      | [] -> []
	      | hd::tl ->
		  begin
		    try
		      let filtered_gtl = match prior with | Left -> tl | _ -> filter_with_global_guard tl  in
			match hd with
			  | Content(ct) when (D.do_meet ct guard) -> 
			      (filtered_pref@((Content(action))::filtered_gtl))::(apply (pref@[hd]) tl)
			  | Context(cx) when (D.do_meet cx guard) (*C and Q'*) -> 
			      let cx_and_gguard = D.meet cx gguard (*C and P*) in
			      let action_and_gguard = D.meet action gguard (*Q and P*) in
			      let action_or_cxAndgguard = D.join action cx_and_gguard in
			      let actionAndgguard_or_cxAndgguard = D.join action_and_gguard cx_and_gguard in
				if D.do_meet guard cx_and_gguard (*Q' and C and P*)
				then 
				  begin 
				    let addition =  match prior with
				      | Left -> [(filtered_pref@[Context(action_or_cxAndgguard)]@[Content(action)]@
						    [Context(cx)]@filtered_gtl)]
					  @[(filtered_pref@[Context(action_or_cxAndgguard)]@filtered_gtl)]
				      | Right -> [(filtered_pref@[Context(cx)]@[Content(action)]@
						     [Context(action_or_cxAndgguard)]@filtered_gtl)]
					  @[(filtered_pref@[Context(action_or_cxAndgguard)]@filtered_gtl)]
				      | LeftRight -> [(filtered_pref@[Context(actionAndgguard_or_cxAndgguard)]@
							 [Content(action)]@[Context(actionAndgguard_or_cxAndgguard)]@
							 filtered_gtl)]
					  @[(filtered_pref@[Context(actionAndgguard_or_cxAndgguard)]@filtered_gtl)]
				    in
				      addition@(apply (pref@[hd]) tl)
				  end
				else
				  let addition = match prior with
				    | Left -> (filtered_pref@[Context(actionAndgguard_or_cxAndgguard)]@[Content(action)]@[Context(cx)]@filtered_gtl) 
				    | Right -> (filtered_pref@[Context(cx)]@[Content(action)]@[Context(actionAndgguard_or_cxAndgguard)]@filtered_gtl)
				    | LeftRight -> (filtered_pref@[Context(cx_and_gguard)]@[Content(action)]@[Context(cx_and_gguard)]@filtered_gtl)
				  in 
				    addition::(apply (pref@[hd]) tl)
			  | _ -> apply (pref@[hd]) tl
		    with GlobalGuardViolation -> (apply (pref@[hd]) tl)
		  end
	with GlobalGuardViolation -> []
      end
    in
      apply [] cstr
end


let weight cstr = List.length cstr 
