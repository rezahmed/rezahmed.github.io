
open Printf

type t = {
  mutable id: string;
  mutable min: int;
  mutable max: int;
}

let create s inf sup = 
  { id = s; 
    min = inf; 
    max = sup}

let print t = t.id

let bottom s = {id = s;
	     min = 1;
	     max = 0}

let isBottom t = (t.min > t.max)

let top s = {id = s;
	  min = min_int;
	  max = max_int }

let meet l1 l2 =
  assert(l1.id=l2.id);
  {id = l1.id;
   min = (l1.min < l2.min ? l2.min : l1.min);
   max = (l1.max < l2.max ? l1.max : l2.max) }

let join l1 l2 =
  assert(l1.id=l2.id);
  {id = l1.id;
   min = (l1.min < l2.min ? l1.min : l2.min);
   max = (l1.max < l2.max ? l2.max : l1.max) }
    
    
let isNotBottom t =
  (!isBottom t)  
