
open Printf


module conjunct = Hashtbl.Make(struct type t= Interval_predicate.id let equal = (=) let hash = IntervalPredicate.id )


type t = {
  mutable content: conjunct;
}

let create l  = 
List.iter (fun id inf max -> 
	  assert ) l

let print t = t.content

let bottom = {content = "_"}

let isBottom t = (t=bottom)

let top = {content = "*" }

let meet l1 l2 =
  if l1=l2 then l1
  else bottom
    
let isNotBottom t =
  (t!=bottom)  
