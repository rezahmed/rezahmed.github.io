append([], Y, Y).
