append([U|V], Y, [U|Z]) :- append(V, Y, Z).
