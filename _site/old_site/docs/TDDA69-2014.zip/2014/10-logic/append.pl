my_append([], Y, Y).
my_append([U|V], Y, [U|Z]) :-
    my_append(V, Y, Z).
