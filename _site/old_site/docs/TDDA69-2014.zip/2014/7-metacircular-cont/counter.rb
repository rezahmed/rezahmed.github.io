class Counter
  def initialize
    @val = 0
  end

  def incrementer
    lambda {|v| @val += v}
  end

  def printer
    lambda {puts "counter value: #{@val}"}
  end
end

c = Counter.new
adder = c.incrementer
publisher = c.printer

(1..4).each do |i| 
  adder.call(i)
  publisher.call
end
