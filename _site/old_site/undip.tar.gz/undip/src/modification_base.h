/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file modification_base.h
 * Header for Modification_Base
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_MODIFICATION_BASE_H
#define _UNDIP_MODIFICATION_BASE_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <iterator>
#include <vector>
#include <set>

#include "polynomial.h"

using namespace std;

/** Brief 
 */

class Modification_Base : private vector<set<int> >  
{
  typedef vector<set<int> > Container;
  
  int shift(int position, int var)const{
    if(pure_right){
      set<int> prefix(operator[](position-at).begin(), operator[](position-at).find(var));
      return prefix.size()+1;
    }
    else{
      set<int> prefix(operator[](position-1).begin(), operator[](position-1).find(var));
      return prefix.size()+1;
    }
  }
  
 public:
  typedef Container::iterator iterator;
  typedef Container::const_iterator const_iterator;
  iterator begin(){return Container::begin();}
  const_iterator begin()const {return Container::begin();}
  iterator end(){return Container::end();}
  const_iterator end()const{return Container::end();}

 public:
  Modification_Base(int _at, int _cn, bool _pure_right, bool _pure_left,
		    const set<int>& _initiator_modified, 
		    const vector<set<int> >& _left_modified, 
		    const vector<set<int> >& _left_right_modified, 
		    const vector<set<int> >& _right_modified, 
		    int sv, int pv,
		    const Polynomial& p);
  
  friend ostream& operator<< (ostream& out, const Modification_Base& mb);
    
  int get(int position, int var)const{
    assert(is_modified(position, var));
    if(pure_right)
      return base[position-at]+shift(position, var);
    else
      return base[position-1]+shift(position, var);
  }

  bool is_modified(int position, int var)const{
    assert(1<= position & position<=cn); 
    if(pure_right)
      if(at<=position)
	return operator[](position-at).find(var)!=operator[](position-at).end();
      else
	return false;
    else
      if(pure_left)
	if(position<=at)
	  return operator[](position-1).find(var)!=operator[](position-1).end();
	else
	  return false;
      else
	return operator[](position-1).find(var)!=operator[](position-1).end();
  }

  int modified_number()const{return modified;}
    
 private:
  int at, cn;
  bool pure_right, pure_left;
  int modified;
  vector<int> base;
};


inline ostream& operator<< (ostream& out, const Modification_Base& mb)
{

   if(mb.pure_right){
    out << "initiator ";
    copy(mb[0].begin(), mb[0].end(), ostream_iterator<int>(out, " ")); out << endl;
    out << endl;
    for(int r=1; r<=mb.cn-mb.at; r++){
      out << "R receptor["<< r << "] :";
      copy(mb[r-1].begin(), mb[r-1].end(), ostream_iterator<int>(out, " ")); out << endl;
      out << endl;
    }
  }
  else{
    for(int r=1; r<mb.at; r++){
      out << "L receptor["<< r << "] ";
      copy(mb[r-1].begin(), mb[r-1].end(), ostream_iterator<int>(out, " ")); out << endl;
      out << endl;
    }
    out << "initiator ";
    copy(mb[mb.at-1].begin(), mb[mb.at-1].end(), ostream_iterator<int>(out, " ")); out << endl;
    out << endl;
    
    if(!mb.pure_left)
      for(int r=mb.at+1; r<=mb.cn; r++){
	out << "R receptor["<< r << "] ";
	copy(mb[r-1].begin(), mb[r-1].end(), ostream_iterator<int>(out, " ")); out << endl;
	out << endl;
      }
  }

  return out;
}

#endif

