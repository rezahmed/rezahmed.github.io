/*
    Copyright (C) 2003 Johann Deneux

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>
*/

#ifndef MINSET_H
#define MINSET_H

#include <cstdlib>
#include <list>
#include "printable.h"
#include <set>
#include <memory>
#include "ref.h"

//#define MIN_DEBUG
#ifdef MIN_DEBUG
#include <iostream>
#endif

//! Set of minimal elements
template<class T, class le = std::less_equal<T> >
class MinSet: public Printable, private std::list<T>
  {
    public:
    typedef std::list<T> ContainerT;
    
    class InsertStrategy
    {
    protected:
      void real_insert(ContainerT& c, const T& t) {
#if 0
	if (random() > RAND_MAX/2)
	  c.push_back(t);
	else
	  c.push_front(t);
#else
	c.push_back(t);
#endif
      }
    public:
      virtual bool insert(ContainerT& c, const T& t, bool blindly=false) = 0;
      virtual ~InsertStrategy() {}
    };

    public:
    class BlindInsertStrategy : public InsertStrategy
    {
    public:
      bool insert(ContainerT& c, const T& t, bool blindly=false) { real_insert(c, t); return true; }
    };

    class CheckCoverInsertStrategy : public InsertStrategy
    {
    public:

      bool insert(ContainerT& c, const T& t, bool blindly=false) {
	if(blindly)
	  {
	    real_insert(c,t);
	    return true;
	  }

	for (typename ContainerT::iterator p = c.begin(); p != c.end(); ++p)
	  if (le()(*p,t)) {
	      
#ifdef MIN_DEBUG
	    std::cerr<<t<<" not inserted ("<<(*p)<<")"<<std::endl;
#endif
	      
	    return false;
	  }
	  
	clean(c, t);
	real_insert(c,t);

	return true;
	  
      }
	
      void clean(ContainerT& c, const T& t) {
	for (typename ContainerT::iterator p = c.begin();
	     p != c.end();) {
	  typename ContainerT::iterator next = p; ++next;
	  if (le()(t,*p)) {
#ifdef MIN_DEBUG
	    std::cerr<<"cleaned "<<(*p)<<" :"<<t<<std::endl;
#endif
	    c.erase(p);
	  }
	  p = next;
	}
      }
    };

    public:    
    typedef typename ContainerT::const_iterator const_iterator;
    typedef typename ContainerT::iterator iterator;
    typedef typename ContainerT::const_reverse_iterator const_reverse_iterator;
    typedef typename ContainerT::reverse_iterator reverse_iterator;

    public:
    //FIXME: insert strategies leak.
    MinSet():
    insert_strategy(Ref<InsertStrategy>(new CheckCoverInsertStrategy))
    {}
    MinSet(Ref<InsertStrategy> insert_strategy):
    insert_strategy(insert_strategy)
    {};

    //! try to insert t
    /*! \return true iff t could be inserted */

    bool insert(const T& t, bool blindly=false) {
      return insert_strategy->insert(static_cast<ContainerT&>(*this), t, blindly);

    }

    //! Insert a range

    void insert(const_iterator p, const_iterator end, bool blindly=false) 
    {
      
#if 0
      for (; p != end; ++p) 
	insert(*p, blindly);
#else	
      if(blindly)
	for (; p != end; ++p) 
	  insert(*p, true);
      else
	{
	  ContainerT binserted;
	  
	  for (; p != end; ++p) 
	    {
	      if(!includes(*p))	  
		binserted.push_back(*p);
	    }

	  for(iterator mine = this->begin(); mine != this->end(); ) 
	    {
	      iterator nxit=mine; nxit++;

	      for (typename ContainerT::const_iterator his=binserted.begin(); his != binserted.end(); ++his) 
		{
		  if(le()(*his, *mine))	  
		    {
		      erase(mine);
		      break;
		    }

		}
	      mine=nxit;
	    }
	      
	  for (const_iterator his = binserted.begin();  his != binserted.end(); ++his) 
	    {
	      insert(*his);
	    }
	}
#endif
    }
    
    bool includes(const T& t) const {
      for (const_iterator p = begin();
	   p != end();
	   ++p) {
	if (le()(*p, t)) return true;
      }
      return false;
    }

    bool includes(const MinSet<T,le>& other) const {
      for (const_iterator his = other.begin();
	   his != other.end();
	   ++his) {
	const_iterator mine;
	for (mine = begin();
	     mine != end() && !le()(*mine, *his);
	     ++mine);
	if (mine == end()) {
	  return false;
	}
      }
	
      return true;
    }
  
    int size() const { return ContainerT::size(); }
    bool empty() const { return ContainerT::empty(); }

    iterator begin() { return ContainerT::begin(); }
    const_iterator begin() const { return ContainerT::begin(); }

    iterator end() { return ContainerT::end(); }
    const_iterator end() const { return ContainerT::end(); }

    reverse_iterator rbegin() { return ContainerT::rbegin(); }
    const_reverse_iterator rbegin() const { return ContainerT::rbegin(); }

    reverse_iterator rend() { return ContainerT::rend(); }
    const_reverse_iterator rend() const { return ContainerT::rend(); }
    
    void swap(MinSet<T,le> other) { ContainerT::swap(other); }
    void clear() { ContainerT::clear(); }

    void erase(iterator it) { ContainerT::erase(it); }
    void erase(const_iterator it) { ContainerT::erase(it); }

    void print(std::ostream& out) const {
      out<<"{";
      const_iterator p = begin();
      if (!empty()) {
	out<<**p;
	++p;
	//	  for (; p != end(); ++p) out<<", "<<**p;
	for (; p != end(); ++p) out<< std::endl <<**p;
      }
      out<<"}";
    }

    private:
    Ref<InsertStrategy> insert_strategy;

  };

template <class T, class Order>
  class ReverseOrder
{
 public:
  ReverseOrder() {};

  bool operator()(const T& A, const T& B) const {
    return Order()(B, A);
  }
};

template<class T, class le=std::less_equal<T> >
class MaxSet: public MinSet<T, ReverseOrder<T, le> >
  {
    typedef MinSet<T, ReverseOrder<T, le> > MinSetT;
    typedef typename MinSet<T, ReverseOrder<T, le> >::InsertStrategy InsertStratT;

    public:
    MaxSet() {}
    MaxSet(Ref<InsertStratT> insert_strategy):
    MinSetT(insert_strategy)
    {};
  };

#endif
