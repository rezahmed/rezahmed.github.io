/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file sdgt.cc
 * implementation of a SDGT
 *
 * @author Rezine Ahmed
 */

#include "sdgt.h"
#include <iterator>


//#define DEBUG_SDGT_CONSTRUCT
//#define DEBUG_FIRE_SDGT
//#define DEBUG_CHANNEL_VALIDITY
//#define DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
//#define DEBUG_FIRE_POSITION_INSERTED_WITNESS


#define WITH_SAME  

SDGT::SDGT(const Actions_Sequence& _sequence,  
	   const Quantifier_Domain& _domain)
  : domain(_domain)
{
  rid=++rcounter;

  for(Actions_Sequence::const_iterator it=_sequence.begin(); 
      it!=_sequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    if(it->get_cipher().is_bounded())
      bsequence.add(*it);
    else
      usequence.add(*it);
  }

#ifdef DEBUG_SDGT_CONSTRUCT
  cout << "SDGT constructor % input id: " << rid << endl;
  cout << "SDGT constructor % input domain: " << (domain==L? "L" : (domain==R? "R" : "LR")) << endl;
  cout << "SDGT constructor % input bsequence: " << bsequence;
  cout << "SDGT constructor % input usequence: " << usequence;
#endif


  //first, bonded part
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc+bc;
  bimage=Clause(bsegment);
  //collect the modified bounded variables
  for(Actions_Sequence::const_iterator it=bsequence.begin(); 
      it!=bsequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    assert(i==0 | j==0);
    assert(i!=j & i<=2*bsegment & j<=2*bsegment);
    int index=(i==0 ? j: i);
    if(0<index-bsegment){
      if(index-bsegment<=bs) 
	bounded_shared_modified.insert(index-bsegment);
      else if(index-bsegment<=bs+bp) 
	bounded_process_modified.insert(index-bsegment);
      else 
	bounded_channels_modified.insert(index-bsegment);
    }
  }
  //build the largest image, and collect the guards
  for(Actions_Sequence::const_iterator it=bsequence.begin(); 
      it!=bsequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    int index=(i==0? j: i);
    numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
    numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
    if(bsegment < index){
      assert(bimage.tighten(index-bsegment, nlb, ub));
      if(index-bsegment<=bs+bp) 
	bounded_shared_and_process_guard.add(*it);
      else 
	bounded_channels_guard.add(*it);
    }
    else 
      if(bounded_shared_modified.find(index)==bounded_shared_modified.end() 
	 & bounded_process_modified.find(index)==bounded_process_modified.end() 
	 & bounded_channels_modified.find(index)==bounded_channels_modified.end()){
	assert(bimage.tighten(index, nlb, ub));
	if(index<=bs+bp) 
	  bounded_shared_and_process_guard.add(*it);
	else 
	  bounded_channels_guard.add(*it);
      }
  }
  
  //intersect with bounds 
  for(int index=1; index<=bs+bp+bc; ++index)
    assert(bimage.tighten(index, Constraint::Bb.gnlb(index), Constraint::Bb.gub(index)));
  for(int index=bs+bp+bc+1; index<=bsegment; ++index)
    assert(bimage.tighten(index, Constraint::Bb.gnlb(index-bc), Constraint::Bb.gub(index-bc)));
  
  assert(Constraint::pure_unbounded | !bimage.is_empty());

#ifdef  DEBUG_SDGT_CONSTRUCT
  cout << "SDC constructor % bounded shared modified      : "; 
  copy(bounded_shared_modified.begin(), bounded_shared_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % bounded process modified     : "; 
  copy(bounded_process_modified.begin(), bounded_process_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;  
  cout << "SDC constructor % bounded channels modified     : "; 
  copy(bounded_channels_modified.begin(), bounded_channels_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % bounded shared/process guard : " << endl 
       << bounded_shared_and_process_guard << endl; 
  cout << "SDC constructor % bounded channels guard        : " << endl 
       << bounded_channels_guard << endl; 
  cout << "SDC constructor % obtained bounded image       : " << endl 
       << bimage << endl; 
#endif

  // Second, the unbounded case.
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc+uc;
  
  Dbm dbm(2*usegment);
  for(Actions_Sequence::const_iterator it=usequence.begin(); 
      it!=usequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    assert(dbm.tighten(i,j,it->get_dbm().get(0,1)));
    assert(dbm.tighten(j,i,it->get_dbm().get(1,0)));
    if(0<i-usegment){
      if(i-usegment<=us) 
	unbounded_shared_modified.insert(i-usegment);
      else if(i-usegment<=us+up) 
	unbounded_process_modified.insert(i-usegment);
      else 
	unbounded_channels_modified.insert(i-usegment);
    }
    if(0<j-usegment){
      if(j-usegment<=us) 
	unbounded_shared_modified.insert(j-usegment);
      else if(j-usegment<=us+up) 
	unbounded_process_modified.insert(j-usegment);
      else 
	unbounded_channels_modified.insert(j-usegment);
    }
  }

  //fix encoding for modified unbounded variables
  set<int>::const_iterator mit;
  int incrementer=1;
  for(mit=unbounded_shared_modified.begin(); 
      mit!=unbounded_shared_modified.end(); ++mit, ++incrementer)  
    modification[*mit]=incrementer;  
  for(mit=unbounded_process_modified.begin(); 
      mit!=unbounded_process_modified.end(); ++mit, ++incrementer)  
    modification[*mit]=incrementer;  
  for(mit=unbounded_channels_modified.begin(); 
      mit!=unbounded_channels_modified.end(); ++mit, ++incrementer) 
    modification[*mit]=incrementer; 

  // Apply variable lower bounds
  for(int j=1; j<=us+up+uc; ++j){ 
    assert(dbm.tighten(0,j,Constraint::Ub.gnlb(j))); 
    assert(dbm.tighten(0,j+usegment,Constraint::Ub.gnlb(j))); 
    if(modification.find(j)==modification.end()){ 
      //non modified variable are copied
      assert(dbm.tighten(j,j+usegment,numb(0)));
      assert(dbm.tighten(j+usegment,j,numb(0)));
    }
  }
  for(int j=us+up+uc+1; j<=usegment; ++j){ 
    assert(dbm.tighten(0,j,Constraint::Ub.gnlb(j-uc))); 
    assert(dbm.tighten(0,j+usegment,Constraint::Ub.gnlb(j-uc))); 
    if(modification.find(j)==modification.end()){ 
      //non modified variable are copied
      assert(dbm.tighten(j,j+usegment,numb(0)));
      assert(dbm.tighten(j+usegment,j,numb(0)));
    }
  }
  uimage=dbm.project_away(1,usegment);

  assert(Constraint::pure_bounded | !uimage.is_empty());

  // collecting the guards for the unbounded variables
  for(Actions_Sequence::const_iterator it=usequence.begin(); 
      it!=usequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    // is the variable a constant, a shared or a process variable that is either
    // modified in this action, or not modified in any action?
    bool shared_firing_guard_i=(i==0 | (usegment<i & i<=usegment+us+up) | 
				(i<=us+up & modification.find(i)==modification.end()));
    bool shared_firing_guard_j=(j==0 | (usegment<j & j<=usegment+us+up) | 
				(j<=us+up & modification.find(j)==modification.end()));
    //is the variable a constant, a shared or process or channel variable that is modified in 
    //this action, or channel variable that is not modified in any aciton?
    bool witness_guard_i=(i==0 | usegment<i  | 
			  ((us+up<i & i<=usegment) & modification.find(i)==modification.end()));
    bool witness_guard_j=(j==0 | usegment<j  | 
			  ((us+up<j & j<=usegment) & modification.find(j)==modification.end()));
    if(shared_firing_guard_i & shared_firing_guard_j)
      unbounded_shared_and_process_guard.add(*it);
    else 
      if(witness_guard_i & witness_guard_j)
	unbounded_channels_guard.add(*it);
  }


#ifdef  DEBUG_SDGT_CONSTRUCT
  cout << "SDC constructor % modified ushared set: " ;
  copy(unbounded_shared_modified.begin(), unbounded_shared_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % modified uprocess set: " ;
  copy(unbounded_process_modified.begin(), unbounded_process_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % modified uchannels set: " ;
  copy(unbounded_channels_modified.begin(), unbounded_channels_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % obtained dbm: " << dbm << endl; 
  cout << "SDC constructor % unbounded_shared_process_guard: " << endl << endl
       << unbounded_shared_and_process_guard << endl;
  cout << "SDC constructor % unbounded_channels_guard : " << endl << endl 
       << unbounded_channels_guard << endl;
#endif
  
}

MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > SDGT::fire_position(const Constraint_Ref& cstr, int at, bool same) const
{//fire position
  
  assert(cstr);
  assert(1<=at & at<=cstr->cardinal());
    
#ifdef DEBUG_FIRE_SDGT
  cout << endl 
	    << "fire_SDGT% input at: " << at << endl 
	    << "fire_SDGT% input c: " << *cstr << endl
	    << "fire_SDGT% input r: " << rid << endl;
#endif

  if(cstr->is_empty() | !cstr->is_sender_or_one_of_io_channels_old(at)){
#ifdef DEBUG_FIRE_SDC
    cout << "fire_SDC% output : empty input, result doomed to entail the input ! "<< endl ;
#endif
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > phi;
    return phi;
  }
  
  int cn=cstr->cardinal();//number of processes in cstr

  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc+bc;
  int batv=bs+(at-1)*(bp+(cn-1)*bc);//begining of process "at"'s bounded variables 

  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc+uc;
  int uatv=us+(at-1)*(up+(cn-1)*uc);//begining of process "at"'s unbounded variables 
  
  if(!check_satisfiable(at, batv, uatv, cstr)){
#ifdef DEBUG_FIRE_SDC
    cout << "fire_SDC% output : rule not enabled ! "<< endl ;
#endif
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > phi;
    return phi;
  }

  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > result_min_set; //resulting min set
  Confederation non_covered(bimage, uimage); // union of non covered witnesses

  if(domain!=R)
    for(int w=1; w<at; ++w){
      //without insertion for each witness to the left
      // at->w
      int boutwatv=batv+bp+(w-1)*bc;
      int uoutwatv=uatv+up+(w-1)*uc;
      // w->at
      int binwatv=bs+(w-1)*(bp+(cn-1)*bc)+bp+(at-2)*bc;
      int uinwatv=us+(w-1)*(up+(cn-1)*uc)+up+(at-2)*uc;
      
      //here, we restrict the to be inserted witness
#ifdef WITH_SAME
      if(!same & cstr->is_process_old(at))
#else
      if(cstr->is_process_old(at))
#endif
	non_covered=restrict_non_covered(non_covered,batv,uatv,boutwatv,uoutwatv,binwatv,uinwatv,cstr);

#ifdef WITH_SAME      
      if(same & cstr->is_sender_or_io_channel_old(at,w))
#else
      if(cstr->is_sender_or_io_channel_old(at,w))
#endif
	if(!check_channel_validity(at,batv,uatv,boutwatv,uoutwatv,binwatv,uinwatv,cstr))
	  continue;
	else
	  {//if satisfiable channel
	    pair<Clause,Dbm> result=fire_position_specified_witness_no_insertion(at,w,boutwatv,uoutwatv,binwatv,uinwatv,batv,uatv,cstr);
	    
#ifdef DEBUG_FIRE_SDGT
	    cout << "fire_SDGT% no insertion: (fire, witness)=(" << at << "," <<  w << ")" << endl 
		 << "fire_SDGT% no insertion gives" << endl << result.first << result.second << endl ;
#endif

	    if(!(result.first.is_empty() & !Constraint::pure_unbounded) 
	       & !(result.second.is_empty() & !Constraint::pure_bounded)){//if result non empty
	      Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn));
	      cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	      cstr_result->copy_status(cstr);
	      cstr_result->set_process_old(at);
	      cstr_result->set_channel_old(at,w);
	      if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_SDGT
		cout << "fire_SDGT% which is entailed by the constraint: " << endl ;
#endif
	      }
	      else
		result_min_set.insert(cstr_result);
	    }
	  }
    }
  if(domain!=L)//not pure left
    for(int w=at+1; w<=cn; w++){
      //without insertion for each witness to the left
      // at->w
      int boutwatv=batv+bp+(w-2)*bc;
      int uoutwatv=uatv+up+(w-2)*uc;
      // w->at
      int binwatv=bs+(w-1)*(bp+(cn-1)*bc)+bp+(at-1)*bc;
      int uinwatv=us+(w-1)*(up+(cn-1)*uc)+up+(at-1)*uc;
      //here, we restrict the to be inserted witness
#ifdef WITH_SAME
      if(!same & cstr->is_process_old(at))
#else
      if(cstr->is_process_old(at))
#endif
	non_covered=restrict_non_covered(non_covered,batv,uatv,boutwatv,uoutwatv,binwatv,uinwatv,cstr);
      
#ifdef WITH_SAME
      if(same & cstr->is_sender_or_io_channel_old(at,w))
#else
      if(cstr->is_sender_or_io_channel_old(at,w))
#endif
	if(!check_channel_validity(at,batv,uatv,boutwatv,uoutwatv,binwatv,uinwatv,cstr))
	  continue;
	else
	  {//satisfiable
	    pair<Clause,Dbm> result=fire_position_specified_witness_no_insertion(at,w,boutwatv,uoutwatv,binwatv,uinwatv,batv,uatv,cstr);
#ifdef DEBUG_FIRE_SDGT
	    cout << "fire_SDGT% no insertion: (fire, witness)=(" << at << "," <<  w << ")" << endl 
		 << "fire_SDGT% no insertion gives" << endl << result.first << result.second << endl ;
#endif
	    
	    if(!(result.first.is_empty() & !Constraint::pure_unbounded) 
	       & !(result.second.is_empty() & !Constraint::pure_bounded)){//if result non empty
	      Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn));
	      cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	      cstr_result->copy_status(cstr);
	      cstr_result->set_process_old(at);
	      cstr_result->set_channel_old(at,w);
	      if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_SDGT
		cout << "fire_SDGT% which is entailed by the constraint: " << endl ;
#endif
	      }
	      else
		result_min_set.insert(cstr_result);
	    }
	  }
    }		  
  
#ifdef WITH_SAME
  if(!same & cstr->is_process_old(at)){
#else
    if(cstr->is_process_old(at)){
#endif
      //time for insertion
    ConfederationConstIterator    cdit=non_covered.begin();
    for(; cdit != non_covered.end(); ++cdit){
      if(domain!=R)
	for(int insert_position=1; insert_position<=at; insert_position++){
	  //for each possible insertion ins
	  pair<Clause,Dbm> result=fire_position_inserted_witness(at, insert_position, cstr, *cdit);
#ifdef DEBUG_FIRE_SDGT
	  cout << "fire_SDGT% insertion: (fire, insert)=("  << at << "," << insert_position << ")" << endl
	       << "fire_SDGT% insertion gives" << result.first << result.second << endl ;
#endif
	  if(!(result.first.is_empty()&!Constraint::pure_unbounded)
	     & !(result.second.is_empty()&!Constraint::pure_bounded)){
	    Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn+1));
	    cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	    cstr_result->copy_status_and_create(cstr, insert_position);
	    cstr_result->set_channel_old(at+1, insert_position);
	    if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_SDGT
	      cout << "fire_SDGT% which is entailed by the constraint: " << endl ;
#endif
	    }
	    else
	      result_min_set.insert(cstr_result);
	  }
	}
      if(domain!=L)
	for(int insert_position=at+1; insert_position<=cn+1; insert_position++){
	  //for each possible insertion ins
	  pair<Clause,Dbm> result=fire_position_inserted_witness(at, insert_position, cstr, *cdit);
#ifdef DEBUG_FIRE_SDGT
	  cout << "fire_SDGT% insertion: (fire, insert)=("  << at << "," << insert_position << ")" << endl
	       << "fire_SDGT% insertion gives" << result.first << result.second << endl ;
#endif
	  if(!(result.first.is_empty() & !Constraint::pure_unbounded) 
	     & !(result.second.is_empty() & !Constraint::pure_bounded)){
	    Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn+1));
	    cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	    cstr_result->copy_status_and_create(cstr, insert_position);
	    cstr_result->set_channel_old(at, insert_position);
	    if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_SDGT
	      cout << "fire_SDGT% which is entailed by the constraint: " << endl ;
#endif
	    }
	    else
	      result_min_set.insert(cstr_result);
	  }
	}
    }
  }

#ifdef DEBUG_FIRE_SDGT
  cout << "fire_SDGT% output % " << result_min_set << endl ;
#endif
  
  return result_min_set;
}

bool SDGT::check_satisfiable(int at, int batv, int uatv, const Constraint_Ref& cstr) const
{
  if(!Constraint::pure_unbounded){
    // First, the bounded case
    int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
    int bsegment=bs+bp+bc+bc;
    for(Actions_Sequence::const_iterator it=bounded_shared_and_process_guard.begin(); 
	it!=bounded_shared_and_process_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
	int r=0;
	if(index<=bs)	r=index;
	else if(index<=bs+bp) r=index-bs+batv;
	else if(index<=bsegment) assert(false);
	else if(index<=bsegment+bs) r=index-bsegment;
	else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv;
	else assert(false);
      
	if(ub+cstr->clause.gnlb(r)<=numb(-1)
	   | nlb+cstr->clause.gub(r)<=numb(-1) )
	  return false;
      }
  }
  if(!Constraint::pure_bounded){
    //Second, the unbounded part
    int us=Constraint::us, up=Constraint::up, uc=Constraint::uc; 
    int usegment=us+up+uc+uc;
    for(Actions_Sequence::const_iterator it=unbounded_shared_and_process_guard.begin(); 
	it!=unbounded_shared_and_process_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int ri=0,rj=0;
      
	if(i<=us)  ri=i;
	else if(i<=us+up)	  ri=i-us+uatv;
	else if(i<=usegment) assert(false);
	else if(i<=usegment+us) ri=i-usegment;
	else if(i<=usegment+us+up) ri=i-usegment-us+uatv;
	else assert(false);
      
	if(j<=us)	rj=j;
	else if(j<=us+up)  rj=j-us+uatv;
	else if(j<=usegment)  assert(false);
	else if(j<=usegment+us) rj=j-usegment;
	else if(j<=usegment+us+up) rj=j-usegment-us+uatv;
	else assert(false);
      
	if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1)
	   | it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1) )
	  return false;
      }
  }
  return true;
}


bool SDGT::check_channel_validity(int at, int batv, int uatv, int boutwatv, int uoutwatv,
				  int binwatv, int uinwatv, const Constraint_Ref& cstr) const
{
  if(!Constraint::pure_unbounded){
    // First, bounded variables
    int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
    int bsegment=bs+bp+bc+bc;
    for(Actions_Sequence::const_iterator it=bounded_channels_guard.begin(); 
	it!=bounded_channels_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
      
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
      
	int r=0;
	if(bs+bp<index & index<=bsegment-bc) r=index-bs-bp+boutwatv;
	else if(bs+bp+bc<index & index<=bsegment) r=index-bs-bp-bc+binwatv;
	else if(bsegment+bs+bp<index & index<=bsegment+bs+bp+bc) r=index-bsegment-bs-bp+boutwatv;
	else if(bsegment+bs+bp+bc<index) r=index-bsegment-bs-bp-bc+binwatv;
	else assert(false);
      
	if(nlb+cstr->clause.gub(r)<=numb(-1)
	   | ub+cstr->clause.gnlb(r)<=numb(-1) )
	  return false;
      }
  }
  if(!Constraint::pure_bounded){
    // Second, unbounded variables
    int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
    int usegment=us+up+uc+uc;
    for(Actions_Sequence::const_iterator it=unbounded_channels_guard.begin(); 
	it!=unbounded_channels_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int ri=0, rj=0;
      
	if(i<=us) ri=i;
	else if(i<=us+up) ri=i-us+uatv;
	else if(i<=us+up+uc) ri=i-us-up+uoutwatv;
	else if(i<=usegment) ri=i-us-up-uc+uinwatv;
	else if(i<=usegment+us) ri=i-usegment;
	else if(i<=usegment+us+up) ri=i-usegment-us+uatv;
	else if(i<=usegment+us+up+uc) ri=i-usegment-us-up+uoutwatv;
	else ri=i-usegment-us-up-uc+uinwatv;
    
	if(j<=us) rj=j;
	else if(j<=us+up) rj=j-us+uatv;
	else if(j<=us+up+uc) rj=j-us-up+uoutwatv;
	else if(j<=usegment) rj=j-us-up-uc+uinwatv;
	else if(j<=usegment+us) rj=j-usegment;
	else if(j<=usegment+us+up) rj=j-usegment-us+uatv;
	else if(j<=usegment+us+up+uc) rj=j-usegment-us-up+uoutwatv;
	else rj=j-usegment-us-up-uc+uinwatv;
      
#ifdef DEBUG_CHANNEL_VALIDITY
	cout << "check channel validity % (i,ri):(j,rj) " 
	     << ":(" << i << "," << ri << "):("  
	     << j << "," << rj << ")" << endl ;
      
	cout << "check channel validity % gij : "  << it->get_dbm().get(0,1) 
	     << ", rij: " << cstr->dbm.get(ri,rj) << endl ;
      
	cout << "check channel validity % gji : "  << it->get_dbm().get(1,0) 
	     << ", rji: " << cstr->dbm.get(rj,ri) << endl ;
#endif
      
	if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1)
	   | it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1) )
	  return false;
      }
  }
  return true;
}


/* Inpput: non_covered is a set of dbms to be covered
 *         shared variables are encoded in cstr at [1,sv]
 *         sending process is encoded in cstr at [atv+1, atv+pv]
 *         witness channel is encoded in cstr at [wv+1, wv+cv]
 * Output: non_covered diminished by the (sv,atv,wv) combination        
 */
Confederation SDGT::restrict_non_covered(Confederation& non_covered, int batv, int uatv, int boutwatv, int uoutwatv, 
					 int binwatv, int uinwatv, const Constraint_Ref& cstr) const
{

#ifdef DEBUG_RESTRICT_NON_COVERED
  cout << endl
       << "restrict_non_covered% (batv, binwatv, boutwatv): (" << batv << "," << binwatv << "," << boutwatv << ")"<< endl 
       << "restrict_non_covered% (uatv, uinwatv, uoutwatv): (" << uatv << "," << uinwatv << "," << uoutwatv << ")"<< endl 
       << "restrict_non_covered% input non_covered : " << non_covered << endl
       << "restrict_non_covered% input constraint : " << cstr_dbm << endl;
#endif

  //first, bounded witness
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  Clause current_bounded_witness(bs+bp+bc+bc);
  if(!Constraint::pure_unbounded){
    for(int i=1; i<=bs; ++i)
      current_bounded_witness.modify(i, cstr->clause.gnlb(i), cstr->clause.gub(i));
    for(int i=batv+1; i<=batv+bp; ++i)
      current_bounded_witness.modify(bs+i-batv, cstr->clause.gnlb(i), cstr->clause.gub(i));
    for(int i=boutwatv+1; i<=boutwatv+bc; ++i)
      current_bounded_witness.modify(bs+bp+i-boutwatv, cstr->clause.gnlb(i), cstr->clause.gub(i));
    for(int i=binwatv+1; i<=binwatv+bc; ++i)
      current_bounded_witness.modify(bs+bp+bc+i-binwatv, cstr->clause.gnlb(i), cstr->clause.gub(i));
  
#ifdef DEBUG_RESTRICT_NON_COVERED
    cout << "restrict_non_covered% current_bounded_witness " << current_bounded_witness << endl ;
#endif
  }

  // then, unbounded witness 
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  Dbm current_unbounded_witness(us+up+uc+uc);
  if(!Constraint::pure_bounded){
    for(int i=0; i<=us; ++i){
      for(int j=i+1; j<=us; ++j){
	current_unbounded_witness.put(i, j, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j, i, cstr->dbm.get(j,i));
      }
      for(int j=uatv+1; j<=uatv+up; ++j){
	current_unbounded_witness.put(i, j-uatv+us, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uatv+us, i, cstr->dbm.get(j,i));
      }
      for(int j=uoutwatv+1; j<=uoutwatv+uc; ++j){
	current_unbounded_witness.put(i, j-uoutwatv+us+up, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uoutwatv+us+up, i, cstr->dbm.get(j,i));
      }
      for(int j=uinwatv+1; j<=uinwatv+uc; ++j){
	current_unbounded_witness.put(i, j-uinwatv+us+up+uc, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uinwatv+us+up+uc, i, cstr->dbm.get(j,i));
      }
    }
    for(int i=uatv+1; i<=uatv+up; ++i){
      for(int j=0; j<=us; ++j){
	current_unbounded_witness.put(i-uatv+us, j, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j, i-uatv+us, cstr->dbm.get(j,i));
      }
      for(int j=i+1; j<=uatv+up; ++j){
	current_unbounded_witness.put(i-uatv+us, j-uatv+us, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uatv+us, i-uatv+us, cstr->dbm.get(j,i));
      }
      for(int j=uoutwatv+1; j<=uoutwatv+uc; ++j){
	current_unbounded_witness.put(i-uatv+us, j-uoutwatv+us+up, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uoutwatv+us+up, i-uatv+us, cstr->dbm.get(j,i));
      }
      for(int j=uinwatv+1; j<=uinwatv+uc; ++j){
	current_unbounded_witness.put(i-uatv+us, j-uinwatv+us+up+uc, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uinwatv+us+up+uc, i-uatv+us, cstr->dbm.get(j,i));
      }
    }
    for(int i=uoutwatv+1; i<=uoutwatv+uc; ++i){
      for(int j=0; j<=us; ++j){
	current_unbounded_witness.put(i-uoutwatv+us+up, j, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j, i-uoutwatv+us+up, cstr->dbm.get(j,i));
      }
      for(int j=uatv+1; j<=uatv+up; ++j){
	current_unbounded_witness.put(i-uoutwatv+us+up, j-uatv+us, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uatv+us, i-uoutwatv+us+up, cstr->dbm.get(j,i));
      }
      for(int j=i+1; j<=uoutwatv+uc; ++j){
	current_unbounded_witness.put(i-uoutwatv+us+up, j-uoutwatv+us+up, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uoutwatv+us+up, i-uoutwatv+us+up, cstr->dbm.get(j,i));
      }
      for(int j=uinwatv+1; j<=uinwatv+uc; ++j){
	current_unbounded_witness.put(i-uoutwatv+us+up, j-uinwatv+us+up+uc, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uinwatv+us+up+uc, i-uoutwatv+us+up, cstr->dbm.get(j,i));
      }
    }
    for(int i=uinwatv+1; i<=uinwatv+uc; ++i){
      for(int j=0; j<=us; ++j){
	current_unbounded_witness.put(i-uinwatv+us+up+uc, j, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j, i-uinwatv+us+up+uc, cstr->dbm.get(j,i));
      }
      for(int j=uatv+1; j<=uatv+up; ++j){
	current_unbounded_witness.put(i-uinwatv+us+up+uc, j-uatv+us, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uatv+us, i-uinwatv+us+up+uc, cstr->dbm.get(j,i));
      }
      for(int j=uoutwatv+1; j<=uoutwatv+uc; ++j){
	current_unbounded_witness.put(i-uinwatv+us+up+uc, j-uoutwatv+us+up, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uoutwatv+us+up, i-uinwatv+us+up+uc, cstr->dbm.get(j,i));
      }
      for(int j=i+1; j<=uinwatv+uc; ++j){
	current_unbounded_witness.put(i-uinwatv+us+up+uc, j-uinwatv+us+up+uc, cstr->dbm.get(i,j));
	current_unbounded_witness.put(j-uinwatv+us+up+uc, i-uinwatv+us+up+uc, cstr->dbm.get(j,i));
      }
    }
#ifdef DEBUG_RESTRICT_NON_COVERED
    cout << "restrict_non_covered% current_unbounded_witness " << current_unbounded_witness <<  endl ;
#endif
  }  
  return non_covered - pair<Clause, Dbm> (current_bounded_witness, current_unbounded_witness);
}

pair<Clause,Dbm> SDGT::fire_position_specified_witness_no_insertion(int at, int w, int boutwatv,int uoutwatv, int binwatv,int uinwatv, 
						       int batv, int uatv, const Constraint_Ref& cstr) const
{

#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
  cout << "fire no insertion % input (at,w,boutwatv,binwatv,batv) : ("
       << at << ","<< w << "," << boutwatv << "," << binwatv << "," << batv << ")"   << endl ;
  cout << "fire no insertion % input (uoutwatv,uinwatv,uatv) : ("
       << uoutwatv << "," << uinwatv << "," << uatv << ")"   << endl ;
#endif
  
  //first the bounded part
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc+bc;
  Clause  working_clause=cstr->clause;

  if(!Constraint::pure_unbounded){
    // relax the modified variables
    set<int>::const_iterator mit;
    for(mit=bounded_shared_modified.begin(); mit!=bounded_shared_modified.end(); ++mit)  
      working_clause.modify(*mit, Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
    for(mit=bounded_process_modified.begin(); mit!=bounded_process_modified.end(); ++mit)  
      working_clause.modify(batv+*mit-bs,Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
    for(mit=bounded_channels_modified.begin(); mit!=bounded_channels_modified.end(); ++mit) 
      if(*mit<=bs+bp+bc) working_clause.modify(boutwatv+*mit-bs-bp,Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
      else working_clause.modify(binwatv+*mit-bs-bp-bc,Constraint::Bb.gnlb(*mit-bc), Constraint::Bb.gub(*mit-bc));
  
    // tighten whatever variable that was not modified, or is predecessor 
    // of a modified variable
    for(Actions_Sequence::const_iterator it=bsequence.begin(); it!=bsequence.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
      
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));

	if(index<=bs)	
	  {if(!working_clause.tighten(index, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
	else if(index<=bs+bp)
	  {if(!working_clause.tighten(index-bs+batv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
	else if(index<=bsegment-bc) 
	  {if(!working_clause.tighten(index-bs-bp+boutwatv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
	else if(index<=bsegment)
	  {if(!working_clause.tighten(index-bs-bp-bc+binwatv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
      }
  
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion % obtained clause :  " << working_clause << endl;
#endif 
  }

  //second, unbounded part
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc+uc;
  Dbm  working_dbm(cstr->dbm.vars_card()+unbounded_shared_modified.size()
		   +unbounded_process_modified.size()+unbounded_channels_modified.size());

  if(!Constraint::pure_bounded){
    //copy the constraint. send the modified values according to modification.
    for(int i=0; i<=cstr->dbm.vars_card(); ++i){
      int bi=constraint_to_working(i, cstr->dbm.vars_card(), uatv, uoutwatv, uinwatv);
      for(int j=i+1; j<=cstr->dbm.vars_card(); ++j){
	int bj=constraint_to_working(j, cstr->dbm.vars_card(), uatv, uoutwatv, uinwatv);
	working_dbm.put(bi, bj, cstr->dbm.get(i,j));
	working_dbm.put(bj, bi, cstr->dbm.get(j,i));
      }
    }
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion % after copying constraint : " << working_dbm << endl ;
#endif
    // Get the bounds to the newly created variables 
    set<int>::const_iterator mit;
    for(mit=unbounded_shared_modified.begin(); mit!=unbounded_shared_modified.end(); ++mit)
      if(!working_dbm.tighten(0,*mit,Constraint::Ub.gnlb(*mit)))  return pair<Clause, Dbm>(Clause(), Dbm());
    for(mit=unbounded_process_modified.begin(); mit!=unbounded_process_modified.end(); ++mit)
      if(!working_dbm.tighten(0,uatv+*mit-us,Constraint::Ub.gnlb(*mit))) return pair<Clause, Dbm>(Clause(), Dbm());
    for(mit=unbounded_channels_modified.begin(); mit!=unbounded_channels_modified.end(); ++mit)
      if(*mit<=usegment-uc)
	{if(!working_dbm.tighten(0,uoutwatv+*mit-us-up,Constraint::Ub.gnlb(*mit)))return pair<Clause, Dbm>(Clause(), Dbm());}
      else 
	{if(!working_dbm.tighten(0,uinwatv+*mit-us-up-uc,Constraint::Ub.gnlb(*mit-uc))) return pair<Clause, Dbm>(Clause(), Dbm());}

    // Finally apply the sequence of actions
    for(Actions_Sequence::const_iterator it=usequence.begin(); 
	it!=usequence.end(); ++it)
      { //for each action
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
	cout << "fire no insertion % considering action : " << *it << endl;
#endif   
	int i=it->get_cipher().first(), j=it->get_cipher().second();

	int wi=action_to_working(i, uatv, uoutwatv, uinwatv, usegment, cstr->dbm.vars_card()); // in working dbm
	int wj=action_to_working(j, uatv, uoutwatv, uinwatv, usegment, cstr->dbm.vars_card());

	if(!working_dbm.tighten(wi,wj,it->get_dbm().get(0,1)) 
	   | !working_dbm.tighten(wj,wi,it->get_dbm().get(1,0)))
	  return pair<Clause, Dbm>(Clause(), Dbm());
      }

    working_dbm=working_dbm.project_away(cstr->dbm.vars_card()+1, cstr->dbm.vars_card() 
					 + unbounded_shared_modified.size()+unbounded_process_modified.size()
					 + unbounded_channels_modified.size());
  
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion% obtained dbm : " << working_dbm << endl ;
#endif    
  }
  
  return pair<Clause, Dbm> (working_clause, working_dbm);
}

inline int SDGT::constraint_to_working(int i, int ucs, 
				       int uatv, int uoutwatv, int uinwatv) const
{
  if(i<=Constraint::us) 
    if(unbounded_shared_modified.find(i)!=unbounded_shared_modified.end()) return ucs+modification.find(i)->second;
    else return i;
  else
    if(uatv<i & i<=uatv+Constraint::up) 
      if(unbounded_process_modified.find(Constraint::us+i-uatv)!=unbounded_process_modified.end())
	return ucs+(modification.find(Constraint::us+i-uatv)->second);
      else return i;
    else
      if(uoutwatv<i & i<=uoutwatv+Constraint::uc ) 
	if(unbounded_channels_modified.find(Constraint::us+Constraint::up+i-uoutwatv)!=unbounded_channels_modified.end())
	  return ucs+(modification.find(Constraint::us+Constraint::up+i-uoutwatv)->second);
	else return i;
      else
	if(uinwatv<i & i<=uinwatv+Constraint::uc ) 
	  if(unbounded_channels_modified.find(Constraint::us+Constraint::up+Constraint::uc+i-uinwatv)!=unbounded_channels_modified.end())
	    return ucs+(modification.find(Constraint::us+Constraint::up+Constraint::uc+i-uinwatv)->second);
	  else return i;
	else return i;
}



/* 
 */
inline int SDGT::action_to_working(int i, int uatv, int uoutwatv, int uinwatv, 
				   int usegment, int ucs)const
{
  if(i<=Constraint::us)  return i; 
  else  if(i<=Constraint::us+Constraint::up) return uatv+i-Constraint::us; 
  else  if(i<=usegment-Constraint::uc) return uoutwatv+i-Constraint::us-Constraint::up;
  else  if(i<=usegment) return uinwatv+i-Constraint::us-Constraint::up-Constraint::uc;
  else  return ucs+(modification.find(i-usegment)->second); 
}


pair<Clause,Dbm> SDGT::fire_position_inserted_witness(int at, int insert_position,  
						      const Constraint_Ref& cstr, const pair<Clause,Dbm>& restriction)const
{

#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
  cout << "fire insertion % input (at,insert_position,cn) : (" << at << ","<< insert_position << ")" << endl ;
  cout << "fire insertion % input restriction (" << endl << restriction.first << restriction.second  << endl ;
#endif

  int cn=cstr->cardinal();
  int ncn=cn+1; //new number of processes 
  int shift=(insert_position<=at? 1:0);//shift the "at" if insertion at "at" or to its left

  // first, the bounded part
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc+bc;    
  
  int bcs=cstr->clause.vars_card();//old number of variables
  int nbcs=bs+ncn*(bp+(ncn-1)*bc);//new number of variables
  assert(nbcs==bcs+bp+2*cn*bc);
  
  int batv=bs+(at-1)*(bp+(cn-1)*bc); //old begining of process's variables 
  int nbatv=bs+(at+shift-1)*(bp+(ncn-1)*bc); //new begining of process's variables 
  
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int uatv=us+(at-1)*(up+(cn-1)*uc);         //old begining of process's variables 

  // insatisfiable insertion?
  if(!check_insertion_satisfiable(batv, uatv, cstr, restriction))
    return pair<Clause, Dbm>(Clause(), Dbm());

  // copy the clause
  Clause  working_clause(nbcs);

  if(!Constraint::pure_unbounded){
    for(int i=1; i<=bcs; ++i){
      int b=0;
      if(i<=bs) b=i;
      else{
	int old_sender=(i-bs-1)/(bp+(cn-1)*bc)+1;
	int new_sender=old_sender+(insert_position<=old_sender? 1:0);
	int pvar=((i-bs-1)%(bp+(cn-1)*bc))+1;
	if(pvar<=bp) b=bs+(new_sender-1)*(bp+(ncn-1)*bc)+pvar;
	else{
	  int old_receiver=((pvar-bp-1)/bc)+1;
	  old_receiver=(old_sender<=old_receiver?old_receiver+1: old_receiver);
	  int new_receiver=old_receiver+(insert_position<=old_receiver? 1:0);
	  int new_receiver_shift=(new_sender<=new_receiver?-1:0);
	  int cvar=(pvar-bp-1)%bc+1;
	  b=bs+(new_sender-1)*(bp+(ncn-1)*bc)+ bp
	    + (new_receiver+new_receiver_shift-1)*bc
	    + cvar;
	}
      }
      working_clause.modify(b, cstr->clause.gnlb(i), cstr->clause.gub(i));
    }
    
#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire_position_inserted_witness% copied clause : " << working_clause << endl ;
#endif  

    //new begining of channel's bounded variables 
    int nboutwatv=bs +(at+shift-1)*(bp+(ncn-1)*bc)+bp
      +(insert_position<at+shift? insert_position-1 : insert_position-2)*bc;

    int nbinwatv=bs +(insert_position-1)*(bp+(ncn-1)*bc)+bp
      +(insert_position<at+shift? at+shift-2 : at+shift-1)*bc;

    // relax the non inserted assigned variables
    set<int>::const_iterator mit;
    for(mit=bounded_shared_modified.begin(); mit!=bounded_shared_modified.end(); ++mit)  
      working_clause.modify(*mit, Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
    for(mit=bounded_process_modified.begin(); mit!=bounded_process_modified.end(); ++mit)  
      working_clause.modify(nbatv+*mit-bs,Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));

#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire_position_inserted_witness% relaxed clause : " << working_clause << endl ;
#endif  

    // apply the restriction for non modified variables
    // this would for instance restrict the variables that were assigned,
    // but not restricted by the guard.
    for(int i=1; i<=bs; ++i)
      if(bounded_shared_modified.find(i)==bounded_shared_modified.end())
	if(!working_clause.tighten(i, restriction.first.gnlb(i), restriction.first.gub(i)))
	  return pair<Clause, Dbm>(Clause(), Dbm());
    for(int i=bs+1; i<=bs+bp; ++i)
      if(bounded_process_modified.find(i)==bounded_process_modified.end())
	if(!working_clause.tighten(nbatv+i-bs, restriction.first.gnlb(i), restriction.first.gub(i)))
	  return pair<Clause, Dbm>(Clause(), Dbm());
    for(int i=bs+bp+1; i<=bs+bp+bc; ++i)
      if(bounded_channels_modified.find(i)==bounded_channels_modified.end())
	if(!working_clause.tighten(nboutwatv+i-bs-bp, restriction.first.gnlb(i), restriction.first.gub(i)))
	  return pair<Clause, Dbm>(Clause(), Dbm());
    for(int i=bs+bp+bc+1; i<=bsegment; ++i)
      if(bounded_channels_modified.find(i)==bounded_channels_modified.end())
	if(!working_clause.tighten(nbinwatv+i-bs-bp-bc, restriction.first.gnlb(i), restriction.first.gub(i)))
	  return pair<Clause, Dbm>(Clause(), Dbm());

#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire_position_inserted_witness% apply restriction: " << working_clause << endl ;
#endif  
  
    // apply the rule for predecessors of modified variables 
    // tighten whatever variable that was not modified, or is predecessor 
    // of a modified variable
    for(Actions_Sequence::const_iterator it=bsequence.begin(); it!=bsequence.end(); ++it){
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      int index=(i==0? j: i);
      numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
      numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
      if(index<=bs) 
	{if(!working_clause.tighten(index, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
      else if(index<=bs+bp) 
	{if(!working_clause.tighten(index-bs+nbatv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
      else if(index<=bs+bp+bc) 
	{if(!working_clause.tighten(index-bs-bp+nboutwatv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
      else if(index<=bsegment) 
	{if(!working_clause.tighten(index-bs-bp-bc+nbinwatv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
    }
  
#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire_position_inserted_witness% apply predecessors: " << working_clause << endl ;
#endif  
  
    // Finally, Get the bounds to the newly created variables Because of the inserted witness.
    for(int p=1; p<insert_position; ++p)
      for(int c=1; c<=bc; ++c){// for each channel variable
	assert(working_clause.tighten(bs+(p-1)*(bp+(ncn-1)*bc)+bp+(insert_position-2)*bc+c, 
				      Constraint::Bb.gnlb(bs+bp+c), Constraint::Bb.gub(bs+bp+c)));
	assert(working_clause.tighten(bs+(insert_position-1)*(bp+(ncn-1)*bc)+bp+(p-1)*bc+c, 
				      Constraint::Bb.gnlb(bs+bp+c), Constraint::Bb.gub(bs+bp+c)));
      }
    for(int p=1; p<=bp; ++p)// for each process variable
      assert(working_clause.tighten(bs+(insert_position-1)*(bp+(ncn-1)*bc)+p, Constraint::Bb.gnlb(bs+p), Constraint::Bb.gub(bs+p)));
    for(int p=insert_position+1; p<=ncn; ++p)
      for(int c=1; c<=bc; ++c){// for each channel variable
	assert(working_clause.tighten(bs+(p-1)*(bp+(ncn-1)*bc)+bp+(insert_position-1)*bc+c, 
				      Constraint::Bb.gnlb(bs+bp+c), Constraint::Bb.gub(bs+bp+c)));
	assert(working_clause.tighten(bs+(insert_position-1)*(bp+(ncn-1)*bc)+bp+(p-2)*bc+c, 
				      Constraint::Bb.gnlb(bs+bp+c), Constraint::Bb.gub(bs+bp+c)));
      }

#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire_position_inserted_witness% obtained clause : " << working_clause << endl ;
#endif
  }

  // Second, the unbounded part
  int usegment=us+up+uc+uc;    
  int ucs=cstr->dbm.vars_card();//old number of variables
  int nucs=us+ncn*(up+(ncn-1)*uc);//new number of variables
  assert(nucs==ucs+up+2*cn*uc);
  
  // the resulting dbm will start by having as many variables 
  // as required by the insertion of a new process plus the modified ones. 
  Dbm working_dbm(nucs+unbounded_shared_modified.size()
		  +unbounded_process_modified.size()+unbounded_channels_modified.size());

  if(!Constraint::pure_bounded){
    int nuatv=us+(at+shift-1)*(up+(ncn-1)*uc); //new begining of process's variables 
    int nuoutwatv=us+(at+shift-1)*(up+(ncn-1)*uc)+up
      +(insert_position<at+shift? insert_position-1 : insert_position-2)*uc;

    int nuinwatv=us+(insert_position-1)*(up+(ncn-1)*uc)+up
      +(insert_position<at+shift? at+shift-2 : at+shift-1)*uc;

    // Copy the constraint to the working_dbm
    for(int i=0; i<=ucs; ++i){
      int bi=constraint_to_inserted_working(i,nucs,cn, ncn, at, insert_position);
      for(int j=i+1; j<=ucs; ++j){
	int bj=constraint_to_inserted_working(j,nucs,cn, ncn, at, insert_position);
	working_dbm.put(bi, bj, cstr->dbm.get(i,j));
	working_dbm.put(bj, bi, cstr->dbm.get(j,i));
      }
    }
  
#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire insertion % after copying dbm : " << working_dbm << endl ;
#endif

  
    //get the restriction
    for(int i=0; i<=us; ++i){
      int ix=(unbounded_shared_modified.find(i)==unbounded_shared_modified.end()? i:nucs+modification.find(i)->second);
      for(int j=i+1; j<=us; ++j){
	int jx=(unbounded_shared_modified.find(j)==unbounded_shared_modified.end()? j:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
	if(!working_dbm.tighten(jx,ix,restriction.second.get(j,i))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+1; j<=us+up; ++j){
	int jx=(unbounded_process_modified.find(j)==unbounded_process_modified.end()? nuatv+j-us:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+up+1; j<=us+up+uc; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? nuoutwatv+j-us-up:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+up+uc+1; j<=usegment; ++j){
	int jx=(unbounded_process_modified.find(j)==unbounded_process_modified.end()? nuinwatv+j-us-up-uc:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
    }
    for(int i=us+1; i<=us+up; ++i){
      int ix=(unbounded_process_modified.find(i)==unbounded_process_modified.end()? nuatv+i-us:nucs+modification.find(i)->second);
      for(int j=0; j<=us; ++j){
	int jx=(unbounded_shared_modified.find(j)==unbounded_shared_modified.end()? j:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=i+1; j<=us+up; ++j){
	int jx=(unbounded_process_modified.find(j)==unbounded_process_modified.end()? nuatv+j-us:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
	if(!working_dbm.tighten(jx,ix,restriction.second.get(j,i))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+up+1; j<=us+up+uc; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? nuoutwatv+j-us-up:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+up+uc+1; j<=usegment; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? 
		nuinwatv+j-us-up-uc:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
    }
    for(int i=us+up+1; i<=us+up+uc; ++i){
      int ix=(unbounded_channels_modified.find(i)==unbounded_channels_modified.end()? nuoutwatv+i-us-up:nucs+modification.find(i)->second);
      for(int j=0; j<=us; ++j){
	int jx=(unbounded_shared_modified.find(j)==unbounded_shared_modified.end()? j:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+1; j<=us+up; ++j){
	int jx=(unbounded_process_modified.find(j)==unbounded_process_modified.end()? nuatv+j-us:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=i+1; j<=us+up+uc; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? nuoutwatv+j-us-up:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
	if(!working_dbm.tighten(jx,ix,restriction.second.get(j,i))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+up+uc+1; j<=usegment; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? 
		nuinwatv+j-us-up-uc:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
    }
    for(int i=us+up+uc+1; i<=usegment; ++i){
      int ix=(unbounded_channels_modified.find(i)==unbounded_channels_modified.end()? nuinwatv+i-us-up-uc:nucs+modification.find(i)->second);
      for(int j=0; j<=us; ++j){
	int jx=(unbounded_shared_modified.find(j)==unbounded_shared_modified.end()? j:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+1; j<=us+up; ++j){
	int jx=(unbounded_process_modified.find(j)==unbounded_process_modified.end()? nuatv+j-us:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=us+up+1; j<=us+up+uc; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? nuoutwatv+j-us-up:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
      for(int j=i+1; j<=usegment; ++j){
	int jx=(unbounded_channels_modified.find(j)==unbounded_channels_modified.end()? 
		nuinwatv+j-us-up-uc:nucs+modification.find(j)->second);
	if(!working_dbm.tighten(ix,jx,restriction.second.get(i,j))) return pair<Clause,Dbm> (Clause(),Dbm());
	if(!working_dbm.tighten(jx,ix,restriction.second.get(j,i))) return pair<Clause,Dbm> (Clause(),Dbm());
      }
    }
  
#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire insertion % after restriction : " << working_dbm << endl ;
#endif

    // Finally apply the sequence of actions 
    for(Actions_Sequence::const_iterator it=usequence.begin(); it!=usequence.end(); ++it)
      {// for each action
#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
	cout << "fire insertion % considering actions : "<< *it  << endl;
#endif   

	int i=it->get_cipher().first(), j=it->get_cipher().second();

	int wi=action_to_inserted_working(i, uatv, nuatv, nuoutwatv, nuinwatv, usegment, nucs);
	int wj=action_to_inserted_working(j, uatv, nuatv, nuoutwatv, nuinwatv, usegment, nucs);

	if(!working_dbm.tighten(wi,wj,it->get_dbm().get(0,1)) 
	   | !working_dbm.tighten(wj,wi,it->get_dbm().get(1,0)))
	  return pair<Clause, Dbm>(Clause(), Dbm());
      
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
	cout << "fire no insertion % after action's application  " << working_dbm << endl;
#endif 
      }


    // Get the bounds to the newly created variables Because of the modifications
    set<int>::const_iterator mit;
    for(mit=unbounded_shared_modified.begin(); mit!=unbounded_shared_modified.end(); ++mit)
      assert(working_dbm.tighten(0,*mit,Constraint::Ub.gnlb(*mit)));
    for(mit=unbounded_process_modified.begin(); mit!=unbounded_process_modified.end(); ++mit)
      assert(working_dbm.tighten(0,nuatv+*mit-us,Constraint::Ub.gnlb(*mit)));

#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire insertion % after bounding modified : " << working_dbm << endl ;
#endif

    // Get the bounds to the newly created variables Because of the inserted witness.
    // for each process to the left of the inserted process
    for(int p=1; p<insert_position; ++p)
      for(int c=1; c<=uc; ++c){// for each channel variable
	assert(working_dbm.tighten(0, us+(p-1)*(up+(ncn-1)*uc)+up+(insert_position-2)*uc+c, Constraint::Ub.gnlb(us+up+c)));
	assert(working_dbm.tighten(0, us+(insert_position-1)*(up+(ncn-1)*uc)+up+(p-1)*uc+c, Constraint::Ub.gnlb(us+up+c)));
      }
  
    for(int p=1; p<=up; ++p)// for each process variable
      assert(working_dbm.tighten(0, us+(insert_position-1)*(up+(ncn-1)*uc)+p, Constraint::Ub.gnlb(us+p)));
  
    for(int p=insert_position+1; p<=ncn; ++p)
      for(int c=1; c<=uc; ++c){// for each channel variable
	assert(working_dbm.tighten(0, us+(p-1)*(up+(ncn-1)*uc)+up+(insert_position-1)*uc+c, Constraint::Ub.gnlb(us+up+c)));
	assert(working_dbm.tighten(0, us+(insert_position-1)*(up+(ncn-1)*uc)+up+(p-2)*uc+c, Constraint::Ub.gnlb(us+up+c)));
      }

#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire insertion % after bounding new variables: " << working_dbm << endl ;
#endif

    working_dbm=working_dbm.project_away(nucs+1, nucs+unbounded_shared_modified.size()
					 +unbounded_process_modified.size()
					 +unbounded_channels_modified.size());
  
#ifdef DEBUG_FIRE_POSITION_INSERTED_WITNESS
    cout << "fire insertion % obtained dbm : " << working_dbm << endl ;
#endif    
  }
  return pair<Clause, Dbm>(working_clause, working_dbm);
}


/*
 */
inline int SDGT::constraint_to_inserted_working(int i, int nucs, int cn, int ncn, 
						int at, int insert_position) const
{
  if(i<=Constraint::us)
    if(unbounded_shared_modified.find(i)!=unbounded_shared_modified.end())
      return nucs+modification.find(i)->second;
    else
      return i;
  else
    {
      int old_sender=(i-Constraint::us-1)/(Constraint::up+(cn-1)*Constraint::uc)+1;
      int new_sender=old_sender+(insert_position<=old_sender? 1:0);
      int pvar=((i-Constraint::us-1)%(Constraint::up+(cn-1)*Constraint::uc))+1;
      if(pvar<=Constraint::up)
	if(old_sender==at)
	  if(unbounded_process_modified.find(pvar+Constraint::us)!=unbounded_process_modified.end())
	    return nucs+modification.find(pvar+Constraint::us)->second;
	  else return Constraint::us+(new_sender-1)*(Constraint::up+(ncn-1)*Constraint::uc)+pvar;
	else return Constraint::us+(new_sender-1)*(Constraint::up+(ncn-1)*Constraint::uc)+pvar;
      else
	{//channel variable
	  int old_receiver=((pvar-Constraint::up-1)/Constraint::uc)+1;
	  old_receiver=(old_sender<=old_receiver?old_receiver+1: old_receiver);
	  int new_receiver=old_receiver+(insert_position<=old_receiver? 1:0);
	  int new_receiver_shift=(new_sender<=new_receiver?-1:0);
	  int cvar=(pvar-Constraint::up-1)%Constraint::uc+1;

	  return Constraint::us+(new_sender-1)*(Constraint::up+(ncn-1)*Constraint::uc)
	    + Constraint::up
	    + (new_receiver+new_receiver_shift-1)*Constraint::uc
	    + cvar;
	}
    }
}

/* 
 */
inline int SDGT::action_to_inserted_working(int i, int uatv, int nuatv, int nuoutwatv, 
					    int nuinwatv, int usegment, int nucs)const
{
  if(i<=Constraint::us)   return i;
  else if(i<=Constraint::us+Constraint::up) return nuatv+i-Constraint::us;
  else if(i<=usegment-Constraint::uc) return nuoutwatv+i-Constraint::us-Constraint::up;
  else if(i<=usegment) return nuinwatv+i-Constraint::us-Constraint::up-Constraint::uc;
  else return nucs+(modification.find(i-usegment)->second);
}

bool SDGT::check_insertion_satisfiable(int batv, int uatv, const Constraint_Ref& cstr, const pair<Clause,Dbm>& restriction) const
{
  assert(restriction.first.vars_card()==Constraint::bs+Constraint::bp+Constraint::bc+Constraint::bc);
  assert(restriction.second.vars_card()==Constraint::us+Constraint::up+Constraint::uc+Constraint::uc);
  
  // first, bounded part
  for(int i=1; i<=Constraint::bs; ++i)
    if(cstr->clause.gnlb(i)+restriction.first.gub(i)<=numb(-1)
       | cstr->clause.gub(i)+restriction.first.gnlb(i)<=numb(-1))
      return false;

  for(int i=Constraint::bs+1; i<=Constraint::bs+Constraint::bp; ++i)
    if(cstr->clause.gnlb(i-Constraint::bs+batv)+restriction.first.gub(i)<=numb(-1)
       | cstr->clause.gub(i-Constraint::bs+batv)+restriction.first.gnlb(i)<=numb(-1))
      return false;

  // second, the unbounded part
  for(int i=0; i<=Constraint::us;i++){
    for(int j=i+1; j<=Constraint::us;j++){
      if(restriction.second.get(i,j)+cstr->dbm.get(j,i)<=numb(-1)
	 | restriction.second.get(j,i)+cstr->dbm.get(i,j)<=numb(-1))
	return false;
    }
    for(int j=Constraint::us+1; j<=Constraint::us+Constraint::up;j++){
      if(restriction.second.get(i,j)+cstr->dbm.get(uatv+j-Constraint::us,i)<=numb(-1)
	 | restriction.second.get(j,i)+cstr->dbm.get(i,uatv+j-Constraint::us)<=numb(-1))
	return false;
    }
  }

  for(int i=Constraint::us+1; i<=Constraint::us+Constraint::up;i++){
    for(int j=i+1; j<=Constraint::us+Constraint::up;j++){
      if(restriction.second.get(i,j)+cstr->dbm.get(uatv+j-Constraint::us,uatv+i-Constraint::us)<=numb(-1)
	 | restriction.second.get(j,i)+cstr->dbm.get(uatv+i-Constraint::us,uatv+j-Constraint::us)<=numb(-1))
	return false;
    }
  }
  return true;
}

void SDGT::printOn(ostream& o) const
{


#ifdef PRINT_PROCESS_CHANNEL

#else
  cout << "SDGT id: " << rid << endl;
  cout << "SDGT domain: " << (domain==L? "L" : (domain==R? "R" : "LR")) << endl;
  cout << "SDGT bsequence: " << bsequence << endl;
  cout << "SDGT bounded_shared_process_guard : " << bounded_shared_and_process_guard << endl;
  cout << "SDGT bounded_channels_guard : " << bounded_channels_guard << endl;
  cout << "SDGT usequence: " << usequence << endl;
  cout << "SDGT unbounded_shared_process_guard : " << unbounded_shared_and_process_guard << endl;
  cout << "SDGT unbounded_channels_guard : " << unbounded_channels_guard << endl;
#endif  
}








