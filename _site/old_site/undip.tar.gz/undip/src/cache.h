/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/**@file algorithms.h
 * Definition of the reachability cache.
 *
 *@author Ahmed Rezine
 */

#ifndef _UNDIP_CACHE_H
#define _UNDIP_CACHE_H

#define DEBUG_SET_INSERT

#include <map>

#include "printable.h"
#include "constraint.h"
#include "minset.h"
#include "order.h"
#include <time.h>

/**
 * Cache is simply a map n-->{constraints of cardinal n}
 * no two constraints are related (i.e. entailing each other)
 */

class Cache : public Printable
  {
    typedef std::map<int, MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > >::iterator store_iterator;
    typedef std::map<int, MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > >::const_iterator store_const_iterator;
    typedef MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >::iterator set_iterator;
    typedef MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >::const_iterator set_const_iterator;

  public:
    Cache(const MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >& _initial):max(0)
      {
	for( set_const_iterator it=_initial.begin();  it != _initial.end(); it++)
	  this->insert(*it);
      }
    
    bool insert(const Constraint_Ref& cstr)
    {
      if(includes(cstr))
	return false;

      int c=cstr->cardinal();
      
      store_iterator cacheit=store.find(c);

      if(cacheit==store.end())
	{//add new stage

	  if(max<c)
	    max=c;

	  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > singleton;
	  singleton.insert(cstr);
	  store[c] = singleton; 

	  clean_upstairs(++c, cstr);

	  return true;
	 }

      //add it to those with same cardinality.
      //      assert(cacheit->second.insert(cstr, true));
      assert(cacheit->second.insert(cstr));
      clean_upstairs(++c, cstr);

      return true;
    }

    bool includes(const Constraint_Ref& cstr) const
    {

      int c=cstr->cardinal();

      if(max<c)
	c=max;

      for(int n=c; n>=2; n--)
	{
	  store_const_iterator cacheit=store.find(n);

	  if(cacheit!=store.end())
	    {
	      if(cacheit->second.includes(cstr))
		return true;
	    }
	}

      return false;
    }


    //assume fresh ordered, get it to the cache, and leave in fresh only the ones inserted
     void insert(MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >& fresh)
    {

#ifdef DEBUG_SET_INSERT
      std::cerr << "insertion of " << fresh.size() << " constraints ";

      time_t start,end;
      time(&start);
#endif
      
      for(set_iterator freshit=fresh.begin(); freshit!=fresh.end();)
	{
	  set_iterator nextit=freshit; nextit++;

	  if(includes(*freshit))
	    fresh.erase(freshit);

	  freshit=nextit;
	}
      

      for(set_const_iterator freshit=fresh.begin(); freshit!=fresh.end();freshit++)
	{ //remove from store every constraint entailed by a constraint from remaining fresh

#ifdef DEBUG_SET_INSERT
	  assert(!includes(*freshit));
#endif
	  int c=(*freshit)->cardinal();

	  clean_upstairs(c, (*freshit));
	}

      for(set_const_iterator freshit=fresh.begin(); freshit!=fresh.end();freshit++)
	insert_blindly(*freshit);
      

#ifdef DEBUG_SET_INSERT
	    time(&end);
	    std::cerr << " done in " << difftime(end, start) << "s" << std::endl;

	    std::cerr << "cache set insert % output obtained cache " << *this  <<  std::endl;
#endif

    }

     void insert_blindly(const Constraint_Ref& cstr)
     {
       int c=cstr->cardinal();

       store_iterator cacheit=store.find(c);
      
       if(cacheit!=store.end())
	 cacheit->second.insert(cstr,true);
       else
	 {
	   if(max<c)
	     max=c;

	   MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > singleton;
	   singleton.insert(cstr);
	   store[c] = singleton; 
	 }
     }

    void next(int lb, MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >& fresh) const
    {

      assert(fresh.empty());
      //find in store the constraints with cardinal striclty larger than lb (i.e not less than lb)
      store_const_iterator cacheit=store.lower_bound(lb);

      if(cacheit!=store.end())
	fresh.insert(cacheit->second.begin(), cacheit->second.end(), true);
    }


    void print(std::ostream& out) const {
      for( store_const_iterator cacheit=store.begin(); cacheit!=store.end(); cacheit++){
	out << std::endl << "[" << cacheit->first << "]-->{";
	/*for( set_const_iterator it=cacheit->second.begin(); it!=cacheit->second.end(); it++){
	  out << (*it)->cid << ", ";
	  //out << *(*it) << ", ";
	}*/
	out << cacheit->second.size() ;
	out << "}";
      }
      //      out << "max=" << max << std::endl;
      out << std::endl;
    }

    int number() const
    {
      int s=0;
      for(store_const_iterator it=store.begin(); it!=store.end(); it++)
	s+=it->second.size();
      return s;
    }

    private:

    bool clean_upstairs( int c, const Constraint_Ref& cstr)
      {
	bool cleaned=false;
	for(int n=c; n<=max; n++)
	  {
	    store_iterator cacheit=store.find(n);

	    if(cacheit!=store.end())
	      {
		
		assert(!cacheit->second.empty());

		for( set_iterator minsetit=cacheit->second.begin(); minsetit!=cacheit->second.end(); )
		  {
		    set_iterator nextit=minsetit; ++nextit;
		    
		    if(EntailmentOrder<Constraint_Ref> ()(cstr, *minsetit))
		      {
			cacheit->second.erase(minsetit);
			cleaned=true;
		      }
		    minsetit=nextit;
		  }
		if(cacheit->second.empty())
		  {
		    assert(cleaned);

		    if(max==cacheit->first)
		      {
			store_iterator nxit;;
			for(int b=max-1; b>=1; b--)
			  {
			    nxit=store.find(b);
			    if(nxit!=store.end())
			      break;
			  }
			if(nxit!=store.end())
			  {
			    assert(!nxit->second.empty());
			    //			assert(*(nxit->second.begin()));
			    assert((*(nxit->second.begin()))->cardinal() == nxit->first);
			    max = ((*(nxit->second.begin()))->cardinal());
			    store.erase(cacheit);
			  }
			else
			  {
			    max=0;
			    store.erase(cacheit);
			    assert(store.empty());
			  }
		      }
		  }
	      }
	  }

	return cleaned;
      }

  private:
      std::map<int, MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > > store;
      int max;
  };


 

#endif

