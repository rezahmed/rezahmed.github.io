/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/**@file algorithm.h
 * Definition of the reachability algorithm.
 *
 *@author Ahmed Rezine
 */
#ifndef _ALGORITHM_H
#define _ALGORITHM_H

#define ALG_DEBUG
#define SEPARATE_FILES
#define TRACE_COUNTER

#ifdef ALG_DEBUG
#include <iostream>
#include <time.h>
#ifdef SEPARATE_FILES
#include <fstream>
#include <sstream>
#endif
#endif

#ifdef TRACE_COUNTER
#include <iostream>
#include <map>
#include "trace.h"
#endif



#include "constraint.h"
#include "minset.h"
#include "order.h"
#include "next.h"

#include "cache.h"

using namespace std;

typedef enum {unsafe, safe, dknow} ambiguous;

/**
 * The Symbolic reachability starts from a symbolic set denoted as initial. 
 * The operator "Next" transforms a symbolic set into another symbolic set.
 * V' = V U Next(V) is then applied untill a fixpoint is reached.
 * The result is then: whether the intersection of the fixpoint and the symbolic set
 * final is empty.
 */
class SymbolicFixpoint
{
 public:
 SymbolicFixpoint(const MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >& _initial, 
		  const Next<EntailmentOrder<Constraint_Ref> >* _next, 
	Reached<EntailmentOrder<Constraint_Ref> >* _reached) 
 : initial(_initial), next(_next), reached(_reached){}
    
  ambiguous run()
  {
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > current, fresh;

    bool unique_initial_bound=true;
    bool first_iteration=true;
    assert(!initial.empty());
    int lower_bound=(*(initial.begin()))->cardinal();
    for(MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >::const_iterator init=initial.begin(); init!=initial.end(); init++)
      {
	if((*init)->cardinal()!=lower_bound)
	  unique_initial_bound=false;
      }

    Cache cache(initial);
    fresh.insert(initial.begin(), initial.end());
    bool finished=false;

#ifdef ALG_DEBUG
    time_t start,end;
    unsigned n_iter=0;
#ifdef SEPARATE_FILES
    ofstream myfile;
    myfile.open("iteration-initial.slog");
    myfile << "initial " << endl << initial << endl;
    myfile << "cache " << cache << endl;
    myfile.close();
#else
    //    cout << "initial " << endl << initial << endl;
    //    cout << "cache " << cache << endl;
#endif
#endif

#ifdef TRACE_COUNTER
    Trace trace;
#endif

    do
      {
#ifdef ALG_DEBUG
	n_iter=0;
#endif

	while(!(fresh.empty()) && !reached->answer(fresh))
	  {
	    lower_bound=(*(fresh.begin()))->cardinal();
	    for( MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >::iterator fit=fresh.begin(); fit!=fresh.end(); fit++)
	      if((*fit)->cardinal() < lower_bound)
		lower_bound = (*fit)->cardinal();

#ifdef TRACE_COUNTER
	    for( MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >::iterator f2traceit=fresh.begin(); 
		 f2traceit!=fresh.end();++f2traceit)
	      //trace.add((*f2traceit)->cid, (*f2traceit)->cpid, (*f2traceit)->crid, (*f2traceit)->cpos);
	      trace.add((*f2traceit));
#endif

#ifdef ALG_DEBUG
	    cerr << "computing cardinal constant iteration[" << n_iter << "] of " << lower_bound 
		      << "cardinals on " << fresh.size() << " constraints ...";
	    time(&start);
#endif

	    fresh=next->compute(fresh, true);

#ifdef ALG_DEBUG
	    time(&end);
	    cerr << "done in " << difftime(end, start) << "s" << endl;
#endif
	    

	    cache.insert(fresh);

#ifdef ALG_DEBUG
	    n_iter++;
#ifdef SEPARATE_FILES
	    stringstream namestream;
	    namestream << "iteration-" << lower_bound << "-" << n_iter << ".slog" ;
	    myfile.open(namestream.str().c_str());
	    myfile << "................................................................." << endl;
	    myfile << "(iteration,bound)=(" << n_iter << "," << lower_bound << ")" << endl;
	    myfile << "fresh" << endl << fresh << endl;
	    myfile.close();
#else
	    //	    cout << "................................................................." << endl;
	    //cout << "(iteration, bound)=(" << n_iter << "," << lower_bound << ")" << endl;
	    //cout << "fresh" << endl << fresh << endl;
#endif
#endif

	  }

#ifdef ALG_DEBUG
	cerr << "fresh before outer after inner loop {";
	cerr << fresh.size() << "}" << endl;
#endif
	if(fresh.empty())
	  {
	    cache.next(lower_bound, fresh);

#ifdef ALG_DEBUG
	    cerr << "computing incrementation of " << lower_bound 
		      << " cardinals on " << fresh.size() << " constraints ...";
	    time(&start);
#endif

	    fresh=next->compute(fresh, false);

#ifdef ALG_DEBUG
	    time(&end);
	    cerr << "done in " << difftime(end, start) << "s" << endl;
#ifdef SEPARATE_FILES
	    stringstream namestream;
	    namestream << "incrementation-of-" << lower_bound << ".slog" ;
	    myfile.open(namestream.str().c_str());
	    myfile << "................................................................." << endl;
	    myfile << "bound=" << lower_bound << ")" << endl;
	    myfile << "fresh" << endl << fresh << endl;
	    myfile.close();
#else
	    //	    cout << "................................................................." << endl;
	    //cout << "bound=" << n_iter << lower_bound << endl;
	    //cout << "fresh" << endl << fresh << endl;
#endif
#endif

	    cache.insert(fresh);
	    
	    if(fresh.empty())
	      finished=true;

	    first_iteration=false;
	  }
	else
	  {
	    finished=true;
	  }

      } while(!finished);

#ifdef ALG_DEBUG
#ifdef SEPARATE_FILES
    myfile.open("final.slog");
    myfile << "...........................Finished.............................." << endl;
    myfile << "(iteration,bound)=(" << n_iter << "," << lower_bound << ")" << endl;
    myfile << "fresh" << endl << fresh << endl;
    myfile << "cache " << cache << endl;
    myfile.close();
#else
    cout << "...........................Finished.............................." << endl;
    cout << "(iteration, bound)=(" << n_iter << "," << lower_bound << ")" << endl;
    //    cout << "fresh " << endl << fresh << endl;
#endif
#endif

#ifdef TRACE_COUNTER
    for(  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >::iterator f2traceit=fresh.begin(); f2traceit!=fresh.end();++f2traceit)
      //trace.add((*f2traceit)->cid, (*f2traceit)->cpid, (*f2traceit)->crid, (*f2traceit)->cpos);
      trace.add((*f2traceit));
    
    if(reached->answer(fresh))
      trace.track(reached->answer_id(fresh));
#endif


    ambiguous result;
    if(!(reached->answer(fresh)))
      result=safe;
    else
      if(unique_initial_bound & first_iteration)
	result = unsafe;
      else
	result=dknow;

    return result; 
  }
 
 private:
 const MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > initial;
 const Next<EntailmentOrder<Constraint_Ref> >* next;
 Reached<EntailmentOrder<Constraint_Ref> >* reached;
};

#endif

