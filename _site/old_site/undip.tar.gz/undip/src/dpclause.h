/*
    Copyright (C) 2007 Ahmed Rezine and Noomene Ben Henda

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Ahmed Rezine <rezine.ahmed@it.uu.se> and 
    Noomene Ben Henda <noomene.benhenda@it.uu.se>
*/

/**@file dpclause.h
 * ADTs for DPClause formulas.
 * This file describes how to create and manipulate 
 * disjunctions of partitioned clauses 
 *
 *@author Ahmed Rezine
 */

#ifndef _UNDIP_DPCLAUSE_H
#define _UNDIP_DPCLAUSE_H

#include <assert.h>

#include "numb.h"
#include "clause.h"

#include <utility>
#include <list>
#include <iostream>
#include <iterator>

using namespace std;

/**
  * Class DPClause.
  * A DPClause is a disjunction of mutually exclusive Clauses.
  * A DPClause is implemented as a list of clauses of same dimension.
  */
class DPClause:private list<Clause>
{
 public:
  typedef list<Clause> container;
  typedef container::iterator iterator;
  typedef container::const_iterator const_iterator;
  iterator begin() {return container::begin();}
  const_iterator begin() const {return container::begin();}
  iterator end() {return container::end();}
  const_iterator end() const {return container::end();}

 public:
  DPClause():cardinal(0){}
  
 DPClause(const Clause& clause);

 bool is_empty() const;

 DPClause operator-(const Clause& other) const;

 DPClause operator-(const DPClause& other) const;

 bool merge(const Clause& clause);

 DPClause operator|(const DPClause& other) const;

 static DPClause difference(const Clause& one, const Clause& two);

 friend ostream& operator<< (ostream& out, const DPClause& _dpc);
 
 private:
 // number of variables
 int cardinal;
};


inline ostream& operator<< (ostream& out, const DPClause& _dpc)
{
  out << "disj. part. clauses : ";
  if(_dpc.is_empty())
    out << "empty !" << endl;
  else
    {
      out << "{" << endl;
      for(DPClause::const_iterator it=_dpc.begin(); it!=_dpc.end(); ++it)
	{
	  out << *it;
	}
      out << "}" << endl;
    }

  return out;
}


#endif
