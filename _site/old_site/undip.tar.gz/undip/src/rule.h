/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file rule.h
 * Header for rule
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_RULE_H
#define _UNDIP_RULE_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>

#include "ref.h"
#include "minset.h"
#include "constraint.h"
#include "order.h"
#include "cache.h" 

typedef enum {L, R, LR} Quantifier_Domain;

class Rule;

typedef Ref<Rule> Rule_Ref;

class Rule
{

  public:
 
  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > compute(const Constraint_Ref& cstr, bool same) const;

  virtual MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > fire_position(const Constraint_Ref&, int, bool same) const = 0;
  
  friend std::ostream& operator<< (std::ostream& out, const Rule& rule);

  virtual ~Rule(){}

  unsigned rid;
  static unsigned rcounter;

 protected:
  virtual void printOn(std::ostream& o) const = 0;
};

inline std::ostream& operator<< (std::ostream& o, const Rule& rule)
{
  rule.printOn(o);
  return o;
}

#endif
