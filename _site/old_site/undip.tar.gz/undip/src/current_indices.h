/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file current_indices.h
 * Header for entailment candidates 
 * This class gets two constraints C1,C2
 * and gives iteratively injections
 * verifying that C1 processes imply
 * their image in C2 as if there were neither 
 * channels nor relations between the processes
 * @author Rezine Ahmed
 */

#ifndef DBS_CURRENT_INDICES_H
#define DBS_CURRENT_INDICES_H

#include <iostream>
#include <assert.h>
#include <vector>


//#define DEBUG_IMAGE


class current_indices
{
 public:
  current_indices(int _n, int _m): n(_n), m(_m), finished(_m<_n), low(n), up(n), current(n) 
    {
      for(int i=1; i<=n;i++){
	low[i-1]=i;      
	up[i-1]=m-(n-i);
      }
      current=low;
    }

    bool next()
    {//increasing next
      while(pnext())
	if(injection())
	  return true;
      
      finished=true;  
      return false;
    }

    int image(int i) const 
    {
      assert(1<=i & i<=n);
#ifdef DEBUG_IMAGE
      //      std::cout << "image of " << i << " is " << *scurrent[i-1] << std::endl;
#endif
      return current[i-1];
    }

    bool empty() const 
    {
      return finished;
    }


    friend std::ostream& operator<< (std::ostream& out, 
				     const current_indices& ci);

 private:
    bool pnext()
    {//polynomial next
      if(finished)
	return false;
      
      for(int i=0; i<n; i++)
	{
	  if(current[i]<up[i])
	    {
	      current[i]++;
	      return true;	  
	    }
	  else
	    current[i]=low[i];
	}
      finished=true;
      return false;
    }
    
    bool injection()const{
      if(n<=1)
	return true;
      for(int i=1; i<n; i++)
	if(current[i]<=current[i-1])
	  return false;
      return true;
    }
    
 private:
    int n, m;
    bool finished;
    std::vector<int> low, up, current;
};


inline std::ostream& operator<< (std::ostream& out, 
				 const current_indices& ci)
{
  out << std::endl << "current {";
  for(std::vector<int>::const_iterator sit=ci.current.begin(); sit!=ci.current.end();sit++)
    out << *sit << " " ;
  out << "}" << std::endl;

  return out;
}

#endif
