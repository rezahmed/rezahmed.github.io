/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file federation.cc 
 * implementation of a federation 
 * as union of dbms, i.e union of
 * conjunction.
 * @author Rezine Ahmed
 */

#include "federation.h"

//#define DEBUG_EXTEND
//#define DEBUG_INTERSECT
//#define DEBUG_OPERATOR_OR
//#define DEBUG_PROJECT_AWAY
//#define DEBUG_OPERATOR_MINUS_DBM
//#define DEBUG_OPERATOR_MINUS
//#define DEBUG_DIFFERENCE

Federation Federation::extend(int k) const
{
  if(empty())
    {
#ifdef DEBUG_EXTEND
      cout << "dbm_extend % empty, so for k=" << k << " output is " <<  Federation(Dbm(k)) << endl;
#endif
      return Federation(Dbm(k));
    }

  Federation result;

#ifdef DEBUG_EXTEND
  cout << "dbm_extend % input " << k << ",  " << *this << endl;
#endif
  for(const_iterator it=begin(); it!= end(); ++it)
    {
      result.push_back(it->extend(k));
    }

#ifdef DEBUG_EXTEND
  cout << "dbm_extend % output " <<  result << endl;
#endif
  return result;
}

Federation Federation::operator&(const Federation& other) const
{
#ifdef DEBUG_INTERSECT
  cout << "federation this & other % input this " << *this << endl;
  cout << "federation this & other % input other " << other << endl;
#endif

  if(is_empty() | other.is_empty())
    {
#ifdef DEBUG_INTERSECT
      cout << "federation this & other % empty input " << endl;
#endif
      return Federation();
    }

  Federation result;
  
  for(const_iterator it=begin(); it!= end(); ++it)
    for(const_iterator oit=other.begin(); oit!= other.end(); ++oit)
      {
	Dbm conj = (*it) & (*oit);
	if(!conj.is_empty())
	  result.push_back(conj); 
      } 
  
#ifdef DEBUG_INTERSECT
  cout << "federation this & other % output " <<  result << endl;
#endif
  return result;
}


Federation Federation::operator|(const Federation& other) const
{
#ifdef DEBUG_OPERATOR_OR
  cout << "federation this | other % input this " << *this << endl;
  cout << "federation this | other % input other " << other << endl;
#endif
  if(is_empty())
    {
#ifdef DEBUG_OPERATOR_OR
      cout << "federation this | other % output " <<  other << endl;
#endif     
      return other;
    }
  
  if(other.is_empty())
    {
#ifdef DEBUG_OPERATOR_OR
      cout << "federation this | other % output " <<  *this << endl;
#endif     
      return *this;
    }

  Federation result = (*this) - other;
  
  result.insert(result.end(), other.begin(), other.end());


#ifdef DEBUG_OPERATOR_OR
  cout << "federation this | other % output " <<  result << endl;
#endif
  
  return result;
}


Federation Federation::project_away(int from, int to) const 
{
  
  Federation result;
  
#ifdef DEBUG_PROJECT_AWAY
  cout << "federation::dbm_project_away % input" << *this << endl;      
#endif

  for(const_iterator it=begin(); it!=end(); ++it)
    {

#ifdef DEBUG_PROJECT_AWAY
      cout << "federation::project-away % input element" << *it << endl;
#endif

      Dbm tmp=it->project_away(from, to);

#ifdef DEBUG_PROJECT_AWAY
      cout << "federation::project-away % projected element" << tmp << endl;
#endif
      result.merge(tmp);
    }

#ifdef DEBUG_PROJECT_AWAY
  cout << "federation::project_away % output" << result << endl;
#endif

  return result;
}


Federation Federation::operator-(const Dbm& other) const
{
#ifdef DEBUG_OPERATOR_MINUS_DBM
  cout << "Federation - Dbm % input this" << *this << endl;
  cout << "Federation - Dbm % input other" << other << endl;
#endif

  if(is_empty() | other.is_empty())
    {
#ifdef DEBUG_OPERATOR_MINUS_DBM
      cout << "Federation - Dbm % output " << result << endl;
#endif
      return *this;
    }
  
  Federation result;
  
  for(const_iterator it=begin(); it!=end(); ++it)
    {
      Federation fragmented_it=difference(*it, other);
      result.insert(result.end(), fragmented_it.begin(), fragmented_it.end()); //assuming disjoint inputs
    }
  
#ifdef DEBUG_OPERATOR_MINUS_DBM
  cout << "Federation - Dbm % output " << result << endl;
#endif
  return result;
}


Federation Federation::operator-(const Federation& other) const 
{
  
#ifdef DEBUG_OPERATOR_MINNUS
  cout << "federation - % input t:" << *this  << endl;
  cout << "federation - % input o:" << other << endl;
#endif

  Federation result(*this);

  if(is_empty() | other.is_empty())
    {
#ifdef DEBUG_OPERATOR_MINNUS
      cout << "federation::reomve_from % output "<< result << endl;
#endif
      return result;
    }

  for(const_iterator oit=other.begin(); oit!=other.end(); ++oit)
    result = result - (*oit);

#ifdef DEBUG_OPERATOR_MINNUS
  cout << "federation::reomve_from % output " << result << endl;
#endif

   return result;
}


bool Federation::merge(const Dbm& other)
{
  if(other.is_empty())
    return false;

  Federation fragmented = other;

  for(const_iterator it=begin(); it!=end(); ++it)
    fragmented = fragmented - (*it);

  if(fragmented.is_empty())
    return false;

  insert(end(), fragmented.begin(), fragmented.end());

  return true;    
}


Federation Federation::difference(const Dbm& d, const Dbm& e)
{

#ifdef DEBUG_DIFFERENCE
  cout << "federation::difference % input d - e " << endl;
  cout << "federation::difference % input d "<< d << endl;
  cout << "federation::difference % input e "<< e << endl;
#endif

  if(d.is_empty())
    {
#ifdef DEBUG_DIFFERENCE
      cout << "federation::difference % output d empty. return empty " << endl;
#endif
      return Federation();
    }

  if(e.is_empty())
    {
#ifdef DEBUG_DIFFERENCE
      cout << "federation::difference % output e empty. return d " << Federation(d) <<endl;
#endif
      return Federation(d);
    }

  assert(d.vars_card()==e.vars_card());


  // dij <= neg eji for some i,j
  for(int i=0; i <= d.vars_card(); ++i)
    for(int j=i+1; j <= e.vars_card(); ++j)
      if(d.get(i,j) + e.get(j,i) <= numb(-1) | d.get(j,i) + e.get(i,j) <= numb(-1))
	{
	  Federation result(d);

#ifdef DEBUG_DIFFERENCE
	  cout << "federation::difference % output: " << result << endl;
#endif
	  return result;
	}


  Federation result;
	
  Dbm r(d);

  while(!r.is_empty())
    {
      pair<int, int> min=Federation::min(e,r);
      numb efs=e.get(min.first, min.second);
      numb rfs=r.get(min.first, min.second);

      if(rfs + e.get(min.second, min.first) <= numb(-1))
	{
	  result.push_back(r);

#ifdef DEBUG_DIFFERENCE
	  cout << "federation::difference % output: " << result << endl;
#endif
	  return result;
	}
      else
	if(rfs <= efs)
	  break;
      
	else
	  {//eij is not oo, otherwise it would have been caught by previous if.
	    Dbm rn(r);
	    //S= S \or r\and not eij
	    if(  numb(-efs.value-1) <= r.get(min.second, min.first) )
	      {
		rn.modify(min.second, min.first,-efs.value-1);
	      }
	    if(!rn.is_empty())
	      result.push_back(rn);
	  }
      if(!efs.inf & efs<=rfs)
	{
	  r.modify(min.first,min.second,numb(efs.value));
	}
    }

#ifdef DEBUG_DIFFERENCE
  cout << "federation::difference % output h:" << result << endl;
#endif
  
  return result;
}


//min eij - rij
//
pair<int, int> Federation::min(const Dbm& e, const Dbm& r)
{
  assert(e.vars_card()==r.vars_card() & r.vars_card()!=0);

  bool begun=false;
  int t=0;
  pair<int, int> last(0,1);

  for(int i=0; i <= e.vars_card(); ++i)
    for(int j=0; j<= e.vars_card(); ++j)
      if(i!=j)
	{
	  if(r.get(i,j).inf & !e.get(i,j).inf) {
	    last.first=i; last.second=j;   return last;
	  }
	  else
	    if(!(r.get(i,j).inf) & !(e.get(i,j).inf)) 
	      {
		if(!begun | (e.get(i,j).value - r.get(i,j).value <= t)){
		  begun=true;
		  t=e.get(i,j).value - r.get(i,j).value;
		  last.first=i;	  last.second=j;
		}
	      }  
	}
  
  return last;
}
