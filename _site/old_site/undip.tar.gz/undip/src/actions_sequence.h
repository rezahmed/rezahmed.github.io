/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file actions_sequence.h
 * trivial implementation of a sequence of actions 
 *
 * @author Rezine Ahmed
 */

#ifndef DBS_ACTIONS_SEQUENCE_H
#define DBS_ACTIONS_SEQUENCE_H


#include <vector>
#include <iostream>

#include "action.h"

using namespace std;

class Actions_Sequence: private vector<Action>
{
  typedef vector<Action> Container;

 public:
  typedef Actions_Sequence::const_iterator const_iterator;
  typedef Actions_Sequence::iterator iterator;


 public:
  Actions_Sequence(){}

  Actions_Sequence(const Action _action){push_back(_action);}

  void add(const Action _action){push_back(_action);}
  void add(const Actions_Sequence other){insert(end(), other.begin(), other.end()); }

  int size(){return Container::size();}
  bool empty() const {return Container::empty();}
  iterator begin() {return Container::begin(); }
  const_iterator begin() const {return Container::begin();}
  iterator end() {return Container::end();}
  const_iterator end() const {return Container::end();}



  friend ostream& operator<< (ostream& out, 
				   const Actions_Sequence& actions_sequence);
};


inline ostream& operator<< (ostream& out, 
				 const Actions_Sequence& actions_sequence)
{
  Actions_Sequence::const_iterator it=actions_sequence.begin();

  out << endl
      << "**** Actions Sequence *****" 
      << endl;
  for(; it!=actions_sequence.end(); it++)
    out << *it;
  out << "***************************" 
      << endl;

  return out ;
}



#endif
