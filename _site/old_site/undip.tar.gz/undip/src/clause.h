/*
    Copyright (C) 2007 Ahmed Rezine and Noomene Ben Henda

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Ahmed Rezine <rezine.ahmed@it.uu.se> and 
    Noomene Ben Henda <noomene.benhenda@it.uu.se>
*/

/**@file clause.h
 * ADTs for clause formulas.
 * This file describes how to create and manipulate clause formulas
 *
 *@author Noomene Ben-Henda
 *@author Ahmed Rezine
 */

#ifndef _UNDIP_CLAUSE_H
#define _UNDIP_CLAUSE_H



#include <assert.h>

#include "numb.h"

#include <vector>
#include <utility>
#include <iostream>
#include <iterator>

//#define DEBUG_INSERT_CONJUNCT
//#define DEBUG_INCLUDED

//#define DEBUG_TIGHTEN

using namespace std;

  
/**
  * Class Clause.
  * A Clause is a conjuction of hyperplanes.
  * A Clause is implemented as a vector of pairs in 
  * "N U {oo}". One pair (mlb,ub), meaning "-mlb <= x <= ub", 
  * for each dimension "x"
  */
class Clause:private vector<pair<numb, numb> >
{
 public:
  typedef vector<pair<numb, numb> > container;
  typedef container::iterator iterator;
  typedef container::const_iterator const_iterator;
  iterator begin() {return container::begin();}
  const_iterator begin() const {return container::begin();}
  iterator end() {return container::end();}
  const_iterator end() const {return container::end();}
  
 public:
  
 Clause(){}
  
 Clause(int s){
   //assert(s>=0);
   insert(container::end(), s, pair<numb,numb>(numb(),numb()));
 }
  
 bool insert_conjunct(numb mlb, numb ub)
 {
   if(mlb+ub<=numb(-1))
     return false;
   push_back(pair<numb,numb>(mlb,ub));
   return true;
 }

 bool insert_conjunct(int index, numb mlb, numb ub)
 {
#ifdef DEBUG_INSERT_CONJUNCT
   cout << "clause insert conjunct % input current :"<< *this;
   cout << "clause insert conjunct % input (index,mlb,ub)=("<<index<<","<<mlb<<","<<ub<<")" << endl;
#endif

   //assert(1<=index & index<=size()+1);
   
   if(mlb+ub<=numb(-1))
     return false;
   
   iterator cit=begin();
   advance(cit, index-1);
   container::insert(cit, pair<numb,numb>(mlb, ub));

#ifdef DEBUG_INSERT_CONJUNCT
   cout << "clause insert conjunct % output current :"<< *this << endl;
#endif
   
   return true;
 }
  

 bool tighten(int index, numb mlb, numb ub)
  {
#ifdef DEBUG_TIGHTEN
    cout << "clause tighten % input : (index, mlb, ub)=(" << index << "," << mlb << "," << ub << ")" << endl;
    cout << "clause tighten % current input : " << *this  << endl;
#endif

    if(empty())
      {
#ifdef DEBUG_TIGHTEN
	cout << "clause tighten % empty current " << endl;
#endif
	return false;
      }
    
    if(mlb+ub <= numb(-1))
      {
#ifdef DEBUG_TIGHTEN
	cout << "clause tighten % empty cintersection onjunct " << endl;
#endif
	clear();
	return false;
      }
    
    //assert(1<=index & index<=size());
    operator[](index-1).first =(mlb <= operator[](index-1).first  ? mlb : operator[](index-1).first);
    operator[](index-1).second=(ub  <= operator[](index-1).second ? ub  : operator[](index-1).second);

    if(operator[](index-1).first+operator[](index-1).second<=numb(-1))
      {
#ifdef DEBUG_TIGHTEN
	cout << "clause tighten % empty intersection " << endl;
#endif
	clear();
	return false;
      }


#ifdef DEBUG_TIGHTEN
    cout << "clause tighten % output " << *this << endl;
#endif

    return true;  
  }
  
  void relax(int index, numb mlb, numb ub)
  {
    //assert(1<=index & index<=size());

    operator[](index-1).first =(mlb <= operator[](index-1).first  ? operator[](index-1).first  : mlb);
    operator[](index-1).second=(ub  <= operator[](index-1).second ? operator[](index-1).second : ub );
  }
  
  
  void modify(int index, numb mlb, numb ub){
    //assert(!(mlb+ub <= numb(-1)));
    //assert(1<=index & index<=size());

    operator[](index-1).first=mlb;
    operator[](index-1).second=ub;
  }
  

  numb gnlb(int index) const { 
    //assert(1<=index & index<=size());
    return operator[](index-1).first;
  }

  numb gub(int index) const { 
    //assert(1<=index & index<=size());
    return operator[](index-1).second;
  }

  
  Clause project_away(int from, int to) const
  {
    //assert(1<=from & from<=size() & 1<=to & to<=size() & from<=to);
    
    Clause result(*this);
    iterator from_it=result.begin(), to_it=result.end();
    advance(from_it, from-1);
    advance(to_it, to-1);
    result.erase(from_it, to_it);
    return result;
  }
  
  
  Clause operator &(const Clause& other) const{
    if(empty() | other.empty())
      return Clause();
    
    //assert(size()==other.size());
    Clause result(*this);
    for(int i=1; i<=size(); ++i)
      {
	if(!result.tighten(i, other[i-1].first, other[i-1].second))
	  return Clause();
      }
    return result;
  }
  
 
  int vars_card() const { 
    return size();
  }
  
  bool is_empty() const {
    return empty();
  }
  
  bool addmissible(int index, numb value) const
  {
    //assert(1<=index & index<=size());
    
    if(numb(0)<=operator[](index-1).first+value  & value<=operator[](index-1).second)
      return true;
    
    return false;
  }
  
  bool included_variable_in(int at, const Clause& other, int oat) const
  {
    //assert(1<=at & at<=size());
    //assert(1<=oat & oat<=size());

#ifdef DEBUG_INCLUDED
    cout << "clause included % input : this_var in? other_var : [" << operator[](at-1).first << "," << operator[](at-1).second 
	 <<"] in? [" << other[oat-1].first << "," << other[oat-1].second << "]" << endl;

    cout << "clause included % output : " << (( operator[](at-1).first <= other[oat-1].first ) 
					      & ( operator[](at-1).second <= other[oat-1].second ) ? "yes" : "no")  << endl;
#endif

    return ( operator[](at-1).first <= other[oat-1].first ) 
      & ( operator[](at-1).second <= other[oat-1].second );
  }
  
  
  friend ostream& operator<< (ostream& out, const Clause& _a);
  
 };


inline ostream& operator<< (ostream& out, const Clause& _a)
{
  out << "clause:{";
    
  for(int i=1; i<=_a.vars_card(); ++i)
    out << "x" << i << ":[" << _a[i-1].first << "," << _a[i-1].second << "], ";  
  
  out << "}" << endl;
  
  return out;
}


#endif
