/*
    Copyright (C) 2007 Ahmed Rezine and Noomene Ben Henda

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Ahmed Rezine <rezine.ahmed@it.uu.se> and 
    Noomene Ben Henda <noomene.benhenda@it.uu.se>
*/

/**@file dpclause.cc
 * implementation of DPClause
 *
 *@author Ahmed Rezine
 */

#include "dpclause.h"


//#define DEBUG_MERGE  
//#define DEBUG_OPERATOR_MINUS
//#define DEBUG_OPERATOR_MINUS_CLAUSE
//#define DEBUG_DIFFERENCE

DPClause::DPClause(const Clause& clause)
{
  if(!clause.is_empty())
    {
      cardinal=clause.vars_card();
      push_back(clause);
    }
}

bool DPClause::is_empty() const
{
  return empty();
}


bool DPClause::merge(const Clause& clause)
{

#ifdef DEBUG_MERGE
  cout << "DPClause add disjunct % input this" << *this << endl;
  cout << "DPClause add disjunct % input clause" << clause << endl;
#endif
  
  if(clause.is_empty()){
#ifdef DEBUG_MERGE
    cout << "DPClause add disjunct % empty clause" << endl;
#endif
    return false;
  }

  if(is_empty()){
    cardinal=clause.vars_card();
    push_back(clause);
#ifdef DEBUG_MERGE
    cout << "DPClause add disjunct % empty DPCLause, output :" << *this << endl;
#endif
    return true;
  }

  //assert(cardinal==clause.vars_card());
  
  DPClause fragmented=DPClause(clause)-(*this);
  
  if(fragmented.is_empty())
    {
#ifdef DEBUG_MERGE
      cout << "DPClause add disjunct % clause included in DPClause " << endl;
#endif
      return false;
    }

  insert(end(), fragmented.begin(), fragmented.end());
  
#ifdef DEBUG_MERGE
  cout << "DPClause add disjunct % output with addition " << *this << endl;
#endif

  return true;
}


DPClause DPClause::operator-(const DPClause& other) const
{
#ifdef DEBUG_OPERATOR_MINUS
  cout << "DPClause - DPClause % input this" << *this << endl;
  cout << "DPClause - DPClause % input other" << other << endl;
#endif
  
  DPClause result(*this);
    
  if(is_empty() | other.is_empty())
    return result;
  
  for(const_iterator oit=other.begin(); oit!=other.end(); ++oit)
    result = result - (*oit);
  
#ifdef DEBUG_OPERATOR_MINUS
  cout << "DPClause - DPClause % output " << result << endl;
#endif
  return result;
}


DPClause DPClause::operator-(const Clause& other) const
{
#ifdef DEBUG_OPERATOR_MINUS_CLAUSE
  cout << "DPClause - Clause % input this" << *this << endl;
  cout << "DPClause - Clause % input other" << other << endl;
#endif
  
  if(is_empty() | other.is_empty())
    return *this;
  
  DPClause result;
  
  for(const_iterator it=begin(); it!=end(); ++it)
    {
      DPClause fragmented_it=difference(*it, other);
      result.insert(result.end(), fragmented_it.begin(), fragmented_it.end()); //assuming disjoint inputs
    }
  
#ifdef DEBUG_OPERATOR_MINUS_CLAUSE
  cout << "DPClause - Clause % output " << result << endl;
#endif
  return result;
}


DPClause DPClause::difference(const Clause& one, const Clause& two)
{

#ifdef DEBUG_DIFFERENCE
  cout << "difference one - two % input one : " << one ;
  cout << "difference one - two % input two : " << two ;
#endif

  if(one.is_empty() | two.is_empty())
    return DPClause();
  
  //assert(one.vars_card()==two.vars_card());

  DPClause result;
  
  for(int i=1; i<=one.vars_card(); ++i){
    if(two.gnlb(i)+numb(1) <= one.gnlb(i)){
      Clause candidate(one);
      candidate.tighten(i, one.gnlb(i), numb(-1)-two.gnlb(i));
      result.push_back(candidate);
    }
    
    if(two.gub(i)+numb(1) <= one.gub(i)){
      Clause candidate(one);
      candidate.tighten(i, numb(-1)-two.gub(i), one.gub(i));
      result.push_back(candidate);
    }
  }

#ifdef DEBUG_DIFFERENCE
  cout << "difference one - two % output : " << result ;
#endif
  
  return result;
}

DPClause DPClause::operator|(const DPClause& other) const
{
#ifdef DEBUG_OPERATOR_OR
  cout << "DPClause | DPClause % input this" << *this << endl;
  cout << "DPClause | DPClause % input other" << other << endl;
#endif
  
  DPClause result = other - (*this);

  result.insert(result.begin(), begin(), end());    
  
#ifdef DEBUG_OPERATOR_OR
  cout << "DPClause | DPClause % output " << result << endl;
#endif
  return result;
}
