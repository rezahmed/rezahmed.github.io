/*
  Copyright (C) 2007 Rezine Ahmed

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.file>  
*/

/** @se transient_broadcast_g.cc
 * implementation of a BDC
 *
 * @author Rezine Ahmed
 */

#include "bdc.h"
#include <iterator>

//#define DEBUG_BDC_CONSTRUCT
//#define DEBUG_FIRE_BDC
//#define DEBUG_CONSTRAINT_TO_WORKING
//#define DEBUG_APPLY_BACTION
//#define DEBUG_APPLY_UACTION
//#define DEBUG_CHECK_SATISFIABLE
//#define DEBUG_COMBINATION_VALIDITY


BDC::BDC(const Actions_Sequence& _initiator, 
	 const vector<Actions_Sequence>& _left, 
	 const vector<Actions_Sequence>& _left_right, 
	 const vector<Actions_Sequence>& _right):
  pure_left(_left_right.size()+_right.size()==0), 
  pure_right(_left.size()+_left_right.size()==0)
{ 
  //assert(!(pure_left & pure_right));

  rid=++rcounter;

  for(Actions_Sequence::const_iterator init_it=_initiator.begin(); 
      init_it!=_initiator.end(); ++init_it)
    {//separate the initiator into bounded/unbounded

      int i=init_it->get_cipher().first(), j=init_it->get_cipher().second();

      if(init_it->get_cipher().is_bounded()) 
	binitiator.add(*init_it);
      else 
	uinitiator.add(*init_it);
    }

  
  for(vector<Actions_Sequence>::const_iterator vit=_left.begin();
      vit!=_left.end(); ++vit)
    {//separate left into bounded/unbounded

      Actions_Sequence bseq,useq;

      for(Actions_Sequence::const_iterator s_it=vit->begin(); 
	  s_it!=vit->end(); ++s_it)
	{
	  int i=s_it->get_cipher().first(), j=s_it->get_cipher().second();
	  if(s_it->get_cipher().is_bounded()) bseq.add(*s_it);
	  else useq.add(*s_it);
	}
      left.push_back(pair<Actions_Sequence, Actions_Sequence> (bseq,useq));
    }

  for(vector<Actions_Sequence>::const_iterator vit=_left_right.begin();
      vit!=_left_right.end(); ++vit)
    {//separate left_right into bounded/unbounded

      Actions_Sequence bseq,useq;

      for(Actions_Sequence::const_iterator s_it=vit->begin(); 
	  s_it!=vit->end(); ++s_it)
	{
	  int i=s_it->get_cipher().first(), j=s_it->get_cipher().second();
	  if(s_it->get_cipher().is_bounded()) bseq.add(*s_it);
	  else useq.add(*s_it);
	}
      left_right.push_back(pair<Actions_Sequence, Actions_Sequence> (bseq,useq));
    }

  for(vector<Actions_Sequence>::const_iterator vit=_right.begin();
      vit!=_right.end(); ++vit)
    {//separate right into bounded/unbounded

      Actions_Sequence bseq,useq;

      for(Actions_Sequence::const_iterator s_it=vit->begin(); 
	  s_it!=vit->end(); ++s_it)
	{
	  int i=s_it->get_cipher().first(), j=s_it->get_cipher().second();
	  if(s_it->get_cipher().is_bounded()) bseq.add(*s_it);
	  else useq.add(*s_it);
	}
      right.push_back(pair<Actions_Sequence, Actions_Sequence> (bseq,useq));
    }

#ifdef DEBUG_BDC_CONSTRUCT
  cout << "BDC CONSTRUCTOR %  rule id: " << rid << endl;
  cout << "BDC CONSTRUCTOR %  rules in bounded initiator  : " 
       << endl << binitiator;
  cout << "BDC CONSTRUCTOR %  rules in unbounded initiator: " 
       << endl << uinitiator;

  cout << endl;

  cout << "BDC CONSTRUCTOR %  number of left choices: " << left.size() << endl;
  for(unsigned i=0; i<left.size();i++)
    {
      cout << "BDC CONSTRUCTOR % bounded left rules  ("<< i <<") " 
	   << endl << left[i].first;
      cout << "BDC CONSTRUCTOR % unbounded left rule ("<< i <<") " 
	   << endl << left[i].second;
    }
  
  cout << endl;

  cout << "BDC CONSTRUCTOR %  number of left_right choices: " << left_right.size() 
       << endl;
  for(unsigned i=0; i<left_right.size();i++)
    {
      cout << "BDC CONSTRUCTOR % bounded left_right rules  ("<< i <<") " 
	   << endl << left_right[i].first;
      cout << "BDC CONSTRUCTOR % unbounded left_right rule ("<< i <<") " 
	   << endl << left_right[i].second;
    }
  cout << endl;

  cout << "BDC CONSTRUCTOR %  number of right choices: " << right.size() 
       << endl;
  for(unsigned i=0; i<right.size();i++)
    {
      cout << "BDC CONSTRUCTOR % bounded right rules  ("<< i <<") " 
	   << endl << right[i].first;
      cout << "BDC CONSTRUCTOR % unbounded right rule ("<< i <<") " 
	   << endl << right[i].second;
    }
  cout << endl;
#endif

  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc;

  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc;


  // The following computations aim at building (b/u)(initiator/choice/left/left_right/right)_modified, and 
  // (b/u)initiator, (left/left_right/right)_guard.(b/u).
  

  // Find in initiator's actions the set of bounded variables to be modified,
  for(Actions_Sequence::const_iterator it=binitiator.begin(); it!=binitiator.end(); ++it){
    //assert(!it->get_dbm().is_empty());
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    //assert((i!=j) & (i==0 | j==0));
    int index=(i==0? j: i);
    // The initiator rules for bounded variables involve only shared variables or variables belonging to the firing process.
    //assert((0<index & index<=bs) | (bs<index & index<=bs+bp) | (bsegment<index & index<=bsegment+bs) 
    //   | (bsegment+bs<index & index<=bsegment+bs+bp));
    int image_base = index - bsegment;
    if(0 < image_base) binitiator_modified.insert(image_base);
  }

  // Find in initiator's actions the set of unbounded variables to be modified,
  for(Actions_Sequence::const_iterator it=uinitiator.begin(); it!=uinitiator.end(); ++it){
    //assert(!it->get_dbm().is_empty());
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    // The initiator rules for unbounded variables involve only constants, shared variables, or variables belonging to the firing process.
    //assert(0==i | (0<i & i<=us) | (us<i & i<=us+up) | (usegment<i & i<=usegment+us) | (usegment+us<i & i<=usegment+us+up));
    //assert(0==j | (0<j & j<=us) | (us<j & j<=us+up) | (usegment<j & j<=usegment+us) | (usegment+us<j & j<=usegment+us+up));
    int image_base = i - usegment;
    if(0 < image_base)
      uinitiator_modified.insert(image_base);
    image_base = j - usegment;
    if(0 < image_base)
      uinitiator_modified.insert(image_base);
  }

  //Find in the actions of each left choice, the corresponding set of bounded/unbounded variables to be modified. 
  for(vector<pair<Actions_Sequence, Actions_Sequence> >::const_iterator vit=left.begin(); vit!=left.end(); vit++){
    set<int> bmodified, umodified;
    //first, the bounded sequence
    for(Actions_Sequence::const_iterator it=vit->first.begin(); it!=vit->first.end(); ++it){
      //assert(!it->get_dbm().is_empty());
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      //assert(i==0 | j==0);
      //assert(i!=j & i<=2*bsegment & j<=2*bsegment);
      int index=(i==0? j: i);
      int image_base = index - bsegment;
      if(0 < image_base){
	bmodified.insert(image_base);
	bchoice_modified.insert(image_base);
      }
    }
    //second, the unbounded sequencea
    for(Actions_Sequence::const_iterator it=vit->second.begin(); it!=vit->second.end(); ++it){
      //assert(!it->get_dbm().is_empty());
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      //assert(i<=2*usegment & j<=2*usegment);
      int image_base = i - usegment;
      if(0 < image_base){
	umodified.insert(image_base);
	uchoice_modified.insert(image_base);
      }
      image_base = j - usegment;
      if(0 < image_base){
	umodified.insert(image_base);
	uchoice_modified.insert(image_base);
      }
    }
    bleft_modified.push_back(bmodified);
    uleft_modified.push_back(umodified);
  }


  //Find in the actions of each left_right choice, the corresponding set of bounded/unbounded variables to be modified. 
  for(vector<pair<Actions_Sequence, Actions_Sequence> >::const_iterator vit=left_right.begin(); vit!=left_right.end(); vit++){
    set<int> bmodified, umodified;
    //first, the bounded sequence
    for(Actions_Sequence::const_iterator it=vit->first.begin(); it!=vit->first.end(); ++it){
      //assert(!it->get_dbm().is_empty());
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      //assert(i==0 | j==0);
      //assert(i!=j & i<=2*bsegment & j<=2*bsegment);
      int index=(i==0? j: i);
      int image_base = index - bsegment;
      if(0 < image_base){
	bmodified.insert(image_base);
	bchoice_modified.insert(image_base);
      }
    }
    //second, the unbounded sequencea
    for(Actions_Sequence::const_iterator it=vit->second.begin(); it!=vit->second.end(); ++it){
      //assert(!it->get_dbm().is_empty());
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      //assert(i<=2*usegment & j<=2*usegment);
      int image_base = i - usegment;
      if(0 < image_base){
	umodified.insert(image_base);
	uchoice_modified.insert(image_base);
      }
      image_base = j - usegment;
      if(0 < image_base){
	umodified.insert(image_base);
	uchoice_modified.insert(image_base);
      }
    }
    bleft_right_modified.push_back(bmodified);
    uleft_right_modified.push_back(umodified);
  }


  //Find in the actions of each right choice, the corresponding set of bounded/unbounded variables to be modified. 
  for(vector<pair<Actions_Sequence, Actions_Sequence> >::const_iterator vit=right.begin(); vit!=right.end(); vit++){
    set<int> bmodified, umodified;
    //first, the bounded sequence
    for(Actions_Sequence::const_iterator it=vit->first.begin(); it!=vit->first.end(); ++it){
      //assert(!it->get_dbm().is_empty());
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      //assert(i==0 | j==0);
      //assert(i!=j & i<=2*bsegment & j<=2*bsegment);
      int index=(i==0? j: i);
      int image_base = index - bsegment;
      if(0 < image_base){
	bmodified.insert(image_base);
	bchoice_modified.insert(image_base);
      }
    }
    //second, the unbounded sequence
    for(Actions_Sequence::const_iterator it=vit->second.begin(); it!=vit->second.end(); ++it){
      //assert(!it->get_dbm().is_empty());
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      //assert(i<=2*usegment & j<=2*usegment);
      int image_base = i - usegment;
      if(0 < image_base){
	umodified.insert(image_base);
	uchoice_modified.insert(image_base);
      }
      image_base = j - usegment;
      if(0 < image_base){
	umodified.insert(image_base);
	uchoice_modified.insert(image_base);
      }
    }
    bright_modified.push_back(bmodified);
    uright_modified.push_back(umodified);
  }


 // Defining guards.
  // If this initiator's guard (weak, i.e. even if respected, the transition may still be disabled)
  // is not satisfied, then the whole transition is disabled (no
  // matter what choice is picked during the application).
  // Find among the initiator's actions those which only involve (i) constants, (ii) shared, firing process 
  // variables that are to be modified, or (iii) that are not to be modified in any rule in initiator, left, 
  // left_right or right; i.e. neither in initiator_modified nor in choice_modified. 

  // Start with the bounded part
  for(Actions_Sequence::const_iterator it=binitiator.begin(); it!=binitiator.end(); ++it){
    int i=it->get_cipher().first();      int j=it->get_cipher().second();
    //assert((i!=j) & (i==0 | j==0));
    int index=(i==0? j: i);
    bool result_untouched=(bsegment<index
			   |(binitiator_modified.find(index)==binitiator_modified.end() 
			     & bchoice_modified.find(index)==bchoice_modified.end()));
    if(result_untouched) 
      binitiator_guard.add(*it);
  }

  // same for the unbounded part
  for(Actions_Sequence::const_iterator it=uinitiator.begin(); it!=uinitiator.end(); ++it){
    int i=it->get_cipher().first();      int j=it->get_cipher().second();
    bool i_constant_result_untouched=(i==0 | usegment<i
				      |(uinitiator_modified.find(i)==uinitiator_modified.end() 
					& uchoice_modified.find(i)==uchoice_modified.end()));
    bool j_constant_result_untouched=(j==0 | usegment<j
				      |(uinitiator_modified.find(j)==uinitiator_modified.end() 
					& uchoice_modified.find(j)==uchoice_modified.end()));
    if(i_constant_result_untouched & j_constant_result_untouched) 
      uinitiator_guard.add(*it);
  }


  // Defining a guard for each left choice.
  // Find among the choices' actions, those which involve only (i) constants, (ii) any variables 
  // that are to be modified, or (iii) receptor (i.e. not initiator and not shared) variables that are not to be 
  // modified in any action of the choice, or (iv) initiator variables that are not to be modified in any action
  // (i.e. that are neither in initiator_modified, nor in choice_modified).
  vector<set<int> >::const_iterator bmit=bleft_modified.begin(), umit=uleft_modified.begin();
  for(vector<pair<Actions_Sequence, Actions_Sequence> >::const_iterator vit=left.begin(); vit!=left.end(); ++vit, ++bmit, ++umit)
    {
      //assert(bmit!=bleft_modified.end());
      //assert(umit!=uleft_modified.end());
      Actions_Sequence bguard, uguard;
      //start with the bounded part
      for(Actions_Sequence::const_iterator it=vit->first.begin(); it!=vit->first.end(); ++it)
	{
	  int i=it->get_cipher().first();      int j=it->get_cipher().second();
	  //assert((i!=j) & (i==0 | j==0));
	  int index=(i==0? j: i);
	  // The guard concerns actions involving only bounded variables of form (ii), (iii), or (iv) 
	  bool result_untouched=( bsegment<index | (bs+bp<index & index<=bsegment & bmit->find(index)==bmit->end())
				  | (0<index & index<=bs+bp & binitiator_modified.find(index)==binitiator_modified.end()
				     & bchoice_modified.find(index)==bchoice_modified.end()));
	  if(result_untouched) bguard.add(*it);
	}
      //then the unbounded part
      for(Actions_Sequence::const_iterator it=vit->second.begin(); it!=vit->second.end(); ++it)
	{
	  int i=it->get_cipher().first();      int j=it->get_cipher().second();
	  // The guard concerns actions involving only constantes or variables of form (ii), (iii) or (iv) 
	  bool i_constant_result_untouched=(i==0 | usegment<i | (us+up<i & i<=usegment & umit->find(i)==umit->end())
					    | (0<i & i<=us+up & uinitiator_modified.find(i)==uinitiator_modified.end()
					       & uchoice_modified.find(i)==uchoice_modified.end()));
	  bool j_constant_result_untouched=(j==0 | usegment<j | (us+up<j & j<=usegment & umit->find(j)==umit->end())
					    | (0<j & j<=us+up & uinitiator_modified.find(j)==uinitiator_modified.end()
					       & uchoice_modified.find(j)==uchoice_modified.end()));
	  if(i_constant_result_untouched & j_constant_result_untouched) 
	    uguard.add(*it);
	}
      left_guard.push_back(pair<Actions_Sequence, Actions_Sequence> (bguard, uguard));
    }

  // Same for defining a guard for each left_right choice.
  bmit=bleft_right_modified.begin(), umit=uleft_right_modified.begin();
  for(vector<pair<Actions_Sequence, Actions_Sequence> >::const_iterator vit=left_right.begin(); 
      vit!=left_right.end(); ++vit, ++bmit, ++umit)
    {
      //assert(bmit!=bleft_right_modified.end());
      //assert(umit!=uleft_right_modified.end());
      Actions_Sequence bguard, uguard;
      //start with the bounded part
      for(Actions_Sequence::const_iterator it=vit->first.begin(); it!=vit->first.end(); ++it)
	{
	  int i=it->get_cipher().first();      int j=it->get_cipher().second();
	  //assert((i!=j) & (i==0 | j==0));
	  int index=(i==0? j: i);
	  // The guard concerns actions involving only bounded variables of form (ii), (iii), or (iv) 
	  bool result_untouched=( bsegment<index | (bs+bp<index & index<=bsegment & bmit->find(index)==bmit->end())
				  | (0<index & index<=bs+bp & binitiator_modified.find(index)==binitiator_modified.end()
				     & bchoice_modified.find(index)==bchoice_modified.end()));
	  if(result_untouched) bguard.add(*it);
	}
      //then the unbounded part
      for(Actions_Sequence::const_iterator it=vit->second.begin(); it!=vit->second.end(); ++it)
	{
	  int i=it->get_cipher().first();      int j=it->get_cipher().second();
	  // The guard concerns actions involving only constantes or variables of form (ii), (iii) or (iv) 
	  bool i_constant_result_untouched=(i==0 | usegment<i | (us+up<i & i<=usegment & umit->find(i)==umit->end())
					    | (0<i & i<=us+up & uinitiator_modified.find(i)==uinitiator_modified.end()
					       & uchoice_modified.find(i)==uchoice_modified.end()));
	  bool j_constant_result_untouched=(j==0 | usegment<j | (us+up<j & j<=usegment & umit->find(j)==umit->end())
					    | (0<j & j<=us+up & uinitiator_modified.find(j)==uinitiator_modified.end()
					       & uchoice_modified.find(j)==uchoice_modified.end()));
	  if(i_constant_result_untouched & j_constant_result_untouched) 
	    uguard.add(*it);
	}
      left_right_guard.push_back(pair<Actions_Sequence, Actions_Sequence> (bguard, uguard));
    }

  // Same for defining a guard for each right choice.
  bmit=bright_modified.begin(), umit=uright_modified.begin();
  for(vector<pair<Actions_Sequence, Actions_Sequence> >::const_iterator vit=right.begin(); vit!=right.end(); ++vit, ++bmit, ++umit)
    {
      //assert(bmit!=bright_modified.end());
      //assert(umit!=uright_modified.end());
      Actions_Sequence bguard, uguard;
      //start with the bounded part
      for(Actions_Sequence::const_iterator it=vit->first.begin(); it!=vit->first.end(); ++it)
	{
	  int i=it->get_cipher().first();      int j=it->get_cipher().second();
	  //assert((i!=j) & (i==0 | j==0));
	  int index=(i==0? j: i);
	  // The guard concerns actions involving only bounded variables of form (ii), (iii), or (iv) 
	  bool result_untouched=( bsegment<index | (bs+bp<index & index<=bsegment & bmit->find(index)==bmit->end())
				  | (0<index & index<=bs+bp & binitiator_modified.find(index)==binitiator_modified.end()
				     & bchoice_modified.find(index)==bchoice_modified.end()));
	  if(result_untouched) bguard.add(*it);
	}
      //then the unbounded part
      for(Actions_Sequence::const_iterator it=vit->second.begin(); it!=vit->second.end(); ++it)
	{
	  int i=it->get_cipher().first();      int j=it->get_cipher().second();
	  // The guard concerns actions involving only constantes or variables of form (ii), (iii) or (iv) 
	  bool i_constant_result_untouched=(i==0 | usegment<i | (us+up<i & i<=usegment & umit->find(i)==umit->end())
					    | (0<i & i<=us+up & uinitiator_modified.find(i)==uinitiator_modified.end()
					       & uchoice_modified.find(i)==uchoice_modified.end()));
	  bool j_constant_result_untouched=(j==0 | usegment<j | (us+up<j & j<=usegment & umit->find(j)==umit->end())
					    | (0<j & j<=us+up & uinitiator_modified.find(j)==uinitiator_modified.end()
					       & uchoice_modified.find(j)==uchoice_modified.end()));
	  if(i_constant_result_untouched & j_constant_result_untouched) 
	    uguard.add(*it);
	}
      right_guard.push_back(pair<Actions_Sequence, Actions_Sequence> (bguard, uguard));
    }


#ifdef DEBUG_BDC_CONSTRUCT
  cout << "BDC CONSTRUCTOR %  initiator's guard for bounded variables : " 
       << endl 
       << binitiator_guard;
  cout << "BDC CONSTRUCTOR %  initiator's guard for unbounded variables : " 
       << endl 
       << uinitiator_guard;
  cout << endl;

  cout << "BDC CONSTRUCTOR %  choices on left guards : " << left_guard.size() << endl;
  for(unsigned i=0; i<left_guard.size();i++)  
    {
      cout << "BDC CONSTRUCTOR % left_guard, for bounded variables, choice ("<< i << ")" 
	   << endl << left_guard[i].first;
      cout << "BDC CONSTRUCTOR % left_guard, for bounded variables, choice ("<< i << ")" 
	   << endl << left_guard[i].second;
    }
  cout << endl;

  cout << "BDC CONSTRUCTOR %  choices on left_right guards : " << left_right_guard.size() << endl;
  for(unsigned i=0; i<left_right_guard.size();i++)  
    {
      cout << "BDC CONSTRUCTOR % left_right_guard, for bounded variables, choice ("<< i << ")" 
	   << endl << left_right_guard[i].first;
      cout << "BDC CONSTRUCTOR % left_right_guard, for bounded variables, choice ("<< i << ")" 
	   << endl << left_right_guard[i].second;
    }
  cout << endl;

  cout << "BDC CONSTRUCTOR %  choices on right guards : " << right_guard.size() << endl;
  for(unsigned i=0; i<right_guard.size();i++)  
    {
      cout << "BDC CONSTRUCTOR % right_guard, for bounded variables, choice ("<< i << ")" 
	   << endl << right_guard[i].first;
      cout << "BDC CONSTRUCTOR % right_guard, for bounded variables, choice ("<< i << ")" 
	   << endl << right_guard[i].second;
    }
  cout << endl;
#endif

}


/* Brief sends a variable from the original constraint to the working Dbm.
 * \param i: variable index in the constraint's dbm.
 * \param cs,cn: number of variables, of processes in the constraint's dbm.
 * \param at, atv: firing process, index of the first variable of the firing in 
 *     constraint's dbm.
 * \param p: polynomial given the combination of the choices to the left/right of the 
 * firing process.
 * \param modification_base: holds the information of what variable is to be modified,
 * and what variable is representing it in the working dbm.
 * \return the index of the variable in the working dbm that is to represent the 
 * variable i.
 */
int BDC::constraint_to_working(int i, int ucs, int cn, int at, int uatv, const Modification_Base& modification_base) const
{

#ifdef DEBUG_CONSTRAINT_TO_WORKING
  cout << "constraint_to_working % (i,ucs,cn,at,uatv) = (" 
       << i << "," << ucs << "," << cn << "," << at <<"," << uatv << endl;
#endif

  if(i==0) return 0;
  else
    if(i<=Constraint::us){
      if(modification_base.is_modified(at, i)) return ucs+modification_base.get(at, i);
      else return i;
    }
    else
      if(uatv<i & i<=uatv+Constraint::up+(cn-1)*Constraint::uc)
	if(i-uatv<=Constraint::up){
	  if(modification_base.is_modified(at, i-uatv+Constraint::us)) return ucs+modification_base.get(at, i-uatv+Constraint::us);
	  else return i;
	}
	else{
	  int shifted_chan=(i-uatv-Constraint::up-1)/Constraint::uc+1;
	  int chan=shifted_chan+(at<=shifted_chan? 1:0);
	  int ucar=(i-uatv-Constraint::up-1)%Constraint::uc+1;
	  if(modification_base.is_modified(chan, ucar+Constraint::us+Constraint::up)) 
	    return ucs+modification_base.get(chan, ucar+Constraint::us+Constraint::up);
	  else return i;
	}
      else return i;
}




void BDC::printOn(ostream& o) const
{
  o <<"id=" << rid << " BDC ";
#ifdef PRINT_PROCESS_CHANNEL


#else  
  

#endif


}


/* Brief apply the action on bounded variables with "at" as 
 * initiator and "c" as receptor
 */
bool BDC::apply_baction(const Action& action, 
			int at, int batv, int c, int bcatv,
			Clause& clause_pred, Clause& clause_imag) const
{
#ifdef DEBUG_APPLY_BACTION
  cout << "apply_baction % input action : " << action;
  cout << "apply_baction % input (at, batv, c, bcatv):(" << at << "," << batv << "," << c << "," << bcatv << ")" << endl; 
  cout << "apply_baction % input pred :" << clause_pred;
  cout << "apply_baction % inut imag :" << clause_imag ;
#endif

  int i=action.get_cipher().first(), j=action.get_cipher().second(); 
  //assert(i!=j & (i==0 | j==0));
  int index=(i==0? j: i);
  numb nlb=(i==0? action.get_dbm().get(0,1) : action.get_dbm().get(1,0));
  numb ub=(i==0? action.get_dbm().get(1,0) : action.get_dbm().get(0,1));
  
  bool result=true;

  if(index<=Constraint::bs){
    if(!clause_pred.tighten(index, nlb, ub)) 
      result=false;
  }
  else if(index<=Constraint::bs+Constraint::bp){
    if(!clause_pred.tighten(index-Constraint::bs+batv, nlb, ub)) 
      result=false;
  }
  else
    {
      int bsegment=Constraint::bs+Constraint::bp+Constraint::bc;
      if(index<=bsegment){ 
	//assert(c!=0); 
	if(!clause_pred.tighten(index-Constraint::bs-Constraint::bp+bcatv, nlb, ub)) 
	  result=false;
      }
      else if(index<=bsegment+Constraint::bs){
	if(!clause_imag.tighten(index-bsegment, nlb, ub)) 
	  result=false;
      }
      else if(index<=bsegment+Constraint::bs+Constraint::bp){
	if(!clause_imag.tighten(index-bsegment-Constraint::bs+batv, nlb, ub)) 
	  result=false;
      }
      else{
	//assert(c!=0); 
	if(!clause_imag.tighten(index-bsegment-Constraint::bs-Constraint::bp+bcatv, nlb, ub)) 
	  result=false;
      }
    }

#ifdef DEBUG_APPLY_BACTION
  cout << "apply_baction % output pred :" << clause_pred;
  cout << "apply_baction % output imag :" << clause_imag << endl;
#endif

  return true;
}

/* Brief apply the action on unbounded variables with "at" as 
 * initiator and "c" as receptor
 */
bool BDC::apply_uaction(const Action& action, 
			int at, int uatv, int c, int ucatv, int ucs,
			const Modification_Base& modification_base, 
			Dbm& working_dbm) const
{
  int i=action.get_cipher().first(), j=action.get_cipher().second(), wi=0, wj=0;

  if(i<=Constraint::us) 
    wi=i; 
  else if(i<=Constraint::us+Constraint::up) 
    wi=uatv+i-Constraint::us; 
  else
    {
      int usegment=Constraint::us+Constraint::up+Constraint::uc;
      if(i<=usegment){
	//assert(c!=0); 
	wi=ucatv+i-Constraint::us-Constraint::up;
      }
      else if(i-usegment<=Constraint::us+Constraint::up) 
	wi=ucs+(modification_base.get(at, i-usegment)); 
      else{
	//assert(c!=0); 
	wi=ucs+(modification_base.get(c, i-usegment));
      }
    }

  if(j<=Constraint::us) 
    wj=j; 
  else if(j<=Constraint::us+Constraint::up) 
    wj=uatv+j-Constraint::us; 
  else
    {
      int usegment=Constraint::us+Constraint::up+Constraint::uc;
      if(j<=usegment){
	//assert(c!=0); 
	wj=ucatv+j-Constraint::us-Constraint::up;
      }
      else if(j-usegment<=Constraint::us+Constraint::up) 
	wj=ucs+(modification_base.get(at, j-usegment)); 
      else{
	//assert(c!=0); 
	wj=ucs+(modification_base.get(c, j-usegment));
      }
    }
  
  if(!working_dbm.tighten(wi,wj,action.get_dbm().get(0,1)) 
     | !working_dbm.tighten(wj,wi,action.get_dbm().get(1,0)))
    return false;
  
  return true;
}



MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > BDC::fire_position(const Constraint_Ref& cstr, int at, bool same) const
{
  //assert(cstr);
  
#ifdef DEBUG_FIRE_BDC
  cout << endl 
       << "fire_BDC% rule id: " << rid << endl
       << "fire_BDC% input at: " << at << endl 
       << "fire_BDC% input c: " << *cstr << endl;
#endif


  //resulting min set
  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > result_min_set;

  if(!same | !cstr->is_sender_or_one_of_channels_old(at))
    {
#ifdef DEBUG_FIRE_BDC
      cout << "fire_BDC% output : initiator and concerned receptors are idle ! "<< endl ;
#endif
      return result_min_set;
    }

  
  int cn=cstr->cardinal(); //number of processes in cstr

  int bcs=cstr->clause.vars_card(); //constraint clause variables
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc;
  int batv=bs+(at-1)*(bp+(cn-1)*bc);//begining of process "at"'s variables   

  int ucs=cstr->dbm.vars_card(); //constraint dbm variables
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc;
  int uatv=us+(at-1)*(up+(cn-1)*uc);//begining of process "at"'s variables   

  if(cstr->is_empty() | !check_satisfiable(batv, uatv, cstr))
    {
#ifdef DEBUG_FIRE_BDC
      cout << "fire_BDC% output : empty input c or rule not enabled ! "<< endl ;
#endif
      return result_min_set;
    }

  Polynomial p(left.size(), left_right.size(), right.size(), at, cn);

  do{
    //for each combination

    if(combination_validity(at, batv, uatv, p, cstr)){ 
      // weak guard enabled.
	  
      bool combination_valid_untill_now=true;

      // bounded part      
      Clause working_clause_pred=cstr->clause;
      Clause working_clause_imag=cstr->clause;

      if(!Constraint::pure_unbounded){
	Modification_Base bmodification_base(at, cn, pure_right, pure_left, binitiator_modified, 
					     bleft_modified, bleft_right_modified, bright_modified,bs,bp,p);
	// relax the bounded variables modified by the initiator
	for(int index=1; index<=bs; ++index)
	  if(bmodification_base.is_modified(at, index))
	    working_clause_pred.modify(index, Constraint::Bb.gnlb(index), Constraint::Bb.gub(index));
	
	for(int index=bs+1; index<=bs+bp; ++index)
	  if(bmodification_base.is_modified(at, index))
	    working_clause_pred.modify(index-bs+batv, Constraint::Bb.gnlb(index), Constraint::Bb.gub(index));

	for(Actions_Sequence::const_iterator it=binitiator.begin(); it!=binitiator.end() & combination_valid_untill_now; ++it)
	  {// restrict predecessors and images according to the initiator
	    
	    int i=it->get_cipher().first(), j=it->get_cipher().second(); 
	    //assert(i!=j & (i==0 | j==0));
	    int index=(i==0? j: i);
	    numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	    numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
	    
	    if(index<=bs) 
	      { if(!working_clause_pred.tighten(index, nlb, ub)) return result_min_set;}
	    else if(index<=bs+bp)
	      {if(!working_clause_pred.tighten(index-bs+batv, nlb, ub)) return result_min_set;}
	    else if(index<=bsegment) 
	      assert(false);
	    else if(index<=bsegment+bs) 
	      {if(!working_clause_imag.tighten(index-bsegment, nlb, ub)) return result_min_set;}
	    else if(index<=bsegment+bs+bp) 
	      {if(!working_clause_imag.tighten(index-bs-bsegment+batv, nlb, ub)) return result_min_set;}
	    else 
	      assert(false);
	  }

#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% after initiator pred  :" << working_clause_pred;
	cout << "fire_BDC% after initiator image :" << working_clause_imag << endl ;
#endif

	// apply the actions to the bounded/unbounded variables of the receptors
	if(!pure_right)
	  for(int c=1; c<at & combination_valid_untill_now;++c) 
	    { // apply combination p's actions to left receptors
	      int bcatv =bs+(at-1)*(bp+(cn-1)*bc)+bp+(c-1)*bc;
	      for(int index=bs+bp+1; index<=bs+bp+bc; ++index)
		if(bmodification_base.is_modified(c, index))
		  working_clause_pred.modify(index-bs-bp+bcatv, Constraint::Bb.gnlb(index), Constraint::Bb.gub(index));
	      if(0<p.lget(c)){
		for(Actions_Sequence::const_iterator lit=left[p.lget(c)-1].first.begin(); 
		    lit!=left[p.lget(c)-1].first.end() & combination_valid_untill_now; ++lit)
		  if(!apply_baction(*lit, at, batv, c, bcatv, working_clause_pred, working_clause_imag))
		    combination_valid_untill_now=false;
	      }
	      else {
		//assert(0<p.lrget(c));
		for(Actions_Sequence::const_iterator lit=left_right[p.lrget(c)-1].first.begin(); 
		    lit!=left_right[p.lrget(c)-1].first.end() & combination_valid_untill_now; ++lit)
		  if(!apply_baction(*lit, at, batv, c, bcatv, working_clause_pred, working_clause_imag))
		    combination_valid_untill_now=false;
	      }
	    }
	  
#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% output : after left pred  :" << working_clause_pred;
	cout << "fire_BDC% output : after left image :" << working_clause_imag << endl ;
#endif


	if(!pure_left)
	  for(int c=at+1; c<=cn & combination_valid_untill_now;++c) 
	    { // apply combination p's actions to right receptors
	      int bcatv =bs+(at-1)*(bp+(cn-1)*bc)+bp+(c-2)*bc;
	      for(int index=bs+bp+1; index<=bs+bp+bc; ++index)
		if(bmodification_base.is_modified(c, index))
		  working_clause_pred.modify(index-bs-bp+bcatv, Constraint::Bb.gnlb(index), Constraint::Bb.gub(index));
	      if(0<p.rget(c)){
		for(Actions_Sequence::const_iterator lit=right[p.rget(c)-1].first.begin(); 
		    lit!=right[p.rget(c)-1].first.end() & combination_valid_untill_now; ++lit)
		  if(!apply_baction(*lit, at, batv, c, bcatv, working_clause_pred, working_clause_imag))
		    combination_valid_untill_now=false;
	      }
	      else  {
		//assert(0<p.lrget(c));
		for(Actions_Sequence::const_iterator lit=left_right[p.lrget(c)-1].first.begin(); 
		    lit!=left_right[p.lrget(c)-1].first.end() & combination_valid_untill_now; ++lit)
		  if(!apply_baction(*lit, at, batv, c, bcatv, working_clause_pred, working_clause_imag))
		    combination_valid_untill_now=false;
	      }
	    }
#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% output : after right pred  :" << working_clause_pred;
	cout << "fire_BDC% output : after right image :" << working_clause_imag << endl ;
#endif
      }

      Dbm working_dbm;
      if(!Constraint::pure_bounded){
	Modification_Base umodification_base(at, cn, pure_right, pure_left, uinitiator_modified, 
					     uleft_modified, uleft_right_modified, uright_modified,us,up,p);
	// copy constraint's dbm
	working_dbm = Dbm(ucs+umodification_base.modified_number());
	for(int i=0; i<=ucs; ++i){
	  int bi=constraint_to_working(i,ucs,cn,at,uatv,umodification_base);
	  for(int j=i+1; j<=ucs; ++j){
	    int bj=constraint_to_working(j,ucs,cn,at,uatv,umodification_base);
	    numb cij=cstr->dbm.get(i,j); numb cji=cstr->dbm.get(j,i);
	    working_dbm.put(bi, bj, cij); working_dbm.put(bj, bi, cji);
	  }
	}
	// apply initiator actions for unbounded variables
	for(Actions_Sequence::const_iterator init=uinitiator.begin(); 
	    init!=uinitiator.end() & combination_valid_untill_now; ++init)
	  if(!apply_uaction(*init, at, uatv, 0, 0, ucs, umodification_base, working_dbm))
	    return result_min_set;

#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% output : after initiator  :" << working_dbm << endl ;
#endif

	// apply the actions to the unbounded variables of the choices
	if(!pure_right)
	  for(int c=1; c<at & combination_valid_untill_now; ++c) 
	    { // apply combination p's actions to left receptors and initiator
	      int ucatv =us+(at-1)*(up+(cn-1)*uc)+up+(c-1)*uc;    
	      if(0<p.lget(c)){
		for(Actions_Sequence::const_iterator lit=left[p.lget(c)-1].second.begin(); 
		    lit!=left[p.lget(c)-1].second.end()&combination_valid_untill_now; ++lit)
		  if(!apply_uaction(*lit, at, uatv, c, ucatv, ucs, umodification_base, working_dbm))
		    combination_valid_untill_now=false;
	      }
	      else {
		//assert(0<p.lrget(c));
		for(Actions_Sequence::const_iterator lrit=left_right[p.lrget(c)-1].second.begin(); 
		    lrit!=left_right[p.lrget(c)-1].second.end() & combination_valid_untill_now; ++lrit)
		  if(!apply_uaction(*lrit, at, uatv, c, ucatv, ucs, umodification_base, working_dbm))
		    combination_valid_untill_now=false;
	      }
	    }

#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% output : after left  :" << working_dbm << endl ;
#endif      
	
	if(!pure_left)
	  for(int c=at+1; c<=cn & combination_valid_untill_now;++c) 
	    { // apply combination p's actions to right receptors and intiator
	      int ucatv =us+(at-1)*(up+(cn-1)*uc)+up+(c-2)*uc;    
	      if(0<p.rget(c)) {
		for(Actions_Sequence::const_iterator rit=right[p.rget(c)-1].second.begin(); 
		    rit!=right[p.rget(c)-1].second.end() & combination_valid_untill_now; ++rit)
		  if(!apply_uaction(*rit, at, uatv, c, ucatv, ucs, umodification_base, working_dbm))
		    combination_valid_untill_now=false;
	      }	
	      else  {
		//assert(0<p.lrget(c));
		for(Actions_Sequence::const_iterator lrit=left_right[p.lrget(c)-1].second.begin(); 
		    lrit!=left_right[p.lrget(c)-1].second.end() & combination_valid_untill_now; ++lrit)
		  if(!apply_uaction(*lrit, at, uatv, c, ucatv, ucs, umodification_base, working_dbm))
		    combination_valid_untill_now=false;
	      }
	    }

#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% output : after right  :" << working_dbm << endl ;
#endif      
	// Bound, if needed, the predecessors of unbounded variables 
	int index=0, position=(pure_right? at-1 : 0);
	for(Modification_Base::const_iterator it=umodification_base.begin(); 
	    it!=umodification_base.end() & combination_valid_untill_now; ++it){
	  ++position;
	  for(set<int>::const_iterator sit=it->begin(); sit!=it->end(); ++sit)
	    {
	      if(*sit<=us) index=*sit; 
	      else if(position==at){
		//assert(us<*sit & *sit<=us+up); 
		index=uatv+*sit-us; 
	      }
	      else{ 
		//assert(us+up<*sit & *sit<=us+up+uc);
		index=uatv+up+(position<at? position-1: position-2)*uc+(*sit-us-up);
	      }
	      if(!working_dbm.tighten(0, index, Constraint::Ub.gnlb(*sit)))
		combination_valid_untill_now=false;
	    }
	}

#ifdef DEBUG_FIRE_BDC
	cout << "fire_BDC% output : after bounding predecessors of modified  :" << working_dbm << endl ;
#endif      
      }
  
      if(combination_valid_untill_now & !(working_dbm.is_empty() & !Constraint::pure_bounded) 
	 & !((working_clause_pred.is_empty() | working_clause_imag.is_empty()) & !Constraint::pure_unbounded))
	{
	  working_dbm=working_dbm.project_away(ucs+1,working_dbm.vars_card());
	  Constraint_Ref cstr_result(new Constraint(working_clause_pred, working_dbm, cn));
	  cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	  cstr_result->copy_status(cstr);
	  cstr_result->set_sender_and_channels_old(at);
#ifdef DEBUG_FIRE_BDC
	  cout << "fire_BDC% inserting result: " << *cstr_result << endl ;
#endif
	  
	  if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_BDC
	    cout << "fire_BDC% which is entailed by the constraint: " << endl ;
#endif
	  }
	  else
	    result_min_set.insert(cstr_result);
	}
    }   

  }while(p.next());
  
  return result_min_set;
}
  

/* Brief cheap |initiator| check for satisfiability.
 *
 */
bool BDC::check_satisfiable(int batv, int uatv, const Constraint_Ref& cstr) const
{
  //first, the bounded part
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc;
  for(Actions_Sequence::const_iterator it=binitiator_guard.begin(); it!=binitiator_guard.end(); ++it){ 
    // For each action in the guard
    int i=it->get_cipher().first();      int j=it->get_cipher().second();
    //assert((i!=j) & (i==0 | j==0));
    int index=(i==0? j: i);
    numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
    numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
    int r=0;

    if(index<=bs) r=index;
    else if(index<=bs+bp) r=index-bs+batv;
    else if(index<=bsegment) assert(false);
    else if(index<=bsegment+bs) r=index-bsegment;
    else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv;
    else assert(false);

    if(nlb+cstr->clause.gub(r)<=numb(-1)
       | ub+cstr->clause.gnlb(r)<=numb(-1) )
      return false;
  }
  
  //then the unbounded part,
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc;
  for(Actions_Sequence::const_iterator it=uinitiator_guard.begin(); it!=uinitiator_guard.end(); ++it){ 
    // For each action in the guard
      int i=it->get_cipher().first(), j=it->get_cipher().second();
      int ri=0, rj=0;
      if(i<=us)	ri=i;
      else if(i<=us+up)	ri=i-us+uatv;
      else if(i<=usegment) assert(false);
      else if(i<=usegment+us) ri=i-usegment;
      else if(i<=usegment+us+up) ri=i-usegment-us+uatv;
      else assert(false);

      if(j<=us)	rj=j;
      else if(j<=us+up) rj=j-us+uatv;
      else if(j<=usegment) assert(false);
      else if(j<=usegment+us) rj=j-usegment;
      else if(j<=usegment+up+us) rj=j-usegment-us+uatv;
      else assert(false);

      if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1)
	 | it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1) )
	return false;
  }
  
  return true;
}


bool BDC::combination_validity(int at, int batv, int uatv, const Polynomial& p, const Constraint_Ref& cstr) const
{

#ifdef DEBUG_COMBINATION_VALIDITY
  cout << "BDC combination validity% input (at,batv,uatv)=(" << at << "," << batv << "," << uatv << ")" << endl ;
  cout << "BDC combination validity% input polynomial : " << p << endl;
#endif

 //number of processes in cstr
  int cn=cstr->cardinal();

  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc;

  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc;
  
  if(!pure_right)
    for(int c=1; c<at;++c) 
      { //look at the satisfiability of the combination "p" for the left channels
	if(0<p.lget(c)) 
	  {//receptor "c" gets one of the left choices
	    //first, bounded part
	    int bcatv =bs+(at-1)*(bp+(cn-1)*bc)+bp+(c-1)*bc;
	    for(Actions_Sequence::const_iterator it=left_guard[p.lget(c)-1].first.begin(); 
		it!=left_guard[p.lget(c)-1].first.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second(); //assert((i!=j) & (i==0 | j==0));
		int index=(i==0? j: i);
		numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
		numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
		int r=0;
		if(index<=bs) r=index; 
		else if(index<=bs+bp) r=index-bs+batv; 
		else if(index<=bsegment) r=index-bs-bp+bcatv; 
		else if(index<=bsegment+bs) r=index-bsegment;
		else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv; 
		else r=index-bsegment-bs-bp+bcatv; 
		
		if(nlb+cstr->clause.gub(r)<=numb(-1) |
		   ub+cstr->clause.gnlb(r)<=numb(-1))
		  return false;
	      }
	    //second, unbounded part	    
	    int ucatv =us+(at-1)*(up+(cn-1)*uc)+up+(c-1)*uc;
	    for(Actions_Sequence::const_iterator it=left_guard[p.lget(c)-1].second.begin(); 
		it!=left_guard[p.lget(c)-1].second.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second();
		int ri=0, rj=0;
		if(i<=us) ri=i; 
		else if(i<=us+up) ri=i-us+uatv; 
		else if(i<=usegment) ri=i-us-up+ucatv; 
		else if(i<=usegment+us) ri=i-usegment;
		else if(i<=usegment+us+up) ri=i-usegment-us+uatv; 
		else ri=i-usegment-us-up+ucatv; 
		
		if(j<=us) rj=j; 
		else if(j<=us+up) rj=j-us+uatv;
		else if(j<=usegment) rj=j-us-up+ucatv; 
		else if(j<=usegment+us) rj=j-usegment;
		else if(j<=usegment+us+up) rj=j-usegment-us+uatv; 
		else rj=j-usegment-us-up+ucatv; 
		
		if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1) |
		   it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1))
		  return false;
	      }
	  }
	else 
	  {//receptor "c" gets one of the left_right choices.
	    //assert(0<p.lrget(c));
	    //first, bounded part
	    int bcatv =bs+(at-1)*(bp+(cn-1)*bc)+bp+(c-1)*bc;
	    for(Actions_Sequence::const_iterator it=left_right_guard[p.lrget(c)-1].first.begin(); 
		it!=left_right_guard[p.lrget(c)-1].first.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second(); //assert((i!=j) & (i==0 | j==0));
		int index=(i==0? j: i);
		numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
		numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
		int r=0;
		if(index<=bs) r=index; 
		else if(index<=bs+bp) r=index-bs+batv; 
		else if(index<=bsegment) r=index-bs-bp+bcatv; 
		else if(index<=bsegment+bs) r=index-bsegment;
		else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv; 
		else r=index-bsegment-bs-bp+bcatv; 
		
		if(nlb+cstr->clause.gub(r)<=numb(-1) |
		   ub+cstr->clause.gnlb(r)<=numb(-1))
		  return false;
	      }
	    //second, unbounded part
	    int ucatv =us+(at-1)*(up+(cn-1)*uc)+up+(c-1)*uc;
	    for(Actions_Sequence::const_iterator it=left_right_guard[p.lrget(c)-1].second.begin(); 
		it!=left_right_guard[p.lrget(c)-1].second.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second();
		int ri=0, rj=0;
		if(i<=us)  ri=i; 
		else if(i<=us+up)   ri=i-us+uatv;
		else if(i<=usegment) ri=i-us-up+ucatv; 
		else if(i<=usegment+us) ri=i-usegment;
		else if(i<=usegment+us+up)  ri=i-usegment-us+uatv; 
		else ri=i-usegment-us-up+ucatv; 
		
		if(j<=us) rj=j; 
		else if(j<=us+up) rj=j-us+uatv;
		else if(j<=usegment) rj=j-us-up+ucatv; 
		else if(j<=usegment+us) rj=j-usegment;
		else if(j<=usegment+us+up) rj=j-usegment-us+uatv; 
		else rj=j-usegment-us-up+ucatv; 
		
		if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1) |
		   it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1))
		  return false;
	      }
	  }
      }


  if(!pure_left)
    for(int c=at+1; c<=cn;++c) 
      { //look at the satisfiability of the combination "p" for the right channels
	if(0<p.rget(c)) 
	  {//receptor "c" gets one of the right choices
	    //first, the bounded part
	    int bcatv =bs+(at-1)*(bp+(cn-1)*bc)+bp+(c-2)*bc;
	    for(Actions_Sequence::const_iterator it=right_guard[p.rget(c)-1].first.begin(); 
		it!=right_guard[p.rget(c)-1].first.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second(); //assert((i!=j) & (i==0 | j==0));
		int index=(i==0? j: i);
		numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
		numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
		int r=0;
		if(index<=bs) r=index; 
		else if(index<=bs+bp) r=index-bs+batv; 
		else if(index<=bsegment) r=index-bs-bp+bcatv; 
		else if(index<=bsegment+bs) r=index-bsegment;
		else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv; 
		else r=index-bsegment-bs-bp+bcatv; 
		
		if(nlb+cstr->clause.gub(r)<=numb(-1) |
		   ub+cstr->clause.gnlb(r)<=numb(-1))
		  return false;
	      }
	    //second, the unbounded part
	    int ucatv =us+(at-1)*(up+(cn-1)*uc)+up+(c-2)*uc;
	    for(Actions_Sequence::const_iterator it=right_guard[p.rget(c)-1].second.begin(); 
		it!=right_guard[p.rget(c)-1].second.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second();
		int ri=0, rj=0;
		if(i<=us)  ri=i; 
		else if(i<=us+up)   ri=i-us+uatv;
		else if(i<=usegment) ri=i-us-up+ucatv; 
		else if(i<=usegment+us) ri=i-usegment;
		else if(i<=usegment+us+up)  ri=i-usegment-us+uatv; 
		else ri=i-usegment-us-up+ucatv; 

		if(j<=us) rj=j; 
		else if(j<=us+up) rj=j-us+uatv;
		else if(j<=usegment) rj=j-us-up+ucatv; 
		else if(j<=usegment+us) rj=j-usegment;
		else if(j<=usegment+us+up) rj=j-usegment-us+uatv; 
		else rj=j-usegment-us-up+ucatv; 
	    	    
		if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1) |
		   it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1))
		  return false;
	      }
	}	
	else 
	  {//receptor "c" gets one of the left_right choices
	    //assert(0<p.lrget(c));
	    //first, the bounded part
	    int bcatv =bs+(at-1)*(bp+(cn-1)*bc)+bp+(c-2)*bc;
	    for(Actions_Sequence::const_iterator it=left_right_guard[p.lrget(c)-1].first.begin(); 
		it!=left_right_guard[p.lrget(c)-1].first.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second(); //assert((i!=j) & (i==0 | j==0));
		int index=(i==0? j: i);
		numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
		numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
		int r=0;
		if(index<=bs) r=index; 
		else if(index<=bs+bp) r=index-bs+batv; 
		else if(index<=bsegment) r=index-bs-bp+bcatv; 
		else if(index<=bsegment+bs) r=index-bsegment;
		else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv; 
		else r=index-bsegment-bs-bp+bcatv; 
		
		if(nlb+cstr->clause.gub(r)<=numb(-1) |
		   ub+cstr->clause.gnlb(r)<=numb(-1))
		  return false;
	      }
	    //second, the unbounded part
	    int ucatv =us+(at-1)*(up+(cn-1)*uc)+up+(c-2)*uc;
	    for(Actions_Sequence::const_iterator it=left_right_guard[p.lrget(c)-1].second.begin(); 
		it!=left_right_guard[p.lrget(c)-1].second.end(); ++it)
	      {
		int i=it->get_cipher().first(), j=it->get_cipher().second();
		int ri=0, rj=0;
		if(i<=us)  ri=i; 
		else if(i<=us+up)   ri=i-us+uatv;
		else if(i<=usegment) ri=i-us-up+ucatv; 
		else if(i<=usegment+us) ri=i-usegment;
		else if(i<=usegment+us+up)  ri=i-usegment-us+uatv; 
		else ri=i-usegment-us-up+ucatv; 

		if(j<=us) rj=j; 
		else if(j<=us+up) rj=j-us+uatv;
		else if(j<=usegment) rj=j-us-up+ucatv; 
		else if(j<=usegment+us) rj=j-usegment;
		else if(j<=usegment+us+up) rj=j-usegment-us+uatv; 
		else rj=j-usegment-us-up+ucatv; 	
	    
		if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1) |
		   it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1))
		  return false;
	      }
	  }
      }

  return true;
}
