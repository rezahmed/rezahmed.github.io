/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file polynomial.h
 * Header for polynomila
 *
 * @author Rezine Ahmed
 */

#ifndef DBS_POLYNOMIAL_H
#define DBS_POLYNOMIAL_H

#include <iostream>
#include <assert.h>
#include <vector>
#include <iterator>

//#define DEBUG_NEXT


using namespace std;

/* this class is given 3 sets: "left={1,...,lcp}", "right={1,..., rcp}" 
 * and  "left-right={1,..., lrcp}". It is also given a size "cn", and a position
 * "at" in {1,..., cn}.
 */
class Polynomial
{
 public:

  /* Each position in {1,...,at-1} will evolve from 1 if lcp or lrcp 
   * is non nul,0 ow, to lcp+lrcp.
   * Notice that if lcp=lrcp=0, then the position evolves from 0 to 0.
   * Each position in {at,...,cn-1} will evolve from 1 if rcp or lrcp 
   * is non nul,0 ow, to rcp+lrcp.
   * Notice that if rcp=lrcp=0, then the position evolves from 0 to 0.
   */
  Polynomial(int _lcp, int _lrcp, int _rcp, int _at, int _cn):
    lcp(_lcp), lrcp(_lrcp), rcp(_rcp), 
    at(_at), cn(_cn), no_more_combinations(_lcp+_lrcp+_rcp==0)
    {
      int lmax=lcp+lrcp;

      max.insert(max.end(), at-1, lmax);
      store.insert(store.end(), at-1, 1);

      int rmax=lrcp+rcp;

      max.insert(max.end(), cn-at, rmax);
      store.insert(store.end(), cn-at, 1);
    }
    

    /* for a position in {1,..,at}, returns 
     * the corresponding left rule in {1,...,lcp}, 
     * or 0 if not to be applied
     */
    int lget(int rec)const{
      assert(rec<at);
      return (0<store[rec-1]-lrcp? store[rec-1]-lrcp:0);
    } 

    int rget(int rec)const{
      assert(at<rec);
      return (0<store[rec-2]-lrcp? store[rec-2]-lrcp:0);
    }
 
    int lrget(int rec)const{
      assert(rec!=at);
      if(rec<at)
	return (store[rec-1]<=lrcp? store[rec-1]:0);
      else
	return (store[rec-2]<=lrcp? store[rec-2]:0);
    } 
    
    bool next() 
    {
 #ifdef DEBUG_NEXT 
      cerr << "polynomial %  next: " << endl;
#endif
      if(no_more_combinations) 
	{
 #ifdef DEBUG_NEXT 
	  cerr << "polynomial %  output false " << endl;
#endif
	  return false;
	}
      else 
	for(unsigned i=0; i<store.size(); i++) 
	  if(store[i]<max[i]){
	    store[i]++;
 #ifdef DEBUG_NEXT 
	    cerr << "polynomial %  output true " << endl;
#endif
	    return true;
	  }
	  else
	    store[i]=1;
 #ifdef DEBUG_NEXT       
      cerr << "polynomial %  output false " << endl;
#endif
      no_more_combinations=true;
      return false;
    }


    bool end()const{return no_more_combinations;}
  
    friend ostream& operator<< (ostream& out, const Polynomial& p);

 private:
    int lcp, lrcp, rcp;
    int at, cn;
    bool no_more_combinations;
    vector<int> store;
    vector<int> max;
};



inline ostream& operator<< (ostream& out, const Polynomial& p)
{

  out << "[lcp=" << p.lcp << ", lrcp=" << p.lrcp << ", rcp=" << p.rcp << ", cn=" << p.cn 
      << ", at=" << p.at << (p.end()? ", ended":", not ended") << "]->( " ;
  for(vector<int>::const_iterator sit=p.store.begin(); sit!=p.store.end(); sit++)
    out << *sit << " " ;

  out  << ")";// << endl;

  return out;
}

#endif

