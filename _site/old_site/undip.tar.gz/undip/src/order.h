/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/**@file next.h
 *ADT for next operator.
 *
 *@author Rezine Ahmed. 
 */

#ifndef _UNDIP_ORDER_H
#define _UNDIP_ORDER_H

/**
 * This class defines the order on constraints
 * using the entailement relation.
 * (c1,c2)=([|c2|] in [|c1|])
 */
template<class T>
class EntailmentOrder
{
 public:
  EntailmentOrder<T>() {}

  bool operator()(const T& C1, const T& C2) const{
    return (C1->entailed(C2));
  }
};


#endif
