/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file exp.h
 * Header for EXP
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_EXP_H
#define _UNDIP_EXP_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <map>

#include "ref.h"
#include "order.h"
#include "minset.h"
#include "dbm.h"
#include "clause.h"
#include "constraint.h"
#include "cipher.h"
#include "action.h"
#include "actions_sequence.h"
#include "rule.h"
#include "confederation.h"

using namespace std;

/** Brief Specialized Transitions for Exists Globally.  
 *  Updates the firing process and a witness process, which witness may eventually, 
 *  be created together with its witnesss with the other processes. The values
 *  of the firing process and of the witness are to verify and to be updated
 *  according to the list of dbms.
 */
class EXP: public Rule
{

  /** Brief fire transition at specified position without witness insertion.
   *  \param at index of the firing process.
   *  \param w index of the witness process.
   *  \param watv encoding position of the witness witness.
   *  \param atv encoding position of the firing process.
   *  \param cs number of encoding variables in the constraint.
   *  \param cstr_dbm dbm of the image constraint the pre of which is to be computed.
   *  \returns dbm of the predecessor constraint, empty dbm if disabled.
   */
  pair<Clause,Dbm> fire_position_specified_witness_no_insertion(int at,int w,int batv,int uatv, 
								int bwatv,int uwatv,const Constraint_Ref& cstr) const;

/* 
 */
 int action_to_working(int i, int uatv, int uwatv, 
			int usegment, int cs) const;

 /* Get the constraint to the working dbm.
  *
  */ 
 int constraint_to_working(int i,int cs,int uatv,int uwatv) const;
 
 /* Easy check to save time in case transitions disabled.
  *
  */
  bool check_satisfiable(int at, int batv, int uatv, const Constraint_Ref& cstr) const;
  
  
  /* Easy check to save time in case transition disabled on the given witness.
   *
  */
  bool check_witness_validity(int at, int batv, int uatv, int bwatv, 
			      int uwatv, const Constraint_Ref& cstr) const;
  

 public:
/** Brief Construct a Specialized Transition for Sending Globally.
 *  
 */
 EXP(const Actions_Sequence& _sequence, const Quantifier_Domain& _domain=LR);
  
  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > fire_position(const Constraint_Ref&, int, bool) const;

 protected:
  void printOn(ostream& o) const;

 private:
  Actions_Sequence bsequence;
  set<int> bounded_shared_modified, bounded_process_modified, 
    bounded_witness_modified;
  Actions_Sequence bounded_shared_and_process_guard, bounded_witness_guard;
  Clause bimage;
  
  Actions_Sequence usequence;
  set<int> unbounded_shared_modified, unbounded_process_modified, 
    unbounded_witness_modified;
  map<int, int> modification;
  Actions_Sequence unbounded_shared_and_process_guard, unbounded_witness_guard;
  Dbm uimage;
  
  Quantifier_Domain domain;  
};



#endif

