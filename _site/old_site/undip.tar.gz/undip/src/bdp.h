/*
    Copyright (C) 2006 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file bdp.h
 * Header for BDP
 *
 * @author Rezine Ahmed
 */

#ifndef UNDIP_BDP_H
#define UNDIP_BDP_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <iterator>

#include "ref.h"
#include "order.h"
#include "minset.h"
#include "dbm.h"
#include "clause.h"
#include "constraint.h"
#include "cipher.h"
#include "action.h"
#include "actions_sequence.h"
#include "rule.h"

#include "polynomial.h"
#include "modification_base.h"

using namespace std;

/* Brief Transition Broadcast to other Processes Globally.
 * Updates the firing process and all other processes in the 
 * Domain. The values of the firing process and of the 
 * other processes in the domain are to to verify and to 
 * be updated according to the matrices.
 */
class BDP: public Rule
{

  /* Brief sends a variable from the original constraint to the working Dbm.
   */
  int constraint_to_working(int i, int ucs, int cn, int at, int uatv, const Modification_Base& modification_base) const;

  /* Brief apply an action on bounded variables, with "at" as 
   * initiator and "c" as receptor
   */
  bool apply_baction(const Action& action, 
		     int at, int batv, int c, int bwatv,
		     Clause& clause_pred, Clause& clause_imag) const;
  
  /* Brief apply the action on unbounded variables with "at" as 
   * initiator and "c" as receptor
   */
  bool apply_uaction(const Action& action, 
		     int at, int uatv, int c, int uwatv, int ucs,
		     const Modification_Base& modification_base, 
		     Dbm& working_dbm) const;

/* Brief cheap |initiator| check for satisfiability.
 *
 */
 bool check_satisfiable(int batv, int uatv, const Constraint_Ref& cstr) const;

 /* Brief cheap Sum_c|max{left(c), left_right(c), right(c)}| check for the satisfiability
  * of the current combination.
  */
 bool combination_validity(int at, int batv, int uatv, const Polynomial& p, const Constraint_Ref& cstr) const;

 public:
  
  BDP(const Actions_Sequence& _initiator, 
	const vector<Actions_Sequence>& _left, 
	const vector<Actions_Sequence>& _left_right, 
	const vector<Actions_Sequence>& _right);

  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > fire_position(const Constraint_Ref&, int, bool ) const;

 protected:
  void printOn(ostream& o) const;

 private:

  // Only left/right receptors concerned?
  bool pure_left, pure_right;

  // Sequence applied to the firing process bounded/unbounded variables
  Actions_Sequence binitiator, uinitiator; 
  // Choices of sequences to be applied to the bounded/unbounded 
  // variables of the processes to the left, both left and right, 
  // or right of the firing process. 
  vector<pair<Actions_Sequence, Actions_Sequence> > left, left_right, right;

  // Bounded/unbounded variables modified in one of the initiator's 
  // sequence's actions. Variables modified in an action belonging 
  // to a sequence of one of the choices
  set<int> binitiator_modified, bchoice_modified;
  set<int> uinitiator_modified, uchoice_modified;

  // Each pair of sets (bk,uk) of index "k" in x_modified 
  // (x in {left, left_right, right}) corresponds to the set 
  // of bounded variables for bk, unbounded for uk, modified 
  // in some action of the sequence of index "k" in x.
  vector<set<int> > bleft_modified,bleft_right_modified,bright_modified,
    uleft_modified,uleft_right_modified,uright_modified;

  // Sequence of the actions in initiator in which are involved variables 
  // that are either modified in some action in initiator,
  // or not modified in any action: neither in initiator nor in any action in 
  // any sequence in any choice in left, left_right or right.
  Actions_Sequence binitiator_guard, uinitiator_guard;

  // Each pair (bk, uk) of sequences of actions with index "k" in x_guard 
  // (with x in {left, left_right, right}) corresponds to the actions in 
  // the sequence with index "k" in x and (the actions) involving 
  // bounded variables for bk, unbounded for uk, that are either modified 
  // in the rule, or non modified in the whole bounded/unbounded sequence.
  vector<pair<Actions_Sequence, Actions_Sequence> > left_guard,left_right_guard,right_guard;
};

#endif

