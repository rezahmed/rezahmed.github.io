
#include "dbm.h"

//#define DEBUG_REORDER
//#define DEBUG_PERMUTE
//#define DEBUG_PROJECT_AWAY
//#define DEBUG_IS_EMPTY
//#define DEBUG_INTERSECT
//#define DEBUG_EXTEND
//#define DEBUG_ADD_VARIABLE
//#define DEBUG_MODIFY
//#define DEBUG_TIGHTEN
//#define CHECK_MODIFY
//#define CHECK_ADD_VARIABLE
//#define NOPTIMIZED 

Dbm Dbm::extend(int k) const
{
#ifdef DEBUG_EXTEND
  std::cout << "extend % input " << k << ", " << *this << std::endl; 
#endif
  
  Dbm result(*this);

  int old=result.cardinal;
  result.cardinal+=k;

  std::vector<numb> small(k, numb());
  std::vector<numb> raw(result.cardinal+1, numb());

  for(int i=0; i<=old; ++i)
    result[i].insert(result[i].end(), small.begin(), small.end());

  for(int i=old; i<result.cardinal; ++i)
    result.push_back(raw);

#ifdef DEBUG_EXTEND
    std::cout << "extend % output " << result << std::endl;
#endif
    return result;
}


bool Dbm::is_empty() const{
#ifdef DEBUG_IS_EMPTY
  std::cout << "Dbm::is_empty % input: " << *this << std::endl;
#endif

  //assert(closed);

#ifdef DEBUG_IS_EMPTY
  std::cout << "Dbm::is_empty % output : " << (empty? "true": "false") << std::endl ;
#endif
  
  return empty;
}

//true iff empty
//normalizes and sets closed/empty flags
bool Dbm::normalize_and_close()
{
  if(closed)
    return empty;

  closed=true;
  
  Dbm D0(*this);
  for(int k=0; k<=cardinal; ++k) { 
    D0=*this;
    for(int i=0; i<=cardinal; ++i)
      for(int j=0; j<=cardinal; ++j)
	{
	  if(i!=k & k!=j & i!=j)
	    {
	      numb tmp=D0.get(i,k)+D0.get(k,j);
	      if(!tmp.inf & !(D0.get(i,j) <= tmp))
		put(i,j, tmp); 
	    }
	}
  }
    

  for(int i=0; i<=cardinal; ++i)
    for(int j=i+1; j<=cardinal; ++j)
      if(get(i,j) + get(j,i) <= numb(-1))
	{
	  //empty
	  clear();
	  empty=true;
	  cardinal=0;
	  push_back(std::vector<numb>(1,numb()));
	  return true;
	}

  empty=false;
  return false;
}


//true iff result non empty
bool Dbm::add_variable(int index, numb lb, numb ub)
{

#ifdef DEBUG_ADD_VARIABLE
  std::cout << "Dbm add variable % input (index,lb,ub) = (" << index << "," << lb << "," << ub << ")" << std::endl;
  std::cout << "Dbm add variable % input Dbm " << *this << std::endl;
#endif

  if(empty)
    {
#ifdef DEBUG_ADD_VARIABLE
      std::cout << "Dbm add variable % empty input" << std::endl;
#endif
      return false;
    }

  int cn=vars_card();
  //assert(closed & 1<=index & index<=cn+1);

#ifdef CHECK_ADD_VARIABLE
  Dbm check=*this;      
  check.open();
  std::vector<numb>::iterator cvnit;
  cvnit=check[0].begin();
  advance(cvnit, index);
  check[0].insert(cvnit, lb);
  for(int i=1; i<=cn; ++i)
    {
      cvnit=check[i].begin();
      advance(cvnit, index);
      check[i].insert(cvnit, numb());
    }
  std::vector<numb> craw(cn+2, numb());
  craw[0]=ub;
  std::vector<std::vector<numb> >::iterator cdit=check.begin();
  advance(cdit, index);
  check.insert(cdit, craw);
  ++check.cardinal;
  check.normalize_and_close();
#endif

  if(lb+ub<=numb(-1))
    {
      clear();
      empty=true;
      cardinal=0;
      push_back(std::vector<numb>(1,numb()));
#ifdef DEBUG_ADD_VARIABLE
  std::cout << "Dbm add variable % output empty " << std::endl;
#endif
      return false;
    }
	
  ++cardinal;
  std::vector<numb>::iterator vnit;

  vnit=operator[](0).begin();
  advance(vnit, index);
  operator[](0).insert(vnit, lb);

  if(!lb.inf)
    {
      for(int i=1; i<=cn; ++i)
	{
	  numb i_index=get(i,0)+lb;
	  vnit=operator[](i).begin();
	  advance(vnit, index);
	  operator[](i).insert(vnit, i_index);
	}
    }
  else
    {
      for(int i=1; i<=cn; ++i)
	{
	  vnit=operator[](i).begin();
	  advance(vnit, index);
	  operator[](i).insert(vnit, lb);
	}
    }

  std::vector<numb> raw(cn+2, numb());

  raw[0]=ub;
  if(!ub.inf)
    {
      for(int i=1; i<index; ++i)
	raw[i]=ub+get(0,i);
      for(int i=index+1; i<=cn+1; ++i)
	raw[i]=ub+get(0,i-1);
    }

  std::vector<std::vector<numb> >::iterator dit=begin();
  advance(dit, index);
  insert(dit, raw);

#ifdef DEBUG_ADD_VARIABLE
  std::cout << "Dbm add variable % output not empty " << std::endl;
  std::cout << "Dbm add variable % output " << *this << std::endl;
#endif

#ifdef CHECK_ADD_VARIABLE
  if(!(check==*this))
    {
      std::cout << "Dbm add variable% after adding the modified variables: " << *this << std::endl;
      std::cout << "Dbm add variable% check with   the modified variables: " << check << std::endl;
      assert(false);
    }

#endif

  return true;
}


Dbm Dbm::project_away(int from, int to) const
  {
#ifdef DEBUG_PROJECT_AWAY
    std::cout << std::endl << std::endl 
	      << "Dbm::project_away % input (f,t)=(" << from << "," << to << ")" << std::endl;
    std::cout << "Dbm::project_away % input " << *this << std::endl;
#endif

    if(is_empty())
      {
#ifdef DEBUG_PROJECT_AWAY
	std::cout << "Dbm::project_away % output : " << empty << std::endl;
#endif
	return Dbm();
      }

    if(to<from)
      return Dbm(*this);

    //assert(1 <= from & from<=vars_card() & 1<= to & to<=vars_card());
    
    Dbm result(*this);

    //    first, we remove the lines from-->to 
    std::vector<std::vector<numb> >::iterator from_it=result.begin(), to_it=result.begin();
    advance(from_it, from);
    advance(to_it, to+1);
    result.erase(from_it, to_it);

    //then, we remove the columns from-->to

    for(int i=0; i<=(cardinal-(to-from+1)); ++i)
      {
	std::vector<numb>::iterator from_it=result[i].begin(), to_it=result[i].begin();
	advance(from_it, from);
	advance(to_it, to+1);
	result[i].erase(from_it, to_it);
      }

    result.cardinal= (cardinal - (to-from+1));
    //assert(result.cardinal==int(result.size()-1));
    
#ifdef DEBUG_PROJECT_AWAY
    std::cout << "Dbm::project_away % output " << result << std::endl;
#endif
    return result;
  }

Dbm Dbm::operator&(const Dbm& other) const 
{
  //assert(size()==other.size());

  Dbm result(*this);

  bool minimize=false;

  for(int i=0; i<=vars_card(); ++i)
    for(int j=i+1; j<=vars_card(); ++j)
      {
	if(other.get(i,j) < result.get(i,j))
	  {
	    minimize=true;
	    result.put(i,j, other.get(i,j));
	  }
	
	if(other.get(j,i) < result.get(j,i))
	  {
	    minimize=true;
	    result.put(j,i, other.get(j,i));
	  }
      }

  if(minimize)
    result.open();
  result.normalize_and_close();
  return result;
}


bool Dbm::tighten(int i0, int j0, numb m)
{

  if(empty)
    {
#ifdef DEBUG_TIGHTEN
      std::cout << "Dbm tighten % empty input" << std::endl;
#endif
      return false;
    }


  int cn=vars_card();
  //assert(closed 
  //	 & 0<=i0 & i0<=cn
  //	 & 0<=j0 & j0<=cn
  //	 & i0 != j0);


  if(get(i0,j0)<=m)
    {
#ifdef DEBUG_TIGHTEN
      std::cout << "Dbm tighten % output unchanged"  << std::endl;
#endif
      return true;
    }
  else
    return modify(i0, j0, m);

}


//true iff result non empty
bool Dbm::modify(int i0, int j0, numb m)
{

#ifdef DEBUG_MODIFY
  std::cout << "Dbm modify % input (i0,j0,m) = (" << i0 << "," << j0 << "," << m << ")" << std::endl;
  //std::cout << "Dbm modify % input Dbm " << *this << std::endl;
#endif


  if(empty)
    {
#ifdef DEBUG_MODIFY
      std::cout << "Dbm modify % empty input" << std::endl;
#endif
      return false;
    }


  int cn=vars_card();
  //assert(closed 
  //	 & 0<=i0 & i0<=cn
  //	 & 0<=j0 & j0<=cn
  //	 & i0 != j0);


 /* if(get(i0,j0)<=m) { #ifdef DEBUG_MODIFY std::cout << "Dbm modify
    % output unchanged" << std::endl; #endif return true; } */

  if(m+get(j0,i0)<=numb(-1)){
 #ifdef DEBUG_MODIFY
    std::cout << "Dbm modify % output empty from first check (m,[j0,i0]) : ("<< m << "," << get(j0,i0) << ")" << *this << std::endl;
    std::cout << "Dbm modify % output empty from first check : " << *this << std::endl;
#endif
   clear();
    empty=true;
    cardinal=0;
    push_back(std::vector<numb>(1,numb()));

    return false;
  }
	
  int min = (i0<j0? i0: j0);
  int max = (i0<j0? j0: i0);

  operator[](i0)[j0]=m;

#ifdef CHECK_MODIFY
  Dbm check=*this;      
  check.put(i0,j0,m);
  check.open();
  check.normalize_and_close();
#endif


  //min pivot
  for(int i=0; i< min; ++i)
    {
#ifdef NOPTIMIZED      
      for(int j=0; j< min; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
      
      for(int j=min+1; j< max; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
      
      for(int j=max+1; j<= cn; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
#endif

    numb ij=operator[](i)[min]+operator[](min)[max];
    if(ij<=operator[](i)[max])
      operator[](i)[max]=ij;
  }

  for(int i=min+1; i< max; ++i)
    {
#ifdef NOPTIMIZED      
      for(int j=0; j< min; ++j)	{
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
      
      for(int j=min+1; j< max; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
      
      for(int j=max+1; j<= cn; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
#endif

      numb ij=operator[](i)[min]+operator[](min)[max];
      if(ij<=operator[](i)[max])
	operator[](i)[max]=ij;
    }

  for(int i=max+1; i<=cn; ++i)
    {
#ifdef NOPTIMIZED      
      for(int j=0; j< min; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
      
      for(int j=min+1; j< max; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
      
      for(int j=max+1; j<= cn; ++j){
	numb ij=operator[](i)[min]+operator[](min)[j];
	if(ij<=operator[](i)[j])
	  operator[](i)[j]=ij;
      }
#endif
      numb ij=operator[](i)[min]+operator[](min)[max];
      if(ij<=operator[](i)[max])
	operator[](i)[max]=ij;
    }

  //i=max
  //#ifdef NOPTIMIZED

#ifndef NOPTIMIZED      
      if(!operator[](max)[min].inf)
	{
#endif     
    for(int j=0; j< min; ++j){
      numb ij=operator[](max)[min]+operator[](min)[j];
      if(ij<=operator[](max)[j])
	operator[](max)[j]=ij;
    }
    
      for(int j=min+1; j< max; ++j){
	numb ij=operator[](max)[min]+operator[](min)[j];
	if(ij<=operator[](max)[j])
	  operator[](max)[j]=ij;
      }
      
      for(int j=max+1; j<= cn; ++j)	{
	numb ij=operator[](max)[min]+operator[](min)[j];
	if(ij<=operator[](max)[j])
	  operator[](max)[j]=ij;
      }
#ifndef NOPTIMIZED      
	}
#endif     

	
//max pivot

  for(int i=0; i<min; ++i)
    {

#ifndef NOPTIMIZED      
      if(!operator[](i)[max].inf)
	{
#endif
	  for(int j=0; j< min; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  for(int j=min+1; j< max; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  for(int j=max+1; j<= cn; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  numb ij=operator[](i)[max]+operator[](max)[min];
	  if(ij<=operator[](i)[min])
	    operator[](i)[min]=ij;
#ifndef NOPTIMIZED      
	}
#endif
    }
      
  for(int i=min+1; i< max; ++i)
    {
#ifndef NOPTIMIZED      
      if(!operator[](i)[max].inf)
	{
#endif
	  for(int j=0; j< min; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  for(int j=min+1; j< max; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }

	  for(int j=max+1; j<= cn; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }

	  numb ij=operator[](i)[max]+operator[](max)[min];
	  if(ij<=operator[](i)[min])
	    operator[](i)[min]=ij;
#ifndef NOPTIMIZED      
	}
#endif
  }

  for(int i=max+1; i<=cn; ++i)
    {
#ifndef NOPTIMIZED      
      if(!operator[](i)[max].inf)
	{
#endif
	  for(int j=0; j< min; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  for(int j=min+1; j< max; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  for(int j=max+1; j<= cn; ++j){
	    numb ij=operator[](i)[max]+operator[](max)[j];
	    if(ij<=operator[](i)[j])
	      operator[](i)[j]=ij;
	  }
	  
	  numb ij=operator[](i)[max]+operator[](max)[min];
	  if(ij<=operator[](i)[min])
	    operator[](i)[min]=ij;
#ifndef NOPTIMIZED      
	}
#endif
    }
  
#ifndef NOPTIMIZED      
  if(!operator[](min)[max].inf)
    {
#endif
      for(int j=0; j< min; ++j){
	numb ij=operator[](min)[max]+operator[](max)[j];
	if(ij<=operator[](min)[j])
	  operator[](min)[j]=ij;
      }
      
      for(int j=min+1; j< max; ++j){
	numb ij=operator[](min)[max]+operator[](max)[j];
	if(ij<=operator[](min)[j])
	  operator[](min)[j]=ij;
      }
      
      for(int j=max+1; j<= cn; ++j)	{
	numb ij=operator[](min)[max]+operator[](max)[j];
	if(ij<=operator[](min)[j])
	  operator[](min)[j]=ij;
      }
#ifndef NOPTIMIZED      
    }
#endif

#ifdef DEBUG_MODIFY
  if(is_empty())  
    std::cout << "Dbm modify % output  empty !! " << std::endl;
#endif


#ifdef CHECK_MODIFY
  if(!(check==*this))
    {
      std::cout << "Dbm modify % output with the modified variables :" << *this << std::endl;
      std::cout << "Dbm modify % check with   the modified variables: " << check << std::endl;
      assert(false);
    }

#endif

  return true;

}
