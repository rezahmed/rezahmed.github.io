

/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

#ifndef _NUMB_H

#define _NUMB_H

#include <iostream>
#include <assert.h>

using namespace std;

class numb
{
  numb(bool _inf, bool _minf, int _value):inf(_inf), minf(_minf), value(_value)
    {assert(!minf | !inf);}

 public:
  numb():inf(true), minf(false), value(0){}
  numb(int _value): inf(false), minf(false), value(_value){}

  bool operator==(const numb& other) const {
    if (inf & other.inf) return true; 
    else if(minf & other.minf) return true;
    else if(inf | other.inf) return false;
    else  return other.value == value;
  }


  bool operator!=(const numb& other) const {
    return !((*this)== other);
  }

  bool operator<=(const numb& other) const {
    if (other.inf) return true; 
    else if (inf) return false;
    else if (minf) return true;
    else if (other.minf) return false;
    else return value <= other.value;
  }

  bool operator<(const numb& other) const {
    if (inf) return false; 
    else if (other.inf) return true;
    else if (other.minf) return false;
    else if (minf) return true;
    else return value < other.value;
  }

  //  bool operator<(const numb& other) const {
  //  return (*this)<=other & (*this)!=other;
  // }

  numb operator+(const numb& other) const
  {
    assert(!((inf&other.minf) | (minf&other.inf)));
    if (inf | other.inf) return numb(); 
    else if(minf | other.minf) return numb(false, true, 0);
    else return numb(other.value + value);
  }

  numb operator-(const numb& other) const
  {
    assert(!( (inf & other.inf) | (minf & other.minf) ));

    if(inf) return numb();
    else if(minf) return numb(false, true, 0);
    else return numb(value-other.value);
  }

  numb operator-() const
  {
    if(inf) return numb(false, true, 0);
    else if(minf) return numb();
    else return numb(-value);
  }

  friend std::ostream& operator<< (std::ostream& out, const numb& n);

  // private:
  bool minf;
  bool inf;
  int  value;
};


inline std::ostream& operator<< (std::ostream& out, const numb& n)
{
  if(n.inf) return out << "oo";
  else if(n.minf) return out << "-oo";
  else return out << n.value;
}


#endif
