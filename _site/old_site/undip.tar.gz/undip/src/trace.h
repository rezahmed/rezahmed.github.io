/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/**@file trace.h
 * Definition of  whatever is needed for tracing
 *
 *@author Ahmed Rezine
 */
#ifndef _TRACE_H
#define _TRACE_H

#include <iostream>
#include <map>

#include "constraint.h"
#include "minset.h"
#include "order.h"
#include "next.h"



class Trace : public std::map<unsigned, const Constraint_Ref>
{
 public:

  Trace(){}
  void add(const Constraint_Ref cstr){
    std::pair<unsigned, const Constraint_Ref> element(cstr->cid, cstr);
    insert(element);
  }
  unsigned parent_id(unsigned id) const{
    assert(find(id)!=end());
    return (find(id)->second)->cpid;
  }
  unsigned parent_action(unsigned id) const{
    assert(find(id)!=end());
    return (find(id)->second)->crid;
  }


  unsigned parent_position(unsigned id)const{
    assert(find(id)!=end());
    return (find(id)->second)->cpos;
  }

  const Constraint_Ref constraint(unsigned id) const{
    assert(find(id)!=end());
    return find(id)->second;
  }

  void track(unsigned id){
    bool tracking=true;
    unsigned target=id;
    while(tracking){
      assert(find(target)!=end());
      //      std::cout << "tracking% id: " << target << ", parent: " << parent_id(target) << ", via action: " 
      //		<< parent_action(target) << ", on position: " << parent_position(target) << std::endl;
      std::cout << *constraint(target) << std::endl;
      if(parent_id(target)!=0)
	target=parent_id(target);
      else
	tracking=false;
    }
  }
};

#endif

