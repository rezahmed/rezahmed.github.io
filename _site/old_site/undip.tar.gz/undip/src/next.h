/*
  Copyright (C) 2007 Rezine Ahmed

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/**@file next.h
 *ADT for next operator.
 *
 *@author Rezine Ahmed. 
 */

#ifndef _UNDIP_NEXT_H
#define _UNDIP_NEXT_H


#include "clause.h"
#include "dbm.h"

#include "order.h"
#include "minset.h"

#include "constraint.h"
#include "rule.h"


/**
 * class Reached
 * Reached answers wether the fispoint has been reached.
 */
template<class le=EntailmentOrder<Constraint_Ref> > 
class Reached
{
 public:

  virtual  bool answer(const MinSet<Constraint_Ref, le>& ) = 0;

  unsigned answer_id(const MinSet<Constraint_Ref, le>& subject) {
    typename MinSet<Constraint_Ref, le>::const_iterator its=subject.begin();
    for(; its!=subject.end(); ++its){
      MinSet<Constraint_Ref, le> tmp;
      tmp.insert(*its);
      if(answer(tmp))
	return (*its)->cid;
    }
    return 0;
  }

  virtual ~Reached(){}
};


/**
 * class ReachedOnlyOne
 * ReachedOnlyOne answers if a constraint: 
 *  "s.p.c.c.p.c.c.p.c.c" has reached the subject upward
 */
template<class le=EntailmentOrder<Constraint_Ref> >
class ReachedOnlyOne: public Reached<le>
{
 public:
  ReachedOnlyOne(const Clause& _clause, const Dbm& _dbm):
    clause(_clause), dbm(_dbm),threshold(0){} 

    bool answer(const MinSet<Constraint_Ref, le>& subject) {
      typename MinSet<Constraint_Ref, le>::const_iterator its=subject.begin();
      for(; its!=subject.end(); ++its)
	{
	  assert(!(*its)->is_empty());
	
	  /*if( (*its)->cardinal()>=4 ){
	    return true;
	    }*/

	  int c=(*its)->cardinal();
	  for(int i=threshold+1; i<=c; i++)
	    initials.push_back(Constraint::get_initial(clause, dbm, i));
	  threshold=(threshold>=c? threshold:c);

	  //	  if( (*its)->entailed(initials[c-1]) ){
	  bool nedbm=!(((*its)->dbm)&(initials[c-1]->dbm)).is_empty();
	  bool neclause=!((*its)->clause & initials[c-1]->clause).is_empty();
	  if( (Constraint::pure_bounded | nedbm) & (Constraint::pure_unbounded | neclause) )
	    {
	      //	      cout << "non empty intersection !!" << endl;
	      //cout << (*its)->dbm << endl;
	      //cout << (*its)->clause << endl;
	      //assert(false);
	      return true;
	    }
	}
      return false;
    };
  
 private:
    Clause clause;
    Dbm dbm;
    int threshold;
    std::vector<Constraint_Ref> initials;
};


template<class le=EntailmentOrder<Constraint_Ref> >
class Next
  {
    public:
    void add(const Rule_Ref& rule){rules.push_back(rule);}

    MinSet<Constraint_Ref, le> compute(const MinSet<Constraint_Ref, le>& sset, bool same) const{
      MinSet<Constraint_Ref, le> result;
      typename MinSet<Constraint_Ref, le>::const_iterator ssetit=sset.begin(), ssetend=sset.end();
      for(; ssetit!=ssetend; ++ssetit){
	MinSet<Constraint_Ref, le> intermidiate=compute(*ssetit, same);
	result.insert(intermidiate.begin(), intermidiate.end());
      }
      return result;
    }

    virtual MinSet<Constraint_Ref, le> compute(const Constraint_Ref&, bool) const=0;

    virtual ~Next(){}

    protected:
    std::vector<Rule_Ref> rules;
  };

class UpwardPre: public Next<EntailmentOrder<Constraint_Ref> >
{
 public:
  UpwardPre(){}

  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > compute(const Constraint_Ref& constraint, bool same) const{
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > result, tmp;

    std::vector<Rule_Ref>::const_iterator rulesit=rules.begin(), rulesend=rules.end();
    for(; rulesit!=rulesend; ++rulesit){
      tmp=(*rulesit)->compute(constraint, same);
      result.insert(tmp.begin(), tmp.end(), false);
    }
    return result;
  }

  friend std::ostream& operator<< (std::ostream& out, const UpwardPre&);
};


inline std::ostream& operator<< (std::ostream& out, const UpwardPre& next)
{

  std::vector<Rule_Ref>::const_iterator it;
  for(it=next.rules.begin(); it!=next.rules.end();++it){
    out << std::endl << **it << std::endl;
  }
  return out;
}


#endif
