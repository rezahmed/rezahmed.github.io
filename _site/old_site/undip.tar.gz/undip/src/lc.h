/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file lc.h
 * Header for LC
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_LC_H
#define _UNDIP_LC_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <map>

#include "ref.h"
#include "order.h"
#include "minset.h"
#include "dbm.h"
#include "clause.h"
#include "constraint.h"
#include "cipher.h"
#include "action.h"
#include "actions_sequence.h"
#include "rule.h"

using namespace std;

/** Brief Specialized Transitions for Getting Globally.  
 *  Updates the firing process and a channel, whose sender may eventually, 
 *  be created together with its channels with the other processes. The values
 *  of the firing process and of the channel are to verify and to be updated
 *  according to the list of dbms.
 */
class LC: public Rule
{
 

/* 
 */
  int action_to_working(int i, int uatv, int usegment, int ucs)const;


 /* Get the constraint to the working dbm.
  *
  */  
 int constraint_to_working(int i, int ucs, int uatv) const;
 
 /* Easy check to save time in case transitions disabled.
  *
  */
 bool check_satisfiable(int at, int batv, int uatv, const Constraint_Ref& cstr) const;

 public:
/** Brief Construct a Specialized Transition for Sending Globally.
 *  
 */
  LC(const Actions_Sequence & _sequence);
  
  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > fire_position(const Constraint_Ref&, int, bool) const;

 protected:
  void printOn(ostream& o) const;

 private:
  Actions_Sequence bsequence, usequence;

  set<int> bounded_modified, unbounded_modified;

  Actions_Sequence bounded_guard, unbounded_guard;

  map<int, int> modification;

};



#endif

