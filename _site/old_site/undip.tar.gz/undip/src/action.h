/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file action.h
 * trivial implementation of a printable pair<int,int>
 *
 * @author Rezine Ahmed
 */

#ifndef DBS_ACTION_H
#define DBS_ACTION_H


#include <utility>
#include <iostream>

#include "cipher.h"
#include "dbm.h"

class Action
{

 public:

  Action(Cipher _key, Dbm _value): key(_key), value(_value){assert(value.vars_card()==1);}

    Action(Dbm _value, int _index1,int _index2, bool _bounded): 
      key(_index1, _index2, _bounded), value(_value){assert(value.vars_card()==1);}

    Dbm get_dbm()const{return value;}

    Cipher get_cipher()const{return key;}

  friend std::ostream& operator<< (std::ostream& out, 
				   const Action& action);
 private:
  Cipher key;
  Dbm value;
};


inline std::ostream& operator<< (std::ostream& out, 
				 const Action& action)
{
  return out << action.get_cipher() << std::endl << action.get_dbm() ;
}



#endif
