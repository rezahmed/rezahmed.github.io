
/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

#ifndef _UNDIP_CONFEDERATION_H
#define _UNDIP_CONFEDERATION_H

#include <iostream>
#include <list>


#include "dbm.h"
#include "federation.h"
#include "clause.h"
#include "dpclause.h"

#include "constraint.h"

//#define DEBUG_CONFEDERATION_CONSTRUCTOR
//#define DEBUG_OPERATOR_MINUS


using namespace std;

class Confederation;

class ConfederationConstIterator
{

 public :

  ConfederationConstIterator(list<pair<DPClause, Federation> >::const_iterator _constit, 
			     list<pair<DPClause, Federation> >::const_iterator _constit_end):
    constit(_constit), constit_end(_constit_end)
    {
      if(constit!=constit_end)
	{
	  if(!Constraint::pure_bounded){
	    assert(constit->second.begin()!=constit->second.end());
	    FEDit=constit->second.begin();
	  }
	  if(!Constraint::pure_unbounded){
	    assert(constit->first.begin()!=constit->first.end());
	    DPCit=constit->first.begin();
	  }
	}
    }
    

  bool operator==(ConfederationConstIterator other)const
  {
    if(constit!=other.constit) return false;
    if(constit==constit_end) return true;
    if(!Constraint::pure_unbounded)
      if(DPCit!=other.DPCit) return false;
    if(!Constraint::pure_bounded)
      if(FEDit!=other.FEDit) return false;
    return true;
  }


  bool operator!=(ConfederationConstIterator other)const 
  {
    return !((*this)==other);
  }
  


  bool operator++(int count)
  {
    bool end=false;

    for(int i=1; i<=count & !end; ++i)
      end=!operator++();

    return !end;
  }


  bool operator++()
  {
    if(constit==constit_end)
      return false;

    if(Constraint::pure_unbounded)
      {
	assert(FEDit!=constit->second.end());
	++FEDit;
	if(FEDit!=constit->second.end())
	  return true;
	++constit;
	assert(constit==constit_end);
	return false;
      }
    else 
      if(Constraint::pure_bounded)
	{
	  assert(DPCit!=constit->first.end());
	  ++DPCit;
	  if(DPCit!=constit->first.end())
	    return true;
	  ++constit;
	  assert(constit==constit_end);
	  return false;
	}
      else
	{
	  assert(FEDit!=constit->second.end());
	  ++FEDit;
	  if(FEDit!=constit->second.end())
	    return true;
	  assert(DPCit!=constit->first.end());
	  ++DPCit;
	  if(DPCit!=constit->first.end()){
	    FEDit=constit->second.begin();
	    return true;
	  }
	  ++constit;
	  if(constit==constit_end)
	    return false;
	  DPCit=constit->first.begin();
	  FEDit=constit->second.begin();
	  assert(DPCit!=constit->first.end()
		 && FEDit!=constit->second.end());
	}

    return true;
  }

  pair<Clause, Dbm> operator*() const
    {
      assert(constit!=constit_end);
      if(Constraint::pure_unbounded){
	assert(FEDit!=constit->second.end());
	return pair<Clause, Dbm> (Clause(), *FEDit);
      }
      else
	if(Constraint::pure_bounded){
	  assert(DPCit!=constit->first.end());
	  return pair<Clause, Dbm> (*DPCit, Dbm());
	}
	else{
	  assert(DPCit!=constit->first.end());
	  assert(FEDit!=constit->second.end());
	  return pair<Clause, Dbm> (*DPCit, *FEDit);
	}
    }

  friend class Confederation;
  
 private:
  
  list<pair<DPClause, Federation> >::const_iterator constit;  
  list<pair<DPClause, Federation> >::const_iterator constit_end;  
  DPClause::const_iterator DPCit;
  Federation::const_iterator FEDit;
};

class Confederation
{

 public:
  Confederation(){}
  
  Confederation(const Clause& _clause, const Dbm& _dbm)
    {
#ifdef DEBUG_CONFEDERATION_CONSTRUCTOR
      cout << "confederation construct: input clause :";
      if(_clause.is_empty())
	cout << "{}" << endl;
      else
	cout << _clause ;
      cout << "confederation construct: input Dbm    :";
	if(_dbm.is_empty())
	  cout << "{}" << endl;
	else
	  cout << _dbm ;
#endif
      if(Constraint::pure_unbounded){
	assert(!_dbm.is_empty());
	store.push_back(pair<DPClause, Federation>(DPClause(), Federation(_dbm)));
      }
      else
	if(Constraint::pure_bounded){
	  assert(!_clause.is_empty());
	  store.push_back(pair<DPClause, Federation>(DPClause(_clause), Federation()));
	}
	else{
	  assert(!_clause.is_empty() & !_dbm.is_empty());
	  store.push_back(pair<DPClause, Federation>(DPClause(_clause), Federation(_dbm)));
	}
    }

  ConfederationConstIterator begin() const 
  {
    return   ConfederationConstIterator::ConfederationConstIterator(store.begin(),store.end());
  }
  
  ConfederationConstIterator end() const 
  {
    return ConfederationConstIterator::ConfederationConstIterator(store.end(),store.end());
  }
  
  bool is_empty() const {
    return store.empty();
  }
  

  /**
   * for each pair (dpc,fed) in store
   *   for the pair (oc,od) in other.store
   *     add (dpc-oc,fed) to result
   *     add (dpc,fed-od) to result
   **/
  Confederation operator-(const pair<Clause, Dbm>& other) const 
  {

#ifdef DEBUG_OPERATOR_MINUS
    cout << endl 
	 << "confederation - : input this          :" << *this ;
    cout << "confederation - : input clause :";
    if(other.first.is_empty())  cout << "{}" << endl;
    else cout << other.first << endl;
    cout << "confederation - : input Dbm    :";
    if(other.second.is_empty())  cout << "{}" << endl;
    else  cout << other.second << endl;
#endif

    if(is_empty() | (other.first.is_empty() & other.second.is_empty())){
#ifdef DEBUG_OPERATOR_MINUS
      cout << "confederation - : output this because empty pair " << endl;
#endif
      return *this;
    }
    
    Confederation result;

    list<pair<DPClause, Federation> >::const_iterator it;

    for(it=store.begin(); it!=store.end(); ++it)
      {
	DPClause dpcD;
	if(!Constraint::pure_unbounded)
	  dpcD = it->first - other.first;

	Federation fedD;
	if(!Constraint::pure_bounded)
	  fedD = it->second - other.second;
    
	if(!dpcD.is_empty())
	  result.store.push_back(pair<DPClause, Federation>(dpcD, it->second));
	
	if(!fedD.is_empty())
	  result.store.push_back(pair<DPClause, Federation>(it->first, fedD));
      }

#ifdef DEBUG_OPERATOR_MINUS
      cout << "confederation - : output           :" << result ;
#endif

    return result;
  }
  
  friend ostream& operator<< (ostream& out, const Confederation& fd);

  friend class ConfederationConstIterator;
    
 private:
  list<pair<DPClause, Federation> > store;
};


inline ostream& operator<< (ostream& out, const Confederation& fd)
{
  out << endl << "*********************{ " << endl;
  for(ConfederationConstIterator dpit=fd.begin(); dpit!=fd.end(); ++dpit){
    out << "----------------" << endl;
    if(!Constraint::pure_unbounded) out << (*dpit).first ;
    if(!Constraint::pure_bounded)   out << (*dpit).second;
    out << "----------------" << endl;
  }
  out << "}*********************" << endl;
  
  return out;
}

#endif
