/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file lc.cc
 * implementation of a LC
 *
 * @author Rezine Ahmed
 */

#include "lc.h"
#include <iterator>

//#define DEBUG_LC_CONSTRUCT
//#define DEBUG_FIRE_LC
//#define DEBUG_CHANNEL_VALIDITY
//#define DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
//#define DEBUG_FIRE_POSITION_INSERTED_WITNESS


LC::LC(const Actions_Sequence& _sequence)
{
  rid=++rcounter;

  for(Actions_Sequence::const_iterator it=_sequence.begin(); 
      it!=_sequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    if(it->get_cipher().is_bounded())
      bsequence.add(*it);
    else
      usequence.add(*it);
  }

#ifdef DEBUG_LC_CONSTRUCT
  cout << "LC constructor % input id: " << rid << endl;
  cout << "LC constructor % input bsequence: " << bsequence;
  cout << "LC constructor % input usequence: " << usequence;
#endif

  //first, bonded part
  int bs=Constraint::bs, bp=Constraint::bp;
  int bsegment=bs+bp;

  //collect the modified bounded variables
  for(Actions_Sequence::const_iterator it=bsequence.begin(); 
      it!=bsequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    assert(i==0 | j==0);
    assert(i!=j & i<=2*bsegment & j<=2*bsegment);
    int index=(i==0 ? j: i);
    if(0<index-bsegment)
      bounded_modified.insert(index-bsegment);
  }
  // collect the guards
  for(Actions_Sequence::const_iterator it=bsequence.begin(); 
      it!=bsequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    int index=(i==0? j: i);
    numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
    numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
    if(bsegment < index)
      bounded_guard.add(*it);
    else 
      if(bounded_modified.find(index)==bounded_modified.end())
	bounded_guard.add(*it);
  }
  
#ifdef  DEBUG_LC_CONSTRUCT
  cout << "SDC constructor % bounded modified      : "; 
  copy(bounded_modified.begin(), bounded_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % bounded guard : " << endl 
       << bounded_guard << endl; 
#endif

  // Second, the unbounded case.
  int us=Constraint::us, up=Constraint::up;
  int usegment=us+up;
  
  for(Actions_Sequence::const_iterator it=usequence.begin(); 
      it!=usequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    if(0<i-usegment)
      unbounded_modified.insert(i-usegment);
    if(0<j-usegment)
      unbounded_modified.insert(j-usegment);
  }
  
  //fix encoding for modified unbounded variables
  set<int>::const_iterator mit;
  int incrementer=1;
  for(mit=unbounded_modified.begin(); 
      mit!=unbounded_modified.end(); ++mit, ++incrementer)  
    modification[*mit]=incrementer;  

  // collecting the guards for the unbounded variables
  for(Actions_Sequence::const_iterator it=usequence.begin(); 
      it!=usequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    // is the variable a constant, a shared or a process variable that is either
    // modified in this action, or not modified in any action?
    bool shared_firing_guard_i=(i==0 | (usegment<i & i<=usegment+us+up) | 
				(i<=us+up & modification.find(i)==modification.end()));
    bool shared_firing_guard_j=(j==0 | (usegment<j & j<=usegment+us+up) | 
				(j<=us+up & modification.find(j)==modification.end()));
    if(shared_firing_guard_i & shared_firing_guard_j)
      unbounded_guard.add(*it);
  }

#ifdef  DEBUG_LC_CONSTRUCT
  cout << "SDC constructor % unbounded modified set: " ;
  copy(unbounded_modified.begin(), unbounded_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "SDC constructor % unbounded_guard: " << endl << endl
       << unbounded_guard << endl;
#endif
  
}

MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > LC::fire_position(const Constraint_Ref& cstr, int at, bool same) const
{//fire position
  
  assert(cstr);
  assert(1<=at & at<=cstr->cardinal());
    
#ifdef DEBUG_FIRE_LC
  cout << endl 
	    << "fire_LC% input at: " << at << endl 
	    << "fire_LC% input c: " << *cstr << endl
	    << "fire_LC% input r: " << rid << endl;
#endif

    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > result_min_set;

  if(!same | cstr->is_empty() | !cstr->is_process_old(at)){
#ifdef DEBUG_FIRE_SDC
    cout << "fire_SDC% output : empty input, result doomed to entail the input ! "<< endl ;
#endif
    return result_min_set;
  }
  
  int cn=cstr->cardinal();//number of processes in cstr

  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp;
  int batv=bs+(at-1)*(bp+(cn-1)*bc);//begining of process "at"'s bounded variables 

  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up;
  int uatv=us+(at-1)*(up+(cn-1)*uc);//begining of process "at"'s unbounded variables 
  
  if(!check_satisfiable(at, batv, uatv, cstr)){
#ifdef DEBUG_FIRE_SDC
    cout << "fire_SDC% output : rule not enabled ! "<< endl ;
#endif
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > phi;
    return phi;
  }

  bool valid_untill_now=true;

  Clause  working_clause=cstr->clause;
  if(!Constraint::pure_unbounded){
    // relax the modified variables
    set<int>::const_iterator mit;
    for(mit=bounded_modified.begin(); mit!=bounded_modified.end(); ++mit) 
      if(*mit<=bs)
	working_clause.modify(*mit, Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
      else
	working_clause.modify(batv+*mit-bs, Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
    
    // tighten whatever variable that was not modified, or is predecessor 
    // of a modified variable
    for(Actions_Sequence::const_iterator it=bsequence.begin(); 
	it!=bsequence.end() & valid_untill_now; ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));

	if(index<=bs)	
	  {if(!working_clause.tighten(index, nlb, ub)) valid_untill_now=false;}
	else if(index<=bsegment)
	  {if(!working_clause.tighten(batv+index-bs, nlb, ub)) valid_untill_now=false;}
      }
  
#ifdef DEBUG_FIRE_LC
    cout << "fire lc % obtained clause :  " << working_clause << endl;
#endif 
  }

  Dbm  working_dbm(cstr->dbm.vars_card()+modification.size());

  if(!Constraint::pure_bounded & valid_untill_now){
    //copy the constraint. send the modified values according to modification.
    for(int i=0; i<=cstr->dbm.vars_card(); ++i){
      int bi=constraint_to_working(i, cstr->dbm.vars_card(), uatv);
      for(int j=i+1; j<=cstr->dbm.vars_card(); ++j){
	int bj=constraint_to_working(j, cstr->dbm.vars_card(), uatv);
	working_dbm.put(bi, bj, cstr->dbm.get(i,j));
	working_dbm.put(bj, bi, cstr->dbm.get(j,i));
      }
    }
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion % after copying constraint : " << working_dbm << endl ;
#endif
    // Get the bounds to the newly created variables 
    set<int>::const_iterator mit;
    for(mit=unbounded_modified.begin(); mit!=unbounded_modified.end() & valid_untill_now; ++mit)
      if(*mit<=us)
	{if(!working_dbm.tighten(0,*mit,Constraint::Ub.gnlb(*mit)))  valid_untill_now=false;}
      else
	{if(!working_dbm.tighten(0,uatv+*mit-us,Constraint::Ub.gnlb(*mit)))  valid_untill_now=false;}

    // Finally apply the sequence of actions
    for(Actions_Sequence::const_iterator it=usequence.begin(); 
	it!=usequence.end() & valid_untill_now; ++it)
      { //for each action
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
	cout << "fire no insertion % considering action : " << *it << endl;
#endif   
	int i=it->get_cipher().first(), j=it->get_cipher().second();

	int wi=action_to_working(i, uatv, usegment, cstr->dbm.vars_card()); // in working dbm
	int wj=action_to_working(j, uatv, usegment, cstr->dbm.vars_card());

	if(!working_dbm.tighten(wi,wj,it->get_dbm().get(0,1)) 
	   | !working_dbm.tighten(wj,wi,it->get_dbm().get(1,0)))
	  valid_untill_now=false;
      }
    
    working_dbm=working_dbm.project_away(cstr->dbm.vars_card()+1, cstr->dbm.vars_card() 
					 + modification.size());
    
#ifdef DEBUG_FIRE_LC
    cout << "fire lc % obtained dbm : " << working_dbm << endl ;
#endif    
  }

  
  if(!(working_clause.is_empty() & !Constraint::pure_unbounded) 
     & !(working_dbm.is_empty() & !Constraint::pure_bounded)){//if result non empty
    Constraint_Ref cstr_result(new Constraint(working_clause, working_dbm, cn));
    cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
    cstr_result->copy_status(cstr);
    cstr_result->set_process_old(at);
    if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_LC
      cout << "fire_LC% which is entailed by the constraint: " << endl ;
#endif
    }
    else
      result_min_set.insert(cstr_result);
  }
  
  return result_min_set;
}

bool LC::check_satisfiable(int at, int batv, int uatv, const Constraint_Ref& cstr) const
{
  if(!Constraint::pure_unbounded){
    // First, the bounded case
    int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
    int bsegment=bs+bp;
    for(Actions_Sequence::const_iterator it=bounded_guard.begin(); 
	it!=bounded_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
	int r=0;
	if(index<=bs)	r=index;
	else if(index<=bsegment) r=index-bs+batv;
	else if(index<=bsegment+bs) r=index-bsegment;
	else if(index<=bsegment+bsegment) r=index-bsegment-bs+batv;
	else assert(false);
      
	if(ub+cstr->clause.gnlb(r)<=numb(-1)
	   | nlb+cstr->clause.gub(r)<=numb(-1) )
	  return false;
      }
  }
  if(!Constraint::pure_bounded){
    //Second, the unbounded part
    int us=Constraint::us, up=Constraint::up, uc=Constraint::uc; 
    int usegment=us+up;
    for(Actions_Sequence::const_iterator it=unbounded_guard.begin(); 
	it!=unbounded_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int ri=0,rj=0;
      
	if(i<=us)  ri=i;
	else if(i<=usegment) ri=i-us+uatv;
	else if(i<=usegment+us) ri=i-usegment;
	else if(i<=usegment+usegment) ri=i-usegment-us+uatv;
	else assert(false);
      
	if(j<=us)	rj=j;
	else if(j<=usegment)  rj=j-us+uatv;
	else if(j<=usegment+us) rj=j-usegment;
	else if(j<=usegment+usegment) rj=j-usegment-us+uatv;
	else assert(false);
      
	if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1)
	   | it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1) )
	  return false;
      }
  }
  return true;
}


inline int LC::constraint_to_working(int i, int ucs, int uatv) const
{
  if(i<=Constraint::us) 
    if(unbounded_modified.find(i)!=unbounded_modified.end()) return ucs+modification.find(i)->second;
    else return i;
  else
    if(uatv<i & i<=uatv+Constraint::up) 
      if(modification.find(Constraint::us+i-uatv)!=modification.end())
	return ucs+(modification.find(Constraint::us+i-uatv)->second);
      else return i;
    else return i;
}



/* 
 */
inline int LC::action_to_working(int i, int uatv, int usegment, int ucs)const
{
  if(i<=Constraint::us)  return i; 
  else  if(i<=usegment) return uatv+i-Constraint::us; 
  else  return ucs+(modification.find(i-usegment)->second); 
}


void LC::printOn(ostream& o) const
{

#ifdef PRINT_PROCESS_CHANNEL

#else
  cout << "LC id: " << rid << endl;
  cout << "LC bsequence: " << bsequence << endl;
  cout << "LC bounded_process_guard : " << bounded_guard << endl;
  cout << "LC usequence: " << usequence << endl;
  cout << "LC unbounded_guard : " << unbounded_guard << endl;
#endif  
}








