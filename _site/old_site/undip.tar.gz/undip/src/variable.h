/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file variable.h
 * Header for variable
 *
 * @author Rezine Ahmed
 */

#ifndef DBS_VARIABLE_H
#define DBS_VARIABLE_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>

#include "numb.h"

typedef enum {shared, channel, process,
	      bounded_shared, bounded_process, bounded_channel, 
	      unbounded_shared, unbounded_process, unbounded_channel, 
	      denomination} v_type;

class Variable 
{

 public:
  
  friend std::ostream& operator<< (std::ostream& out, const Variable& v);

  Variable(){}

  Variable(v_type _type, numb _nmin, numb _max, int _position):type(_type), nmin(_nmin), max(_max), position(_position){}

 public:
  v_type type;
  numb    nmin;
  numb    max;
  int    position;
};



inline std::ostream& operator<< (std::ostream& out, const Variable& v)
{
  
  if(v.type==shared) out << "s:" ;
  else if(v.type==process) out << "p:" ;
  else if(v.type==channel) out << "c:";
  else if(v.type==bounded_shared) out << "bs:" ;
  else if(v.type==bounded_process) out << "bp:" ;
  else if(v.type==bounded_channel) out << "bc:";
  else if(v.type==unbounded_shared) out << "us:" ;
  else if(v.type==unbounded_process) out << "up:" ;
  else if(v.type==unbounded_channel) out << "uc:";
  else if(v.type==denomination) out << "d:";

  out << "[" << v.nmin << ", " << v.max << "]";

  return out;
}

#endif
