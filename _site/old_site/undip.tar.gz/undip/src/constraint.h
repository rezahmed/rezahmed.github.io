/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file constraint.h
 * Header for constraint
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_CONSTRAINT_H
#define _UNDIP_CONSTRAINT_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include <list>
#include <set>

#include "ref.h"
#include "dbm.h"
#include "clause.h"
#include "numb.h"
#include "current_indices.h"

//#include <string>
//#include <map>
//#include "variable.h"

using namespace std;
 
class Constraint;

typedef Ref<Constraint> Constraint_Ref;

typedef enum{old, cnew} status;

//typedef map<string, int> enumeration;

class Constraint
{
 public:
  
  // a constraint is always a conjunction of bounded differences
  // We keep only information of the form "a<=x<=b" for finite variables.
  // This way we diminish the size of the dbm which only keeps track of the 
  // unbounded variables.
  Constraint(const Clause& _clause, const Dbm& _dbm, int _n);

  bool is_empty() const;

  int cardinal() const { return n;  }

  bool simple_check(int process,int channel, const Constraint_Ref& other, 
		    int oprocess, int ochannel) const;

  bool simple_half(int m, const Constraint_Ref& other, 
		   const current_indices& current) const;
  
  bool cross_check(int vp,int vc, int hp, int hc, const Constraint_Ref& other, 
		   int ovp, int ovc, int ohp, int ohc) const;
  
  bool half_check(int m, const Constraint_Ref& other, 
		  const current_indices& current) const;

  bool entailed(const Constraint_Ref&) const;
  
  Constraint_Ref insert_process_before(int position)const;


  friend ostream& operator<< (ostream& out, const Constraint& constraint);


  static Constraint_Ref get_initial(const Clause& intial_clause, 
				    const Dbm& initial_dbm, int n);

  static int bs, bp, bc; // number of bounded shared, process and channel variables per system
  static Clause Bb;      // defines the negated_lower/upper boundaries of the variables

  static int us, up, uc; // number of potentially unbounded shared, process and channel variables
  static Clause Ub;      // defines the negated_lower/upper boundaries of the potentially unbounded variables

  static bool pure_bounded, pure_unbounded;
  static int ccounter;

  static vector<string> BVarNames, UVarNames; //variable naming

  //  static map<string, pair<Variable, enumeration> > namesRepository;

  Dbm dbm;       //conjunction of bounds on differences between unbounded variables
  Clause clause; //conjunction of bounds on differences between unbounded variables
  int n;         // number of processes

  int bl, bu, ul; // sum over bounded deltas

  //static int total_entailments, other_is_empty, 
  //  this_is_empty, mlessn, deltaless, within;

  /* 
   * Used to keep track of which process/channel is new.
   * If all processes/channels involved in a transition are new, 
   * then there is no need to fire the transition, since the 
   * obtained constraint is guaranteed to entail the original one.
   */
  vector<status> creation_status;
  void copy_status(const Constraint_Ref& cstr);
  void copy_status_and_create(const Constraint_Ref& cstr, int at);
  void set_process_old(int p);
  void set_channel_old(int from, int to);
  void set_sender_and_channels_old(int p);
  void set_sender_and_incoming_channels_old(int at);
  void set_process_new(int p);
  bool is_sender_or_one_of_channels_old(int p) const;
  bool is_sender_or_one_of_io_channels_old(int p) const;
  bool is_one_of_processes_old() const;
  bool is_sender_or_channel_old(int sender, int receiver) const;
  bool is_sender_or_io_channel_old(int sender, int receiver) const;
  bool is_process_old(int p) const;
  bool is_receiver_or_channel_old(int sender, int receiver) const;
  bool is_receiver_or_one_of_channels_old(int p) const;


  // Variable encondings
  // bounded

  //tracking data
  void set_bookmark(int _id, int _parent_id, int _rule_id, int _position);
  int cid;   //unique identifier
  int cpid;  //obtained from constraint parent_id
  int crid;  //by firing action_id
  int cpos;  //at position  
};



inline ostream& operator<< (ostream& out, const Constraint& constraint)
{



  int n=constraint.cardinal();
  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int printed=0;

  out << endl 
      << "******" << endl 
      << "[" << n<<"][id=" << constraint.cid << ", pid=" << constraint.cpid << ", rid=" 
      << constraint.crid << ", pos=" << constraint.cpos << "]:" << endl;
  
#if 0
  out << endl << "dbm ";
  if(constraint.dbm.is_empty())
    out << "{}" << endl;
  else
    out << constraint.dbm;
  out << endl << "clause ";
  if(constraint.clause.is_empty())
    out << "{}" << endl;
  else
    out << constraint.clause;

  //  out << endl << "delta " << constraint.delta << endl;
  /*  out << endl 
      << "total_entailments:" << Constraint::total_entailments 
      << ", other_is_empty:" << Constraint::other_is_empty 
      << ", this_is_empty:" << Constraint::this_is_empty
      << ", mlessn:" << Constraint::mlessn
      << ", deltaless:" <<  Constraint::deltaless
      << ", within:" << Constraint::within 
      << endl;*/

  out << "status (old/new): ";
  for(unsigned i=0; i<constraint.creation_status.size(); i++)
    if(constraint.creation_status[i]==old)
      out << " o" ;
    else
      if(constraint.creation_status[i]==cnew)
	out <<" n";
      else
	assert(false);
  out <<endl 
      << "******" << endl;
   
  return out;

#else

  int process, channel, var;
  
  
  if(!Constraint::pure_unbounded){
    //bounded
    for(unsigned b=1; b<=constraint.clause.vars_card(); b++) 
      {
	if(b<=Constraint::bs)
	  {var=b; process=0; channel=0;}
	else{
	  process=(b-Constraint::bs-1)/(Constraint::bp+(n-1)*Constraint::bc)+1;
	  var=(b-Constraint::bs-1)%(Constraint::bp+(n-1)*Constraint::bc);
	  if(var<Constraint::bp){
	    ++var;
	    channel=process;
	  }
	  else{
	    channel=(var-Constraint::bp)/(Constraint::bc)+1;
	    if(process<=channel)
	      ++channel;
	    var=(var-Constraint::bp)%(Constraint::bc)+1;
	  }
	}	    
      
	if(process==0){
	  if(constraint.clause.gnlb(b)<Constraint::Bb.gnlb(var)
	     | constraint.clause.gub(b)<Constraint::Bb.gub(var))
	    {
	      char buf[4]; memset(buf, '\0',4);
	      assert(1<=var & var<=Constraint::bs);
	      (Constraint::BVarNames[var-1]).copy(buf,3);
	      out << buf << "[" << constraint.clause.gnlb(b) << "," << constraint.clause.gub(b) << "], ";
	    }
	}
	else
	  if(process==channel){
	    if(constraint.clause.gnlb(b)<Constraint::Bb.gnlb(Constraint::bs+var)
	       | constraint.clause.gub(b)<Constraint::Bb.gub(Constraint::bs+var))
	      {
		char buf[4]; memset(buf, '\0',4);
		assert(1<=var & var<=Constraint::bp);
		(Constraint::BVarNames[var+Constraint::bs-1]).copy(buf,3);
		out << buf << process << left << "[" << constraint.clause.gnlb(b) 
		    << "," << constraint.clause.gub(b) << "], ";		
	      }
	  }
	  else
	    if(process!=channel){
	      if(constraint.clause.gnlb(b)<Constraint::Bb.gnlb(Constraint::bs+Constraint::bp+var)
		 | constraint.clause.gub(b)<Constraint::Bb.gub(Constraint::bs+Constraint::bp+var))
		{
		  char buf[4]; memset(buf, '\0',4);
		  assert(1<=var & var<=Constraint::bc);
		  (Constraint::BVarNames[var+Constraint::bp+Constraint::bs-1]).copy(buf,3);
		  out << buf << process << channel << left << "[" << constraint.clause.gnlb(b) << "," << constraint.clause.gub(b) << "], ";
		}
	    }
      }
    
    out << endl;
  }

  if(!Constraint::pure_bounded){
    for(unsigned b=0; b<=constraint.dbm.vars_card()+1; b++) 
      out << "|------" ;
    out << "|" << endl;
    
    out << "|   *  |  0   " ;
    for(unsigned b=1; b<=constraint.dbm.vars_card(); b++) 
      {

	if(b<=Constraint::us)
	  {var=b; process=0; channel=0;}
	else{
	  process=(b-Constraint::us-1)/(Constraint::up+(n-1)*Constraint::uc)+1;
	  var=(b-Constraint::us-1)%(Constraint::up+(n-1)*Constraint::uc);
	  if(var<Constraint::up){
	    ++var;
	    channel=process;
	  }
	  else{
	    channel=(var-Constraint::up)/(Constraint::uc)+1;
	    if(process<=channel)
	      ++channel;
	    var=(var-Constraint::up)%(Constraint::uc)+1;
	  }
	}	    
	
	if(process==0){
	  char buf[6]; memset(buf, '\0',6);
	  int copied=(Constraint::UVarNames[var-1]).copy(buf,3); string left(5-copied,' ');
	  out << "| " << buf << left ;
	}
	else
	  if(process==channel){
	    char buf[6]; memset(buf, '\0',6);
	    int copied=(Constraint::UVarNames[var+Constraint::us-1]).copy(buf,3); string left(4-copied,' ');
	    out << "| " << buf << process << left;
	  }
	  else
	    if(process!=channel){
	      char buf[6]; memset(buf, '\0',6);
	      int copied=(Constraint::UVarNames[var+Constraint::up+Constraint::us-1]).copy(buf,3); string left(3-copied,' ');
	      out << "| " << buf << process << channel << left; 
	    }
      }
    out << "|" << endl;
    
    for(unsigned b=0; b<=constraint.dbm.vars_card()+1; b++) 
      out << "|------" ;
    out << "|" << endl;
    
    
    out << "|   0  |  *   " ;
    for(unsigned b=1; b<=constraint.dbm.vars_card(); b++) 
      if(constraint.dbm[0][b].inf)
	out << "|      ";
      else{
	stringstream ss; ss << constraint.dbm[0][b].value;
	char buf[5]; memset(buf, '\0',5);
	int copied=(ss.str()).copy(buf,3); string left(4-copied,' ');
	out << "|  " << buf << left; 
      }
    out << "|" << endl;
    for(unsigned b=0; b<=constraint.dbm.vars_card()+1; b++) 
      out << "|------" ;
    out << "|" << endl;
    
    for(unsigned c=1; c<=constraint.dbm.vars_card(); c++){

	if(c<=Constraint::us)
	  {var=c; process=0; channel=0;}
	else{
	  process=(c-Constraint::us-1)/(Constraint::up+(n-1)*Constraint::uc)+1;
	  var=(c-Constraint::us-1)%(Constraint::up+(n-1)*Constraint::uc);
	  if(var<Constraint::up){
	    ++var;
	    channel=process;
	  }
	  else{
	    channel=(var-Constraint::up)/(Constraint::uc)+1;
	    if(process<=channel)
	      ++channel;
	    var=(var-Constraint::up)%(Constraint::uc)+1;
	  }
	}	    

      if(process==0){
	char buf[6]; memset(buf, '\0',6);
	int copied=(Constraint::UVarNames[var-1]).copy(buf,3); string left(5-copied,' ');
	out << "| " << buf << left ;
      }
      else
	if(process==channel){
	  char buf[6]; memset(buf, '\0',6);
	  int copied=(Constraint::UVarNames[var+Constraint::us-1]).copy(buf,3); string left(4-copied,' ');
	  out << "| " << buf << process << left;
	}
	else
	  if(process!=channel){
	    char buf[6]; memset(buf, '\0',6);
	    int copied=(Constraint::UVarNames[var+Constraint::up+Constraint::us-1]).copy(buf,3); string left(3-copied,' ');
	    out << "| " << buf << process << channel << left; 
	  }
      
      for(unsigned b=0; b<=constraint.dbm.vars_card(); b++) 
	if(c==b)
	  out << "|  *   ";
	else
	  if(constraint.dbm[c][b].inf)
	    out << "|      ";
	  else{
	    stringstream ss; ss << constraint.dbm[c][b].value;
	    char buf[5]; memset(buf, '\0',5);
	    int copied=(ss.str()).copy(buf,3); string left(4-copied,' ');
	    out << "|  " << buf << left; 
	  }
      out << "|" << endl;
      
      for(unsigned b=0; b<=constraint.dbm.vars_card()+1; b++) 
	out << "|------" ;
      out << "|" << endl;
    }
  }
  
  return out;
#endif
}    



#endif
