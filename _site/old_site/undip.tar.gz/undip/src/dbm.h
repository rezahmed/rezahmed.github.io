

/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/


#ifndef _DBM_H

#define _DBM_H

#include <iostream>
#include <assert.h>
#include <vector>

#include "numb.h"

#define DEBUG_NEQUAL

/** Brief Toggle matrice/formula print of the difference bound matrice (dbm).
 */
#define MATRICE_PRINT


//extern int sv;
//extern int pv;
//extern int cv;

/** Brief Difference Bound Matrice (dbm) implementation.
 * A Difference Bound Matrice is the conjunction of formulas
 * representing upper bounds on binary differences between
 * variables. Each cell (a_ij) is to be understood as 
 * "di-dj<=a_ij". The variable d0 is always equal to 0.
 */
class Dbm : public std::vector<std::vector<numb> >
{

 public:
  /* Brief Default constructor, build empty closed dbm.
   * An empty dbm is a dbm that does not enclose any 
   * variable. We assume the dbm equals False.
   * A closed dbm is a normalized one.
   */
  Dbm(): cardinal(0), closed(true), empty(true){
    std::vector<numb> v(1, numb());
    push_back(v);
  }

  /* Brief Constructor with "s" variables, build closed dbm.
   * \param s number of variables.
   * The dbm is empty iff the number of variables is null.
   */
  Dbm(int s): cardinal(s), closed(true), empty(s==0){
    std::vector<numb> v(s+1, numb());
    insert(end(),s+1, v);
  }
    
    /** Brief Normalizes the dbm.
     * Done in n+1^3, where n is the number of variables constrained
     * by the dbm. assumes an open dbm.
     */
    bool normalize_and_close(); //sets also the flags

    /** Brief opens the dbm.
     * Opens the dbm in order to modify and normalize it.
     */
    void open() { assert(closed==true); closed=false; }

    /** Brief adds a variable to the dbm.
     * Adds a variable at index with lower 
     * bound "lb" and upper bound "up".
     * Normalises in n^2.
     */
    bool add_variable(int index, numb lb, numb ub);


    /** Brief tightens the bound of one difference.
     *  Lowers the bound xi0-xj0. Normalises in n^2.
     */
    bool tighten(int i0, int j0, numb m);

    /** Brief modifies the bound of one difference.
     *  Modifies the bound xi0-xj0. Normalises in n^2.
     */
    bool modify(int i0, int j0, numb m);

    /** Brief existential quantification.
     * Projects away the variables indexed between from and to.
     */
    Dbm project_away(int from, int to) const;

    /** Brief Adds a number of variables.
     *  Adds a number of variables without the need to normalize.
     */
    Dbm extend(int) const;


    /** Brief Conjuncts current and other dbms.
     *  Returns the conjunction of the current and the other dbm.
     */
    Dbm operator&(const Dbm& other) const;

    /** Brief returns the upper bound of a difference.
     * Returns the upper bound on the difference xi-xj.
     */
    numb get(int i, int j) const {
      //      assert( i <= cardinal & j!=i & j <= cardinal);
      assert(!is_empty());
      if(!( i <= cardinal & j!=i & j <= cardinal))
	{
	  std::cout << "assertion fault: i=" << i << ", j=" << j << std::endl;
	  std::cout << *this << std::endl;
	  assert(false);
	}
      return operator[](i)[j];
    }

    /** Brief Changes the upper bound of a difference.
     * 
     */
    void put(int i, int j, numb val) {
      if(!(i <= cardinal & i!=j & j <= cardinal))
	{
	  cout << "put: i,j,val = " << i << "," << j << "," << val << endl;
	  cout << "in :" << *this << endl;
	  assert(i <= cardinal & i!=j & j <= cardinal);
	}
      operator[](i)[j]=val;      
    }

    /** Brief Checks if the dbm is empty
     *
     */
    bool is_empty() const;

    /** Brief Checks if the dbm has been normalized.
     *
     */
    bool is_closed() const {return closed;}

    /** Brief returns the number of variables constrained by the dbm.
     */
    int vars_card() const { return cardinal;}

    /** Brief Checks if a dbm is included in other.
     */
    bool imply(const Dbm& other) const;

    /** Brief Checks for the equality of the non cyclic bounds.
     */
    bool operator==(const Dbm& other) const{
      if(size()!=other.size() | cardinal!=other.cardinal 
	 | closed!=other.closed | empty!=other.empty)
	{ 
#ifdef DEBUG_NEQUAL
	  std::cout << "not equal because of carinal, closure or emptiness difference." << std::endl; 
#endif
	return false;
	}
      for(unsigned i=0; i<size(); i++)
	for(unsigned j=i+1; j<size(); j++)
	  if(operator[](i)[j]!=other[i][j] 
	     | operator[](j)[i]!=other[j][i])
	    {
#ifdef DEBUG_NEQUAL
	      std::cout << "not equal because of (i,j)=(" << i << "," << j 
			<< "), tij=" << operator[](i)[j]
			<< ", oij=" << other[i][j] 
			<<", tji=" << operator[](j)[i]
			<< ", oji=" << other[j][i] 
			<< std::endl; 
#endif		
	      return false;
	    }
      return true;
    }
    
    friend std::ostream& operator<< (std::ostream& out, const Dbm& d);
    
    // private:
    int cardinal;
    bool closed;
    bool empty;
};


/** Brief prints a dbm in one of two ways, either as a matrice or as a formula. 
 */
inline std::ostream& operator<< (std::ostream& out, const Dbm& d)
{

  out <<" [" << d.vars_card()<<"]["<< (d.closed? "c": "nc") <<"]["<< (d.empty? "e":"ne") << "]:" << std::endl ;

#ifdef MATRICE_PRINT

  out << "\t" ;
  for(unsigned b=0; b<d.size(); b++) 
    out << "|-------" ;
  out << std::endl;
  out << "\t" ;
  for(unsigned b=0; b<d.size(); b++) 
    out << "|  x" << b <<  "\t";
  out << std::endl;
  for(unsigned b=0; b<=d.size(); b++) 
    out << "|-------" ;
  out << std::endl;
  for(unsigned c=0; c<d.size(); c++)
    {
      out << "|  x" << c << "\t";
      for(unsigned b=0; b<d.size(); b++) 
	if(c==b)
	  out << "|   *" << "\t";
	else
	  if(d[c][b].inf)
	    out << "| " << "\t";
	  else
	    out << "|  " << d[c][b].value << "\t";
      out << "|" << std::endl;
      for(unsigned b=0; b<=d.size(); b++) 
	out << "|-------" ;
      out << std::endl;
    }
  

#else

  bool started=false;
  
  for(int i=0; i<=d.vars_card(); i++)
    for(int j=i+1; j<=d.vars_card(); j++)
      {
	if(!(d.get(i,j).inf & d.get(j,i).inf)) {
	  if(d.get(j,i).inf){
	    if(i!=0){
	      out << (started ? " & ": "") << 
		-d.get(i,j).value << "<= x" <<  j << "-x" << i; 
	    }
	    else{
	      out << (started ? " & ": "") << 
		-d.get(0,j).value << "<=x" << j;
	    }
	  }
	  else 
	    if(d.get(i,j).inf){
	      if(i!=0){
		out << (started ? " & ": "") <<
		  "x" << j << "-x" << i << "<=" << d.get(j,i).value; 
	      }
	      else{
		out << (started ? " & ": "") <<
		  "x" << j << "<=" << d.get(j,0).value; 
	      }
	    }
	    else{
	      if(-d.get(j,i).value == d.get(i,j).value)
		if(i!=0){
		  out << (started ? " & ": "") << 
		    "x" << i << "-x" << j << "=" << d.get(i,j).value;
		}
		else{
		  out << (started ? " & ": "") << 
		    "x" << j << "=" << d.get(j,0).value;
		}	
	      else
		if(i!=0){
		  out << (started ? " & ": "") << 
		    -d.get(j,i).value << "<=x" << i << "-x" << j << "<=" << d.get(i,j).value;
		}
		else{
		  out << (started ? " & ": "") << 
		    -d.get(0,j).value << "<=x" << j << "<=" << d.get(j,0).value;
		}
	    }
	  started=true;
	}
      }
  out << "}";
#endif
  
  return out;
}

#endif
