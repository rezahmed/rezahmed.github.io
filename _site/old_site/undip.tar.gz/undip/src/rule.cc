/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file rule.cc
 * implementation of a rule
 *
 * @author Rezine Ahmed
 */

#include "rule.h"

#include <time.h>
//#define ALG_DEBUG

//#define DEBUG_COMPUTE
//#define DEBUG_COMPUTE_INSERTION


MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > Rule::compute(const Constraint_Ref& cstr, bool same) const
{
  assert(cstr);

  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > current, result;


  for(int i=1; i<=cstr->cardinal(); ++i)
    {
      current=fire_position(cstr, i, same);
      result.insert(current.begin(), current.end());
    }
  
  if(!same & (Constraint::us!=0 | Constraint::bs!=0)){ 
    // The set of shared variables is non empty.
    // Another process, than the ones explicit in the constraint cstr, may fire
    // the rule and change the shared variables. This may result in constraints
    // that would not entail those computed just by iterating from 1 to cstr->cardinal().
    for(int i=1; i<=cstr->cardinal()+1; ++i)
      {
	Constraint_Ref longer_cstr = cstr->insert_process_before(i);
	current=fire_position(longer_cstr, i, true);
	result.insert(current.begin(), current.end());
	current=fire_position(longer_cstr, i, false);
	result.insert(current.begin(), current.end());
      }

  }
  return result;
}
