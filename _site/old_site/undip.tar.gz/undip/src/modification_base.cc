/*
  Copyright (C) 2007 Rezine Ahmed

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file modification_base.cc
 * implementation of Modificatin_Base
 *
 * @author Rezine Ahmed
 */


#include "modification_base.h"
#include <iterator>

//#define DEBUG_MODIFICATION_BASE_CONSTRUCTOR

Modification_Base::Modification_Base(int _at, int _cn, bool _pure_right, bool _pure_left,
				     const set<int>& _initiator_modified,
				     const vector<set<int> >& _left_modified,
				     const vector<set<int> >& _left_right_modified,
				     const vector<set<int> >& _right_modified,
				     int sv, int pv,
				     const Polynomial& p)
  : at(_at), cn(_cn), pure_right(_pure_right), pure_left(_pure_left), modified(0)
{

#ifdef DEBUG_MODIFICATION_BASE_CONSTRUCTOR
  cout << "modification base constructor %input  combination : " << p << endl;       
#endif

  set<int> minit; 
  // Collect the shared and initiator variables that were modified by the initiator.
  minit.insert(_initiator_modified.begin(), _initiator_modified.end()); 

  if(!pure_right)
    for(int r=1; r<at; ++r)
      {// For each receptor to the left
	set<int> mrecept; 
	if(0<p.lrget(r))
	  { // One of the LR choices will be applied to the receptor
	    for(set<int>::const_iterator it=_left_right_modified[p.lrget(r)-1].begin(); it!=_left_right_modified[p.lrget(r)-1].end(); ++it)
	      {// Collect the modified variables
		if(0<*it & *it<=sv+pv) //shared or initiator's
		  minit.insert(*it);
		else
		  mrecept.insert(*it); //receptor's
	      }
	  }
	else
	  { // One of the L choices will be applied to the receptor
	    for(set<int>::const_iterator it=_left_modified[p.lget(r)-1].begin(); it!=_left_modified[p.lget(r)-1].end(); ++it){
	      if(0<*it & *it<=sv+pv)
		minit.insert(*it);
	      else
		mrecept.insert(*it);
	    }
	  }
	// Remember mrecept for receptor r
	modified+=mrecept.size();
	push_back(mrecept);
      }

  if(!pure_left)
    for(int r=at+1; r<=cn; ++r){
      set<int> mrecept; 
      if(0<p.lrget(r)){
	for(set<int>::const_iterator it=_left_right_modified[p.lrget(r)-1].begin(); it!=_left_right_modified[p.lrget(r)-1].end(); ++it){
	  if(0<*it & *it<=sv+pv)
	    minit.insert(*it);
	  else
	    mrecept.insert(*it);
	}
      }
      else{
	for(set<int>::const_iterator it=_right_modified[p.rget(r)-1].begin(); it!=_right_modified[p.rget(r)-1].end(); ++it){
	  if(0<*it & *it<=sv+pv)
	    minit.insert(*it);
	  else
	    mrecept.insert(*it);
	}
      }
      modified+=mrecept.size();
      push_back(mrecept);
    }

  modified+=minit.size();

  if(pure_right){
    insert(begin(), minit);
    assert(unsigned(cn-at+1)==size());
  }
  else
    if(pure_left){
      insert(end(), minit);
      assert(unsigned(at)==size());
    }
    else{
      vector<set<int> >::iterator it=begin();
      advance(it, at-1);
      insert(it, minit);
      assert(unsigned(cn)==size());
    }

  base.push_back(0);
  for(unsigned i=0; i<size()-1; i++)
    base.push_back(operator[](i).size()+base[i]);

  assert(size()==base.size());
  assert(modified==int(operator[](size()-1).size()+base[size()-1]));


#ifdef DEBUG_MODIFICATION_BASE_CONSTRUCTOR
 
  if(pure_right){
    cout << "current modification  % shared and process variables: ";
    copy(operator[](0).begin(), operator[](0).end(), ostream_iterator<int>(cout, " ")); cout << endl;
    cout << endl;
    for(int r=1; r<=cn-at; ++r){
      cout << "current modification  % R receptor["<< r << "] :";
      copy(operator[](r-1).begin(), operator[](r-1).end(), ostream_iterator<int>(cout, " ")); cout << endl;
      cout << endl;
    }
  }
  else{
    for(int r=1; r<at; ++r){
      cout << "current modification  % L receptor["<< r << "] variables : ";
      copy(operator[](r-1).begin(), operator[](r-1).end(), ostream_iterator<int>(cout, " ")); cout << endl;
      cout << endl;
    }
    cout << "current modification  % shared and process variables : ";
    copy(operator[](at-1).begin(), operator[](at-1).end(), ostream_iterator<int>(cout, " ")); cout << endl;
    cout << endl;
    
    if(!pure_left)
      for(int r=at+1; r<=cn; ++r){
	cout << "current modification  % R receptor["<< r << "] variables : ";
	copy(operator[](r-1).begin(), operator[](r-1).end(), ostream_iterator<int>(cout, " ")); cout << endl;
	cout << endl;
      }
  }
#endif

}
