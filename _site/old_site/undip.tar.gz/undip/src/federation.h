
/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

#ifndef _FEDERATION_H
#define _FEDERATION_H

#include <iostream>
#include <list>


#include "dbm.h"
#include "ref.h"

using namespace std;

class Federation : private list<Dbm>
{
  typedef list<Dbm> container;

 public:
  typedef container::iterator iterator;
  typedef container::const_iterator const_iterator;
  iterator begin(){return container::begin();}
  const_iterator begin() const {return container::begin();}
  iterator end(){return container::end();}
  const_iterator end() const {return container::end();}


 public:
  Federation(){} 
  Federation(const Dbm& d){
    assert(d.is_closed()); 
    if(!d.is_empty()) 
      push_back(d);
  }

  bool is_empty() const { 
    return empty(); 
  }
  
  int vars_card() const {
    if(empty()) return 0; 
    return (begin()->vars_card());
  }

  Federation extend(int) const;
  
  Federation project_away(int from, int to) const; 
  
  Federation operator&(const Federation& other) const;
  
  Federation operator|(const Federation& d) const;

  Federation operator-(const Dbm& d) const;

  Federation operator-(const Federation& other) const;

  bool merge(const Dbm& d);

  static Federation difference(const Dbm& d1, const Dbm& d2);

  static pair<int, int> min(const Dbm& e, const Dbm& r);
  
  friend ostream& operator<< (ostream& out, const Federation& fd);
};

inline ostream& operator<< (ostream& out, const Federation& fd)
{
  out << "{ ";
  for(Federation::const_iterator dpit=fd.begin(); dpit!=fd.end(); ++dpit){
    Federation::const_iterator ndpit=dpit; ++ndpit;
    out << (*dpit) << (ndpit!=fd.end() ? "or":"");
  }
  out << "}";
  
  return out;
}

#endif
