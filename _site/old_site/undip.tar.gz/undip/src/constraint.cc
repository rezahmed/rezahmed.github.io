/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file constraint.cc
 * implementation of a constraint
 *
 * @author Rezine Ahmed
 */

#include "constraint.h"
#include <vector>
#include <list>
#include <set>
#include <iterator>

//#define DEBUG_CONSTRAINT_CONSTRUCT
//#define DEBUG_CONSTRAINT_ENTAILED
//#define DEBUG_COHERENT_UNTILL_NOW
//#define DEBUG_CROSS_CHECK
//#define DEBUG_SIMPLE_CHECK
//#define DEBUG_GET_INITIAL
//#define DEBUG_INSERT_PROCESS
//#define DEBUG_RECEIVER_OR_ONE_OF_CHANNELS_OLD
//#define DEBUG_SET_PROCESS_NEW

//this constructor will only be used in the begining, when building constraints from scratch
//later, we will not (hopefully) go through s^2 and normalize in s^3 as we do here
//

Constraint::Constraint(const Clause& _clause, const Dbm& _dbm, int _n): 
  clause(_clause), dbm(_dbm), n(_n),creation_status(_n*_n)
{ 
#ifdef DEBUG_CONSTRAINT_CONSTRUCT
  cout << "constraint constructor (clause,dbm,n)% input clause  : " << clause << endl
       << "constraint constructor (clause,dbm,n)% input dbm     : " << dbm << endl
       << "constraint constructor (clause,dbm,n)% input cardinal: " << n << endl;
  
  cout << "constraint constructor (clause,dbm,n)% input Bb      : " << Bb << endl;
  cout << "constraint constructor (clause,dbm,n)% input Ub      : " << Ub << endl;
#endif


  bl=0;  bu=0;  ul=0;

  // First, bounded variables:
 
  for(int j=bs+1; j<=clause.vars_card(); j++){
    bl=bl+clause.gnlb(j).value;
    bu=bu+clause.gub(j).value;
  }

  // Second, potentially non bounded variables:

  // intersect with bound for non shared variables 
  for(int j=us+1; j<=dbm.vars_card(); j++)
    ul=ul+dbm.get(0,j).value;

  set_bookmark(0,0,0,0);


#ifdef DEBUG_CONSTRAINT_CONSTRUCT
  cout << "constraint constructor (clause,dbm,n)% output clause  : " << clause
       << "constraint constructor (clause,dbm,n)% output bl,bu,ul: " << bl << "," << bu << "," << ul
       << "constraint constructor (clause,dbm,n)% output dbm     : " << dbm;
#endif
}


bool Constraint::is_empty() const
{
  return (clause.is_empty() & !pure_unbounded) | (dbm.is_empty() & !pure_bounded);
};


bool Constraint::entailed(const Constraint_Ref& other) const
{

#ifdef DEBUG_CONSTRAINT_ENTAILED
  if(other->cid==1307)
    {
      cout << endl << endl ;
      cout << "constraint entailed % input other: " << *other;
      cout << "constraint entailed % input this : " << *this ;
    }
#endif

  //  total_entailments++;

  //assert(other);
 
 //trivial cases
  /*  if(other->is_empty()){
#ifdef DEBUG_CONSTRAINT_ENTAILED
    cout << "constraint entailed output% true on empty other" << endl;
#endif
    other_is_empty++;
    return true;
  }

  if(is_empty()){
#ifdef DEBUG_CONSTRAINT_ENTAILED
    cout << "constraint entailed output% false on empty" << endl;
#endif
    this_is_empty++;
    return false;
    }*/

  int m=other->cardinal();
 
  /*  if(m<n){ // other's size smaller than cstr's 
    // size is a necessar condition
#ifdef DEBUG_CONSTRAINT_ENTAILED
    cout << "constraint entailed output% false: m<n " << endl;
#endif
    //    mlessn++;
    return false;
    }*/


  if(m==n & (bu<other->bu | bl<other->bl | ul<other->ul)){ // other's has a variable that spans over a larger 
    // domain than the corresponding variable here
#ifdef DEBUG_CONSTRAINT_ENTAILED
  if(other->cid==1307)
    {
      cout << "constraint entailed output% false: delta<other->delta " << endl;
    }
#endif
    //    deltaless++;
    return false;
  }


  //within++;

  // shared variables need no renaming
    if(!pure_unbounded)
    if(!simple_check(0, 0, other, 0, 0)){
#ifdef DEBUG_CONSTRAINT_ENTAILED
      cout << "constraint entailed output% false on shared" << endl;
#endif
      return false;
    }
  
  if(!pure_bounded)
    if(!cross_check(0,0,0,0,other,0,0,0,0)){
#ifdef DEBUG_CONSTRAINT_ENTAILED
      cout << "constraint entailed output% false on shared" << endl;
#endif
      return false;
      }

      
  current_indices current(n,m);
  //assert(!current.empty());
  do{
    
#ifdef DEBUG_CONSTRAINT_ENTAILED
  if(other->cid==1307)
    {
      cout << "constraint entailed % starting with this renaming" << current << endl;
    }
#endif
    
    bool fail=false;
    
    if(!pure_unbounded)
      {
	fail = !simple_half(m,other,current);
      }
  
      
    if(!fail & !pure_bounded)
      {
	fail = !half_check(m,other,current);
      }
  

    if(!fail){
#ifdef DEBUG_CONSTRAINT_ENTAILED
  if(other->cid==1307)
    {
      cout << "constraint entailed output% true " << endl;
    }
#endif
      return true;
    }
  
    
  }while(current.next());
  
#ifdef DEBUG_CONSTRAINT_ENTAILED
  if(other->cid==1307)
    {
      cout << "constraint entailed output% false after having been through current" << endl;
    }
#endif
  
  return false;  
}


bool Constraint::half_check(int m, const Constraint_Ref& other, const current_indices& current) const
{

  for(int vp=1; vp<=n; ++vp){
    int Vfromt=us+(vp-1)*(up+(n-1)*uc); 
    int oVfromt=us+(current.image(vp)-1)*(up+(m-1)*uc);
    for(int vc=1; vc<vp; ++vc){
      int Vfrom=Vfromt+up+(vc-1)*uc; 
      int oVfrom=oVfromt+up+(current.image(vc)-1)*uc;
      for(int i=1; i<=uc; ++i)
	{
	  //cout << "vc<vp:hp=hc=0:   [" << Vfrom+i << "][" << 0 
	       //<< "] against [" << oVfrom+i << "][" << 0 << "]" << endl;
	  if(dbm.get(Vfrom+i, 0) < other->dbm.get(oVfrom+i, 0)
	     | dbm.get(0, Vfrom+i) < other->dbm.get(0, oVfrom+i)){
	    return false;
	  }
	}
    }
    // for(int vc=vp; vc<=hp; ++vc){
    // int Vfrom=Vfromt; int oVfrom=oVfromt;
    for(int i=1; i<=up; ++i)
      {
	//cout << "vc=vp:hp=hc=0:   [" << Vfromt+i << "][" << 0 
	     //<< "] against [" << oVfromt+i << "][" << 0 << "]" << endl;
	if(dbm.get(Vfromt+i, 0) < other->dbm.get(oVfromt+i, 0)
	   | dbm.get(0, Vfromt+i) < other->dbm.get(0, oVfromt+i)){
	  return false;
	}
      }
    //}
    for(int vc=vp+1; vc<=n; ++vc){
      int Vfrom=Vfromt+up+(vc-2)*uc; 
      int oVfrom=oVfromt+up+(current.image(vc)-2)*uc;
      for(int i=1; i<=uc; ++i)
	{
	  //cout << "vc>vp:hp=hc=0:   [" << Vfrom+i << "][" << 0 
	       //<< "] against [" << oVfrom+i << "][" << 0 << "]" << endl;
	  if(dbm.get(Vfrom+i, 0) < other->dbm.get(oVfrom+i, 0)
	     | dbm.get(0, Vfrom+i) < other->dbm.get(0, oVfrom+i)){
	    return false;
	  }
	}
    }
  }
  
  for(int vp=1; vp<=n; ++vp)
    {// for each vp
      int Vfromt=us+(vp-1)*(up+(n-1)*uc); 
      int oVfromt=us+(current.image(vp)-1)*(up+(m-1)*uc);
      
      for(int vc=1; vc<vp; ++vc)
	{ //vc<vp
	  int Vfrom=Vfromt+up+(vc-1)*uc; 
	  int oVfrom=oVfromt+up+(current.image(vc)-1)*uc;
	  for(int hp=1; hp<vp; ++hp)
	    {//vc<vp:hp<vp
	      int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	      int oHfromt=us+(current.image(hp)-1)*(up+(m-1)*uc);
	      for(int hc=1; hc<hp; ++hc)
		{//vc<vp:hp<vp:hc<hp
		  int Hfrom=Hfromt+up+(hc-1)*uc; 
		  int oHfrom=oHfromt+up+(current.image(hc)-1)*uc;
		  for(int i=1; i<=uc; ++i)
		    for(int j=1; j<=uc; ++j)
			{
			  //cout << "1:   [" << Vfrom+i << "][" << Hfrom+j 
			       //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
			  if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
			     | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
			    return false;
			  }
			}
		}//vc<vp:hp<vp:hc<hp 1
	      //for(int hc=hp; hc<=hp; ++hc)
	      {//vc<vp:hp<vp:hc=hp
		//int Hfrom=Hfromt;
		//int oHfrom=oHfromt;
		for(int i=1; i<=uc; ++i)
		  for(int j=1; j<=up; ++j)
		    {
		      //cout << "2:   [" << Vfrom+i << "][" << Hfromt+j 
			   //<< "] against [" << oVfrom+i << "][" << oHfromt+j << "]" << endl;
		      if(dbm.get(Vfrom+i, Hfromt+j) < other->dbm.get(oVfrom+i, oHfromt+j)
			 | dbm.get(Hfromt+j, Vfrom+i) < other->dbm.get(oHfromt+j, oVfrom+i)){
			return false;
		      }
		    }
	      }//vc<vp:hp<vp:hc=hp 2
	      for(int hc=hp+1; hc<=n; ++hc)
		{//vc<vp:hp<vp:hc>hp
		  int Hfrom=Hfromt+up+(hc-2)*uc; 
		  int oHfrom=oHfromt+up+(current.image(hc)-2)*uc;
		  for(int i=1; i<=uc; ++i)
		    for(int j=1; j<=uc; ++j)
			{
			  //cout << "3:   [" << Vfrom+i << "][" << Hfrom+j 
			       //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
			  if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
			     | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
			    return false;
			  }
			}
		}//vc<vp:hp<vp:hc>hp 3
	    }//vc<vp:hp<vp
	  //for(int hp=vp; hp<=vp; ++hp)
	  {//vc<vp:hp=vp
	    //int Hfromt=Vfromt;
	    //int oHfromt=Vfromt;
	    for(int hc=1; hc<vc; ++hc)
	      {//vc<vp:hp=vp:hc<hp:hc<vc
		int Hfrom=Vfromt+up+(hc-1)*uc; 
		int oHfrom=oVfromt+up+(current.image(hc)-1)*uc;
		for(int i=1; i<=uc; ++i)
		  for(int j=1; j<=uc; ++j)
		    {
		      //cout << "4:   [" << Vfrom+i << "][" << Hfrom+j 
			   //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
		      if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
			 | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
			return false;
		      }
		    }
	      }//vc<vp:hp=vp:hc<hp:hc<vc 4
	    //for(int hc=vc; hc<=vc; ++hc)
	    {//vc<vp:hp=vp:hc<hp:hc=vc ****
	      //int Hfrom=Hfromt;
	      //int oHfrom=oHfromt;
	      for(int i=1; i<=uc; ++i)
		for(int j=i+1; j<=uc; ++j)
		  {
		    //cout << "5:   [" << Vfrom+i << "][" << Vfrom+j 
			 //<< "] against [" << oVfrom+i << "][" << oVfrom+j << "]" << endl;
		    if(dbm.get(Vfrom+i, Vfrom+j) < other->dbm.get(oVfrom+i, oVfrom+j)
		       | dbm.get(Vfrom+j, Vfrom+i) < other->dbm.get(oVfrom+j, oVfrom+i)){
		      return false;
		    }
		  }
	    }//vc<vp:hp=vp:hc<hp:hc=vc 5 ****
	    /*for(int hc=vc+1; hc<hp; ++hc)
	      {//vc<vp:hp=vp:hc<hp:hc>vc
	      int Hfrom=Hfromt+up+(hc-1)*uc; 
	      int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
	      for(int i=1; i<=uc; ++i)
	      for(int j=1; j<=uc; ++j)
	      if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	      | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	      fail=true;
	      break;
	      }
	      }//vc<vp:hp=vp:hc<hp:hc>vc 6
	    */
	    //for(int hc=hp; hc<=hp; ++hc)
	    {//vc<vp:hp=vp:hc=hp
	      //int Hfrom=Hfromt; 
	      //int oHfrom=VHromt;
	      for(int i=1; i<=uc; ++i)
		for(int j=1; j<=up; ++j)
		  {
		    //cout << "7:   [" << Vfrom+i << "][" << Vfromt+j 
			 //<< "] against [" << oVfrom+i << "][" << oVfromt+j << "]" << endl;
		    if(dbm.get(Vfrom+i, Vfromt+j) < other->dbm.get(oVfrom+i, oVfromt+j)
		       | dbm.get(Vfromt+j, Vfrom+i) < other->dbm.get(oVfromt+j, oVfrom+i)){
		      return false;
		    }
		  }
	    }//vc<vp:hp=vp:hc=hp 7
	    for(int hc=vp+1; hc<=n; ++hc)
	      {//vc<vp:hp=vp:hc>hp
		int Hfrom=Vfromt+up+(hc-2)*uc; 
		int oHfrom=oVfromt+up+(current.image(hc)-2)*uc;
		for(int i=1; i<=uc; ++i)
		  for(int j=1; j<=uc; ++j)
		    {
		      //cout << "8:   [" << Vfrom+i << "][" << Hfrom+j 
			   //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
		      if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
		       | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
		      return false;
		      }
		    }
	      }//vc<vp:hp=vp:hc>hp 8
	  }//vc<vp:hp=vp
	  for(int hp=vp+1; hp<=n; ++hp)
	    {//vc<vp:hp>vp
	      int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	      int oHfromt=us+(current.image(hp)-1)*(up+(m-1)*uc);
	      /*for(int hc=1; hc<hp; ++hc)
		{//vc<vp:hp>vp:hc<hp
		int Hfrom=Hfromt+up+(hc-1)*uc; 
		int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
		for(int i=1; i<=uc; ++i)
		for(int j=1; j<=uc; ++j)
		if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
		| dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
		fail=true;
		break;
		}
		}//vc<vp:hp>vp:hc<hp: 9
	      */
	      //for(int hc=hp; hc<=hp; ++hc)
	      {//vc<vp:hp>vp:hc=hp
		//int Hfrom=Hfromt; 
		//int oHfrom=VHromt;
		for(int i=1; i<=uc; ++i)
		  for(int j=1; j<=up; ++j)
		    {
		      //cout << "10:   [" << Vfrom+i << "][" << Hfromt+j 
			   //<< "] against [" << oVfrom+i << "][" << oHfromt+j << "]" << endl;
		      if(dbm.get(Vfrom+i, Hfromt+j) < other->dbm.get(oVfrom+i, oHfromt+j)
			 | dbm.get(Hfromt+j, Vfrom+i) < other->dbm.get(oHfromt+j, oVfrom+i)){
			return false;
		      }
		    }
	      }//vc<vp:hp>vp:hc=hp 10
	      for(int hc=hp+1; hc<=n; ++hc)
		{//vc<vp:hp>vp:hc>hp
		  int Hfrom=Hfromt+up+(hc-2)*uc; 
		  int oHfrom=oHfromt+up+(current.image(hc)-2)*uc;
		  for(int i=1; i<=uc; ++i)
		    for(int j=1; j<=uc; ++j)
		      {
			//cout << "11:   [" << Vfrom+i << "][" << Hfrom+j 
			     //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
			if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
			   | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
			  return false;
			}
		      }
		}//vc<vp:hp>vp:hc>hp 11
	    }//vc<vp:hp>vp
	}//vc<vp
      //for(int vc=vp; vc<=vp+1; ++vc)
      { //vc=vp
	//int Vfrom=Vfromt;
	//int oVfrom=oVfromt;
	for(int hp=1; hp<vp; ++hp)
	  {//vc=vp:hp<vp
	    int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	    int oHfromt=us+(current.image(hp)-1)*(up+(m-1)*uc);
	    /*for(int hc=1; hc<hp; ++hc)
	      {//vc=vp:hp<vp:hc<hp
	      int Hfrom=Hfromt+up+(hc-1)*uc; 
	      int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
	      for(int i=1; i<=uc; ++i)
	      for(int j=1; j<=uc; ++j)
	      if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	      | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	      fail=true;
	      break;
	      }
	      }//vc=vp:hp<vp:hc<hp 12
	    */
	    //for(int hc=hp; hc<=hp; ++hc)
	    {//vc=vp:hp<vp:hc=hp
	      //int Hfrom=Hfromt; 
	      //int oHfrom=VHromt;
	      for(int i=1; i<=up; ++i)
		for(int j=1; j<=up; ++j)
		  {
		    //cout << "13:   [" << Vfromt+i << "][" << Hfromt+j 
			 //<< "] against [" << oVfromt+i << "][" << oHfromt+j << "]" << endl;
		    if(dbm.get(Vfromt+i, Hfromt+j) < other->dbm.get(oVfromt+i, oHfromt+j)
		       | dbm.get(Hfromt+j, Vfromt+i) < other->dbm.get(oHfromt+j, oVfromt+i)){
		      return false;
		    }
		  }
	    }//vc=vp:hp<vp:hc=hp 13
	    for(int hc=hp+1; hc<=n; ++hc)
	      {//vc=vp:hp<vp:hc>hp
		int Hfrom=Hfromt+up+(hc-2)*uc; 
		int oHfrom=oHfromt+up+(current.image(hc)-2)*uc;
		for(int i=1; i<=up; ++i)
		  for(int j=1; j<=uc; ++j)
		    {
		      //cout << "14:   [" << Vfromt+i << "][" << Hfrom+j 
			   //<< "] against [" << oVfromt+i << "][" << oHfrom+j << "]" << endl;
		      if(dbm.get(Vfromt+i, Hfrom+j) < other->dbm.get(oVfromt+i, oHfrom+j)
			 | dbm.get(Hfrom+j, Vfromt+i) < other->dbm.get(oHfrom+j, oVfromt+i)){
			return false;
		      }
		    }
	      }//vc=vp:hp<vp:hc>hp 14
	  }//vc=vp:hp<vp
	
	//for(int hp=vp; hp<=vp; ++hp)
	{//vc=vp:hp=vp
	  //int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	  //int oHfromt=us+(current.image(hp)-1)*(up+(n-1)*uc);
	  /* for(int hc=1; hc<hp; ++hc)
	     {//vc=vp:hp=vp:hc<hp
	     int Hfrom=Hfromt+up+(hc-1)*uc; 
	     int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
	     for(int i=1; i<=uc; ++i)
	     for(int j=1; j<=uc; ++j)
	     if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	     | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	     fail=true;
	     break;
	     }
	     }//vc=vp:hp=vp:hc<hp 15
	  */
	  //for(int hc=hp; hc<=hp; ++hc)
	  {//vc=vp:hp=vp:hc=hp ***
	    //int Hfrom=Hfromt; int oHfrom=VHromt;
	    for(int i=1; i<=up; ++i)
	      for(int j=i+1; j<=up; ++j)
		{
		  //cout << "16:   [" << Vfromt+i << "][" << Vfromt+j 
		       //<< "] against [" << oVfromt+i << "][" << oVfromt+j << "]" << endl;
		  if(dbm.get(Vfromt+i, Vfromt+j) < other->dbm.get(oVfromt+i, oVfromt+j)
		     | dbm.get(Vfromt+j, Vfromt+i) < other->dbm.get(oVfromt+j, oVfromt+i)){
		    return false;
		  }
		}
	  }//vc=vp:hp=vp:hc=hp 16 *** 
	  for(int hc=vp+1; hc<=n; ++hc)
	    {//vc=vp:hp=vp:hc>hp
	      int Hfrom=Vfromt+up+(hc-2)*uc; 
	      int oHfrom=oVfromt+up+(current.image(hc)-2)*uc;
	      for(int i=1; i<=up; ++i)
		for(int j=1; j<=uc; ++j)
		  {
		    //cout << "17:   [" << Vfromt+i << "][" << Hfrom+j 
			 //<< "] against [" << oVfromt+i << "][" << oHfrom+j << "]" << endl;
		    if(dbm.get(Vfromt+i, Hfrom+j) < other->dbm.get(oVfromt+i, oHfrom+j)
		       | dbm.get(Hfrom+j, Vfromt+i) < other->dbm.get(oHfrom+j, oVfromt+i)){
		      return false;
		    }
		  }
	    }//vc=vp:hp=vp:hc>hp 17
	}//vc=vp:hp=vp
	
	for(int hp=vp+1; hp<=n; ++hp)
	  {//vc=vp:hp>vp
	    int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	    int oHfromt=us+(current.image(hp)-1)*(up+(m-1)*uc);
	    /* for(int hc=1; hc<hp; ++hc)
	       {//vc=vp:hp>vp:hc<hp
	       int Hfrom=Hfromt+up+(hc-1)*uc; 
	       int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
	       for(int i=1; i<=uc; ++i)
	       for(int j=1; j<=uc; ++j)
	       if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	       | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	       fail=true;
	       break;
	       }
	       }//vc=vp:hp>vp:hc<hp 18
	    */
	    /*for(int hc=hp; hc<=hp; ++hc)
	      {//vc=vp:hp=vp:hc=hp
	      int Hfrom=Hfromt; 
	      int oHfrom=VHromt;
	      for(int i=1; i<=uc; ++i)
	      for(int j=1; j<=up; ++j)
	      if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	      | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	      fail=true;
	      break;
	      }
	      }//vc=vp:hp>vp:hc=hp 19
	    */
	    for(int hc=hp+1; hc<=n; ++hc)
	      {//vc=vp:hp>vp:hc>hp
		int Hfrom=Hfromt+up+(hc-2)*uc; 
		int oHfrom=oHfromt+up+(current.image(hc)-2)*uc;
		for(int i=1; i<=up; ++i)
		  for(int j=1; j<=uc; ++j)
		    {
		      //cout << "20:   [" << Vfromt+i << "][" << Hfrom+j 
			   //<< "] against [" << oVfromt+i << "][" << oHfrom+j << "]" << endl;
		      if(dbm.get(Vfromt+i, Hfrom+j) < other->dbm.get(oVfromt+i, oHfrom+j)
		       | dbm.get(Hfrom+j, Vfromt+i) < other->dbm.get(oHfrom+j, oVfromt+i)){
		      return false;
		      }
		    }
	      }//vc=vp:hp>vp:hc>hp 20
	  }//vc=vp:hp=vp
      }//vc=vp

      for(int vc=vp+1; vc<=n; ++vc)
	{//vc>vp
	  int Vfrom=Vfromt+up+(vc-2)*uc; 
	  int oVfrom=oVfromt+up+(current.image(vc)-2)*uc;
	  for(int hp=1; hp<vp; ++hp)
	    {//vc>vp:hp<vp
	      int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	      int oHfromt=us+(current.image(hp)-1)*(up+(m-1)*uc);
	      /*for(int hc=1; hc<hp; ++hc)
		{//vc>vp:hp<vp:hc<hp
		int Hfrom=Hfromt+up+(hc-1)*uc; 
		int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
		for(int i=1; i<=uc; ++i)
		for(int j=1; j<=uc; ++j)
		if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
		| dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
		fail=true;
		break;
		}
		}//vc>vp:hp<vp:hc<hp 21
	      */
	      /*for(int hc=hp; hc<=hp; ++hc)
		{//vc>vp:hp<vp:hc=hp
		int Hfrom=Hfromt; 
		int oHfrom=VHromt;
		for(int i=1; i<=uc; ++i)
		for(int j=1; j<=up; ++j)
		if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
		| dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
		fail=true;
		break;
		}
		}//vc>vp:hp<vp:hc=hp 22
	      */
	      for(int hc=hp+1; hc<=n; ++hc)
		{//vc>vp:hp<vp:hc>hp
		  int Hfrom=Hfromt+up+(hc-2)*uc; 
		  int oHfrom=oHfromt+up+(current.image(hc)-2)*uc;
		  for(int i=1; i<=uc; ++i)
		    for(int j=1; j<=uc; ++j)
		      {
			//cout << "23:   [" << Vfrom+i << "][" << Hfrom+j 
			     //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
			if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
			   | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
			  return false;
			}
		      }
		}//vc>vp:hp<vp:hc>hp 23
	    }//vc>vp:hp<vp
	  //for(int hp=vp; hp<=vp; ++hp)
	  {//vc>vp:hp=vp
	    //int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	    //int oHfromt=us+(current.image(hp)-1)*(up+(n-1)*uc);
	    /* for(int hc=1; hc<hp; ++hc)
	       {//vc>vp:hp=vp:hc<hp
	       int Hfrom=Hfromt+up+(hc-1)*uc; 
	       int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
	       for(int i=1; i<=uc; ++i)
	       for(int j=1; j<=uc; ++j)
	       if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	       | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	       fail=true;
	       break;
	       }
	       }//vc>vp:hp=vp:hc<hp  28 
	    */
	    /* for(int hc=hp; hc<=hp; ++hc)
	       {//vc>vp:hp=vp:hc=hp
	       int Hfrom=Hfromt; int oHfrom=VHromt;
	       for(int i=1; i<=uc; ++i)
	       for(int j=1; j<=up; ++j)
	       if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	       | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	       fail=true;
	       break;
	       }
	       }//vc>vp:hp=vp:hc=hp 27
	    */
	    /* for(int hc=hp+1; hc<=n; ++hc)
	       {//vc>vp:hp=vp:hc>hp:hc<vc
	       int Hfrom=Hfromt+up+(hc-2)*uc; 
	       int oHfrom=VHromt+up+(current.image(hc)-2)*uc;
	       for(int i=1; i<=uc; ++i)
	       for(int j=1; j<=uc; ++j)
	       if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	       | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	       fail=true;
	       break;
	       }
	       }//vc>vp:hp=vp:hc>hp:hc<vc  26
	    */
	    //for(int hc=hp+1; hc<=n; ++hc)
	    {//vc>vp:hp=vp:hc>hp:hc=vc ****
	      //int Hfrom=Hfromt+up+(hc-2)*uc; 
	      //int oHfrom=VHromt+up+(current.image(hc)-2)*uc;
	      for(int i=1; i<=uc; ++i)
		for(int j=i+1; j<=uc; ++j)
		  {
		    //cout << "25:   [" << Vfrom+i << "][" << Vfrom+j 
			 //<< "] against [" << oVfrom+i << "][" << oVfrom+j << "]" << endl;
		    if(dbm.get(Vfrom+i, Vfrom+j) < other->dbm.get(oVfrom+i, oVfrom+j)
		       | dbm.get(Vfrom+j, Vfrom+i) < other->dbm.get(oVfrom+j, oVfrom+i)){
		      return false;
		    }
		  }
	    }//vc>vp:hp=vp:hc>hp:hc=vc 25 ****
	    for(int hc=vc+1; hc<=n; ++hc)
	      {//vc>vp:hp=vp:hc>hp:hc>vc
		int Hfrom=Vfromt+up+(hc-2)*uc; 
		int oHfrom=oVfromt+up+(current.image(hc)-2)*uc;
		for(int i=1; i<=uc; ++i)
		  for(int j=1; j<=uc; ++j)
		    {
		      //cout << "24:   [" << Vfrom+i << "][" << Hfrom+j 
			   //<< "] against [" << oVfrom+i << "][" << oHfrom+j << "]" << endl;
		      if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
			 | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
			return false;
		      }
		    }
	      }//vc>vp:hp=vp:hc>hp:hc>vc 24 
	  }//vc>vp:hp=vp
		
	  //for(int hp=vp; hp<=vp; ++hp)
	  // {//vc>vp:hp>vp
	  // int Hfromt=us+(hp-1)*(up+(n-1)*uc); 
	  // int oHfromt=us+(current.image(hp)-1)*(up+(n-1)*uc);
	  /* for(int hc=1; hc<hp; ++hc)
	     {//vc>vp:hp>vp:hc<hp
	     int Hfrom=Hfromt+up+(hc-1)*uc; 
	     int oHfrom=VHromt+up+(current.image(hc)-1)*uc;
	     for(int i=1; i<=uc; ++i)
	     for(int j=1; j<=uc; ++j)
	     if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	     | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	     fail=true;
	     break;
	     }
	     }//vc>vp:hp>vp:hc<hp 29
	  */
	  /* for(int hc=hp; hc<=hp; ++hc)
	     {//vc>vp:hp>vp:hc=hp
	     int Hfrom=Hfromt; int oHfrom=VHromt;
	     for(int i=1; i<=uc; ++i)
	     for(int j=1; j<=up; ++j)
	     if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	     | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	     fail=true;
	     break;
	     }
	     }//vc>vp:hp>vp:hc=hp 30
	  */
	  /* for(int hc=hp+1; hc<=n; ++hc)
	     {//vc>vp:hp>vp:hc>hp:hc<vc
	     int Hfrom=Hfromt+up+(hc-2)*uc; int oHfrom=VHromt+up+(current.image(hc)-2)*uc;
	     for(int i=1; i<=uc; ++i)
	     for(int j=1; j<=uc; ++j)
	     if(dbm.get(Vfrom+i, Hfrom+j) < other->dbm.get(oVfrom+i, oHfrom+j)
	     | dbm.get(Hfrom+j, Vfrom+i) < other->dbm.get(oHfrom+j, oVfrom+i)){
	     fail=true;
	     break;
	     }
	     }//vc>vp:hp>vp:hc>hp 31
	  */
	  //  }//vc>vp:hp>vp
	}//vc>vp
    }// for each vertical process
  return true;
}


bool Constraint::simple_half(int m, const Constraint_Ref& other, 
			      const current_indices& current) const
{

  for(int vp=1; vp<=n; ++vp){
    int fromt=bs+(vp-1)*(bp+(n-1)*bc); 
    int ofromt=bs+(current.image(vp)-1)*(bp+(m-1)*bc);
    for(int vc=1; vc<vp; ++vc){
      int from=fromt+bp+(vc-1)*bc; 
      int ofrom=ofromt+bp+(current.image(vc)-1)*bc;
      for(int i=1; i<=bc; ++i)
	{
	  //cout << "vc<vp:hp=hc=0:   [" << Vfrom+i << "][" << 0 
	       //<< "] against [" << oVfrom+i << "][" << 0 << "]" << endl;
	  if(!other->clause.included_variable_in(ofrom+i, clause, from+i)){
	    return false;
	  }
	}
    }
    // for(int vc=vp; vc<=hp; ++vc){
    // int Vfrom=Vfromt; int oVfrom=oVfromt;
    for(int i=1; i<=bp; ++i)
      {
	//cout << "vc=vp:hp=hc=0:   [" << Vfromt+i << "][" << 0 
	     //<< "] against [" << oVfromt+i << "][" << 0 << "]" << endl;
	if(!other->clause.included_variable_in(ofromt+i, clause, fromt+i)){
	  return false;
	}
      }
    //}
    for(int vc=vp+1; vc<=n; ++vc){
      int from=fromt+bp+(vc-2)*bc; 
      int ofrom=ofromt+bp+(current.image(vc)-2)*bc;
      for(int i=1; i<=bc; ++i)
	{
	  //cout << "vc>vp:hp=hc=0:   [" << Vfrom+i << "][" << 0 
	  //<< "] against [" << oVfrom+i << "][" << 0 << "]" << endl;
	  if(!other->clause.included_variable_in(ofrom+i, clause, from+i)){
	    return false;
	  }
	}
    }
  }

  return true; 
}


bool Constraint::simple_check(int process,int channel, 
			      const Constraint_Ref& other, 
			      int oprocess, int ochannel) const
{
  
#ifdef DEBUG_SIMPLE_CHECK
  cout << endl 
       << "simple check % input (process,channel:oprocess, ochannel) ---> "
       << "(" << process << "," << channel << ":" << oprocess << "," << ochannel << ")" << endl;
#endif
  
  
  int n=cardinal();
  int m=other->cardinal();
  
  int delta; 
  int from; 
  int ofrom; 

  if(process==0)
    {//checking shared bounded variables
      //assert(channel==0 & oprocess==0 & ochannel==0);
      delta=bs;
      from=0;
      ofrom=0;
    }
  else
    if(process==channel)
      {// checking process bounded variables, 
	//assert(oprocess==ochannel);
	delta=bp;
	from=bs+(process-1)*(bp+(n-1)*bc);
	ofrom=bs+(oprocess-1)*(bp+(m-1)*bc);
      }
    else
      if(process<channel)
	{ //checking process-->channel where process<channel , 
	  delta=bc;
	  from=bs+(process-1)*(bp+(n-1)*bc)+bp+(channel-2)*bc;
	  ofrom=bs+(oprocess-1)*(bp+(m-1)*bc)+bp+(ochannel-2)*bc;
	}
      else
	{ //checking process-->channel where channel<process
	   delta=bc;
	   from=bs+(process-1)*(bp+(n-1)*bc)+bp+(channel-1)*bc;
	   ofrom=bs+(oprocess-1)*(bp+(m-1)*bc)+bp+(ochannel-1)*bc;
	}

#ifdef DEBUG_SIMPLE_CHECK
  cout << "simple check % (from, delta, ofrom) --->" 
       << "(" << from << "," << delta << "," << ofrom << ")" << endl;
#endif

  for(int k=1; k<=delta; k++)
    if(!other->clause.included_variable_in(ofrom+k, clause, from+k)){
#ifdef DEBUG_SIMPLE_CHECK
      cout << "simple check % output false" << endl;
#endif	
      return false;
    }

#ifdef DEBUG_SIMPLE_CHECK
  cout << "simple check % output true" << endl;
#endif	
  return true;
}



bool Constraint::cross_check(int vp,int vc, int hp, int hc,
			     const Constraint_Ref& other, 
			     int ovp, int ovc, int ohp, int ohc) const
{
  
#ifdef DEBUG_CROSS_CHECK
  cout << endl 
       << "constraint cross check % input (vp,vc,hp,hc:ovp,ovc,ohp,ohc) ---> "
       << "(" << vp << "," << vc << "," << hp << "," << hc << ":" << ovp << "," << ovc << "," << ohp << "," << ohc << ")" << endl;
#endif
  
  
  int n=cardinal();
  int m=other->cardinal();
  
  int dv;    //vertical delta
  int dh;    //horizontal delta
  int Vfrom; //local vertical prefix
  int Hfrom; //local horizontal prefix
  int oVfrom;//other vertical prefix
  int oHfrom;//other horizontal prefix

  if(vp==0 & vc==0 & hp==0 & hc==0 & ovp==0 & ovc==0 & ohp==0 & ohc==0)
    {// checking unary and shared boundary, var from 0 to us
      dv=1+us;
      Vfrom=-1;
      oVfrom=-1;
    }
  else
    if(vp==vc & ovp==ovc & vp!=0 & ovp!=0)
      {// checking vertical process vp, 
	dv=up;
	Vfrom=us+(vp-1)*(up+(n-1)*uc);
	oVfrom=us+(ovp-1)*(up+(m-1)*uc);
      }
    else
      if(vp<vc & ovp<ovc)
	{ // checking vp-->vc right channel, 
	  dv=uc;
	  Vfrom=us+(vp-1)*(up+(n-1)*uc)+up+(vc-2)*uc;
	  oVfrom=us+(ovp-1)*(up+(m-1)*uc)+up+(ovc-2)*uc;
	}
      else
	if(vc<vp & ovc<ovp)
	  { //checking vp-->vc left channel
	    dv=uc;
	    Vfrom=us+(vp-1)*(up+(n-1)*uc)+up+(vc-1)*uc;
	    oVfrom=us+(ovp-1)*(up+(m-1)*uc)+up+(ovc-1)*uc;
	  }
	else
	  assert(false);


  if(hp==0 & hc==0 & ohp==0 & ohc==0){
    dh=1+us;
    Hfrom=-1;
    oHfrom=-1;
  }
  else
    if(hp==hc & ohp==ohc){
      dh=up;
      Hfrom=us+(hp-1)*(up+(n-1)*uc);
      oHfrom=us+(ohp-1)*(up+(m-1)*uc);
    }
    else
      if(hp<hc & ohp<ohc){
	dh=uc;
	Hfrom=us+(hp-1)*(up+(n-1)*uc)+up+(hc-2)*uc;
	oHfrom=us+(ohp-1)*(up+(m-1)*uc)+up+(ohc-2)*uc;
      }
      else
	if(hc<hp & ohc<ohp){
	  dh=uc;
	  Hfrom=us+(hp-1)*(up+(n-1)*uc)+up+(hc-1)*uc;
	  oHfrom=us+(ohp-1)*(up+(m-1)*uc)+up+(ohc-1)*uc;
	}
	else
	  assert(false);

#ifdef DEBUG_CROSS_CHECK
  cout << "constraint cross check % (fv,deltav, fov) : (fh, deltah, foh) --->" 
       << "(" << Vfrom << "," << dv << "," << oVfrom << ") : (" << Hfrom << "," << dh << "," << oHfrom << ")" << endl;
#endif

  if(vp==hp & vc==hc)
    { // shared/process/channel square on the diagonal
#ifdef DEBUG_CROSS_CHECK
      cout << "constraint cross check % vp==hp & vc==hc: " << endl;
#endif
      for(int k=1; k<=dv; k++){     
	for(int l=k+1; l<=dh; l++){
#ifdef DEBUG_CROSS_CHECK
	  cout << "constraint cross check % (k,l) = (" << k << "," << l << ")" ;
#endif
	  if((dbm.get(Vfrom+k, Hfrom+l) < other->dbm.get(oVfrom+k, oHfrom+l))
	     | (dbm.get(Hfrom+l, Vfrom+k) < other->dbm.get(oHfrom+l, oVfrom+k)))
	    {//comparing differences between two shared/same process/same channel variables
#ifdef DEBUG_CROSS_CHECK
	      cout << "... false" << endl;
#endif	
	      return false;
	    }
#ifdef DEBUG_CROSS_CHECK
	  else
	    cout << " ... ok" << endl;
#endif	
	}
      }
    }
  else
    { //not on the diagonal
#ifdef DEBUG_CROSS_CHECK
      cout << "constraint cross check % vp!=hp | vc!=hc: " << endl;
#endif
      for(int k=1; k<=dv; k++){     
	for(int l=1; l<=dh; l++){
#ifdef DEBUG_CROSS_CHECK
	  cout << "constraint cross check % (k,l) = (" << k << "," << l << ") " ;
#endif      
	  if(dbm.get(Vfrom+k, Hfrom+l) < other->dbm.get(oVfrom+k, oHfrom+l)
	     | dbm.get(Hfrom+l, Vfrom+k) < other->dbm.get(oHfrom+l, oVfrom+k))
	    {
#ifdef DEBUG_CROSS_CHECK
	      cout << " ... false" << endl;
#endif	
	      return false;
	    }
#ifdef DEBUG_CROSS_CHECK
	  else
	    cout << " ... ok" << endl;
#endif	
	}
      }
    }

  
#ifdef DEBUG_CROSS_CHECK
  cout << "constraint cross check % output true" << endl;
#endif	
  return true;
}




Constraint_Ref Constraint::insert_process_before(int position)const
{
#ifdef DEBUG_INSERT_PROCESS
  cout << "constraint insert process % input position: " << position << endl;
  cout << "constraint insert process % input constraint: " << *this << endl;
#endif

  //assert(1<=position & position<=n+1);

  int bi=0, bj=0;

  // First, bounded variables
  Clause nclause(clause.vars_card()+bp+(n+n)*bc);
  for(int i=1; i<=clause.vars_card(); i++){
    if(i<=bs)
      bi=i;
    else{
      int var=(i-bs-1)%(bp+(n-1)*bc);
      int sender=((i-bs-1)/(bp+(n-1)*bc))+1;
      int sender_shifted=sender + (sender<position? 0: 1);
      if(var<bp)//dealing with a process
	bi=bs+(sender_shifted-1)*(bp+n*bc)+var+1;
      else{
	//dealing with a channel
	int raw_receiver=(var-bp)/bc+1;
	int receiver=raw_receiver+(raw_receiver<sender?0:1);
	int receiver_shifted=receiver+(receiver<position?0:1);
	var=(var-bp)%bc+1;
	bi=bs+(sender_shifted-1)*(bp+n*bc)
	  + bp 
	  + (receiver_shifted-(receiver_shifted<sender_shifted? 0 : 1)-1) * bc
	  + var;
      }
    }
    
#ifdef DEBUG_INSERT_PROCESS
    cout << "clause insert process% i=" << i << "-->bi="<< bi << endl ;
#endif
    
    nclause.modify(bi, clause.gnlb(i), clause.gub(i));
  }
  
#ifdef DEBUG_INSERT_PROCESS
  cout << "insert process% obtained clause : " << nclause << endl ;
#endif


  // Second, unbounded variables
  Dbm ndbm(dbm.vars_card()+up+(n+n)*uc);
  for(int i=0; i<=dbm.vars_card(); i++)
    {
      if(i<=us)
	bi=i;
      else{
	int var=(i-us-1)%(up+(n-1)*uc);
	int sender=((i-us-1)/(up+(n-1)*uc))+1;
	int sender_shifted=sender + (sender<position? 0: 1);
	if(var<up)//dealing with a process
	  bi=us+(sender_shifted-1)*(up+n*uc)+var+1;
	else{
	  //dealing with a channel
	  int raw_receiver=(var-up)/uc+1;
	  int receiver=raw_receiver+(raw_receiver<sender?0:1);
	  int receiver_shifted=receiver+(receiver<position?0:1);
	  var=(var-up)%uc+1;
	  bi=us+(sender_shifted-1)*(up+n*uc)
	    + up 
	    + (receiver_shifted-(receiver_shifted<sender_shifted? 0 : 1)-1) * uc
	    + var;
	}
      }
      
      for(int j=i+1; j<=dbm.vars_card(); j++){
	if(j<=us)
	  bj=j;
	else{
	  int var=(j-us-1)%(up+(n-1)*uc);
	  int sender=((j-us-1)/(up+(n-1)*uc))+1;
	  int sender_shifted=sender + (sender<position? 0:1);
	  if(var<up)//dealing with a process
	    bj=us+(sender_shifted-1)*(up+n*uc)+var+1;
	  else{
	    //dealing with a channel
	    int raw_receiver=(var-up)/uc+1;
	    int receiver=raw_receiver+(raw_receiver<sender?0:1);
	    int receiver_shifted=receiver+(receiver<position?0:1);
	    int var=(var-up)%uc+1;
	    bj=us+(sender_shifted-1)*(up+n*uc)
	      + up 
	      + (receiver_shifted-(receiver_shifted<sender_shifted? 0 : 1)-1) * uc
	      + var;
	  }
	}
	
#ifdef DEBUG_INSERT_PROCESS
	cout << "insert process% (i,j)=(" << i << "," << j << ")-->(bi,bj)=("<< bi << "," << bj  << ")" << endl ;
#endif
      
	ndbm.put(bi, bj, dbm.get(i,j));
	ndbm.put(bj, bi, dbm.get(j,i));
      }
    }
  

#ifdef DEBUG_INSERT_PROCESS
  cout << "insert process% after copying dbm: " << ndbm << endl ;
#endif


  // Apply the bounds to the newly created variables 
  // for each process to the left of the inserted process
  for(int p=1; p<position; p++){
    for(int c=1; c<=bc; c++){
      // bounded channel variables
      nclause.modify(bs+(p-1)*(bp+n*bc)+bp+(position-2)*bc+c, Bb.gnlb(bs+bp+c), Bb.gub(bs+bp+c)); // from p to position
      nclause.modify(bs+(position-1)*(bp+n*bc)+bp+(p-1)*bc+c, Bb.gnlb(bs+bp+c), Bb.gub(bs+bp+c)); // from position to p
    }
    for(int c=1; c<=uc; c++){
      // unbounded channel variable
      ndbm.put(0, us+(p-1)*(up+n*uc)+up+(position-2)*uc+c, Ub.gnlb(us+up+c)); // from p to position
      ndbm.put(0, us+(position-1)*(up+n*uc)+up+(p-1)*uc+c, Ub.gnlb(us+up+c)); // from position to p
    }
  }

  for(int p=1; p<=bp; p++) 
    nclause.modify(bs+(position-1)*(bp+n*bc)+p, Bb.gnlb(bs+p), Bb.gub(bs+p));// for each process variable

  for(int p=1; p<=up; p++)
    ndbm.put(0, us+(position-1)*(up+n*uc)+p, Ub.gnlb(us+p)); // for each process variable
  
  for(int p=position+1; p<=n+1; p++){
    for(int c=1; c<=bc; c++){
      // for each channel variable
      nclause.modify(bs+(p-1)*(bp+n*bc)+bp+(position-1)*bc+c, Bb.gnlb(bs+bp+c), Bb.gub(bs+bp+c));// from p to position
      nclause.modify(bs+(position-1)*(bp+n*bc)+bp+(p-2)*bc+c, Bb.gnlb(bs+bp+c), Bb.gub(bs+bp+c));// from p to position
    }
    for(int c=1; c<=uc; c++){
      // for each channel variable
      ndbm.put(0, us+(p-1)*(up+n*uc)+up+(position-1)*uc+c, Ub.gnlb(us+up+c)); // from p to position
      ndbm.put(0, us+(position-1)*(up+n*uc)+up+(p-2)*uc+c, Ub.gnlb(us+up+c)); // from position to p
    }
  }

  Constraint_Ref cstr_result(new Constraint(nclause, ndbm, n+1));
  cstr_result->set_bookmark(cid, cpid, crid, (cpos<position? cpos:cpos+1));
  cstr_result->set_process_new(position);

#ifdef DEBUG_INSERT_PROCESS
  cout << "insert process% output clause: " << nclause << endl ;
  cout << "insert process% output ndbm  : " << ndbm << endl ;
#endif
  
  return cstr_result;
}


Constraint_Ref Constraint::get_initial(const Clause& iclause, const Dbm& idbm, int n)
{
#ifdef DEBUG_GET_INITIAL
  cout << "constraint get initial (initial_clause, initial_dbm, n)% input cardinal      : " << n << endl
       << "constraint get initial (initial_clause, initial_dbm, n)% input initial clause: " << iclause << endl
       << "constraint get initial (initial_clause, initial_dbm, n)% input initial dbm   : " << idbm << endl;
#endif

  //assert(iclause.vars_card()==bs+bp+bc & idbm.vars_card()==us+up+uc);

  // First, Bounded variables.
  Clause nclause(bs+n*(bp+(n-1)*bc));
  for(int i=1; i<=(bs+n*(bp+(n-1)*bc)); i++){
    int ri=0;
    
    if(i<=bs) //shared variable
      ri=i;
    else
      if(((i-bs-1)%(bp+(n-1)*bc))<bp) //process variable
	ri=bs+((i-bs-1)%(bp+(n-1)*bc))+1;
      else //channel variable
	ri=bs+bp+((((i-bs-1)%(bp+(n-1)*bc))-bp)%bc)+1;
    
    nclause.modify(i, iclause.gnlb(ri), iclause.gub(ri));
  }
  
#ifdef DEBUG_GET_INITIAL
  cout << "constraint get initial % obtained clause : " << nclause << endl;
#endif


  // Second, Unbounded variables.
  Dbm ndbm(us+n*(up+(n-1)*uc));
  for(int i=0; i<=(us+n*(up+(n-1)*uc)); i++){
    int ri=0, pi=0, ci=0;
    if(i<=us) //shared variable
      ri=i;
    else
      if(((i-us-1)%(up+(n-1)*uc))<up){
	//process variable
	ri=us+((i-us-1)%(up+(n-1)*uc))+1;
	pi=((i-us-1)/(up+(n-1)*uc))+1;
      }
      else{
	//channel variable
	ri=us+up+((((i-us-1)%(up+(n-1)*uc))-up)%uc)+1;
	pi=((i-us-1)/(up+(n-1)*uc))+1;
	ci=(((i-us-1)%(up+(n-1)*uc)-up)/uc)+1;
      }

    for(int j=i+1; j<=(us+n*(up+(n-1)*uc)); j++){
      int rj=0, pj=0, cj=0;
      
      if(j<=us)//shared variable
	rj=j;
      else
	if(((j-us-1)%(up+(n-1)*uc))<up){
	  //process variable
	  rj=us+((j-us-1)%(up+(n-1)*uc))+1;
	  pj=((j-us-1)/(up+(n-1)*uc))+1;
	}
	else{
	  //channel variable
	  rj=us+up+((((j-us-1)%(up+(n-1)*uc))-up)%uc)+1;
	  pj=((j-us-1)/(up+(n-1)*uc))+1;
	  cj=(((j-us-1)%(up+(n-1)*uc)-up)/uc)+1;
	}
      
#ifdef DEBUG_GET_INITIAL
      cout << "constraint get initial % (i,j)-->(ri,pi,ci,rj,pj,cj) : (" 
	   << i << "," << j << ")-->(" << ri<< "," << pi << "," << ci << "," << rj << "," << pj << "," << cj << ")" << endl;
#endif	
      
      if(i==0){
	//assert(ri!=rj);
	ndbm.put(0,j,idbm.get(0,rj));
	ndbm.put(j,0,idbm.get(rj,0));
      }
      else
	if(pi==0 | pj==0 | (pi==pj & ci==cj)){
	  //only way to relate variables of different processes or channels is by using the shared ones
	  //assert(ri!=rj);
	  ndbm.put(i,j,idbm.get(ri,rj));
	  ndbm.put(j,i,idbm.get(rj,ri));
	}	
    }
  }
  
#ifdef DEBUG_GET_INITIAL
  cout << "constraint get initial %  obtained dbm : " << ndbm << endl;
#endif
  
  ndbm.open();
  assert(!ndbm.normalize_and_close());
  
  Constraint_Ref result(new Constraint(nclause, ndbm, n));
  result->set_bookmark(0,0,0,0);
  return result;
}


void Constraint::set_bookmark(int _id, int _parent_id, int _rule_id, int _position)
  {
    cid=_id; 
    cpid=_parent_id; 
    crid=_rule_id; 
    cpos=_position;
  }

void Constraint::set_process_new(int p)
{
  
#ifdef DEBUG_SET_PROCESS_NEW
  cout << "set process new % input " << p << endl;
  cout << "set process new % status ";
  for(unsigned i=0; i<creation_status.size(); i++)
    if(creation_status[i]==old)
      cout << " o" ;
    else
      if(creation_status[i]==cnew)
	cout <<" n";
      else
	assert(false);
  cout << endl;
#endif

  p=p-1;
  //assert(0<=p & p<n);
  for(int q=0; q<n; q++)
    {
      creation_status[p*n+q]=cnew;
      creation_status[q*n+p]=cnew;
    }

#ifdef DEBUG_SET_PROCESS_NEW
  cout << "set process new % output status ";
  for(unsigned i=0; i<creation_status.size(); i++)
    if(creation_status[i]==old)
      cout << " o" ;
    else
      if(creation_status[i]==cnew)
	cout <<" n";
      else
	assert(false);
  cout << endl;
#endif

}


void Constraint::set_process_old(int p)
{
  //assert(1<=p & p<=n);
  creation_status[(p-1)*n+(p-1)]=old;
}

void Constraint::set_channel_old(int from, int to)
{
  //assert(1<=from & from<=n & 1<=to & to<=n);
  creation_status[(from-1)*n+(to-1)]=old;
}


void Constraint::set_sender_and_channels_old(int p)
{
  p=p-1;
  //assert(0<=p & p<n);
  for(int q=0; q<n; q++)
    {
      creation_status[p*n+q]=old;
    }
}


void Constraint::set_sender_and_incoming_channels_old(int p)
{
  p=p-1;
  //assert(0<=p & p<n);
  for(int q=0; q<n; q++)
    {
      creation_status[q*n+p]=old;
    }
}

// if neither process p, nor any  channel (p,q) are constrained in C, there is no point
// in computing a pre of C on p with an BDC, or any SDC, transition, since the result is guaranteed 
// to entail C.
bool Constraint::is_sender_or_one_of_channels_old(int p) const
{

  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  p=p-1;
  //assert(0<=p & p<n);
  for(int q=0; q<n; q++)
    {
      if(creation_status[p*n+q]==old)
	return true;
    }
  return false;
}


// if neither process p, nor any  channel (p,q) or (q,p) are constrained in C, there 
// is no point in computing a pre of C on p with an SDGT, transition, since 
// the result is guaranteed to entail C.
bool Constraint::is_sender_or_one_of_io_channels_old(int p) const
{

  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  p=p-1;
  //assert(0<=p & p<n);
  for(int q=0; q<n; q++)
    {
      if(creation_status[p*n+q]==old | creation_status[q*n+p]==old)
	return true;
    }
  return false;
}


// if all processes p are not constrained in C, there is no point
// in computing a pre of C on p with an BDP, or any EXP, transition, since the result is guaranteed 
// to entail C.
bool Constraint::is_one_of_processes_old() const
{
  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  for(int q=0; q<n; q++)
    {
      if(creation_status[q*n+q]==old)
	return true;
    }
  return false;
}

// if neither process p, nor channel (p,q) are constrained in C, there is no point
// in computing a pre of C on p with an SDC transition, since the result is guaranteed 
// to entail C.
bool Constraint::is_sender_or_channel_old(int sender, int receiver) const
{
  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  //assert(1<=sender & sender<=n & 1<=receiver & receiver<=n);
  return creation_status[(sender-1)*n+(sender-1)]==old | creation_status[(sender-1)*n+(receiver-1)]==old ;
}


// if neither process p, nor channel (p,q), nor channel (q,p) are constrained 
// in C, there is no point in computing a pre of C on p with an SDGT transition, 
// since the result is guaranteed to entail C.
bool Constraint::is_sender_or_io_channel_old(int sender, int receiver) const
{
  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  //assert(1<=sender & sender<=n & 1<=receiver & receiver<=n);
  return creation_status[(sender-1)*n+(sender-1)]==old 
    | creation_status[(sender-1)*n+(receiver-1)]==old 
    | creation_status[(receiver-1)*n+(sender-1)]==old ;
}


// if process p is not constrained in C, there is no point
// in computing a pre of C on p with an LC, or EXP, transition,
// since the result is guaranteed to entail C.
bool Constraint::is_process_old(int p) const
{
  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  //assert(1<=p & p<=n);
  return(creation_status[(p-1)*n+(p-1)]==old);
}

// if neither process p, nor channel (q, p) are constrained in C, there is no point
// in computing a pre of C on p with an GTC transition, since the result is guaranteed 
// to entail C.
bool Constraint::is_receiver_or_channel_old(int sender, int receiver) const
{
  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  //assert(1<=sender & sender<=n & 1<=receiver & receiver<=n);
  return creation_status[(receiver-1)*n+(receiver-1)]==old | creation_status[(sender-1)*n+(receiver-1)]==old ;
}

// if neither process p, nor any channel (q, p) are constrained in C, there is no point
// in computing a pre of C on p with an IBDC, or any GTC, transition, since the result is guaranteed 
// to entail C.
bool Constraint::is_receiver_or_one_of_channels_old(int p) const
{
  //except if there are some shared variables
  if(us+bs!=0)
    return true;

  p=p-1;
  assert(0<=p & p<n);
  for(int q=0; q<n; q++)
    {
      if(creation_status[q*n+p]==old)
	{
	  return true;
	}
    }
  return false;
}


void Constraint::copy_status(const Constraint_Ref& cstr)
{
  creation_status=cstr->creation_status;
}

void Constraint::copy_status_and_create(const Constraint_Ref& cstr, int at)
{
  for(int q=0; q<(at-1); q++)
    {
      for(int p=0; p<(at-1); p++)
	creation_status[q*n+p]=cstr->creation_status[q*(n-1)+p];

      for(int p=at; p<n; p++)
	creation_status[q*n+p]=cstr->creation_status[q*(n-1)+(p-1)];
    }

  for(int q=at; q<n; q++)
    {
      for(int p=0; p<at-1; p++)
	creation_status[q*n+p]=cstr->creation_status[(q-1)*(n-1)+p];

      for(int p=at; p<n; p++)
	creation_status[q*n+p]=cstr->creation_status[(q-1)*(n-1)+(p-1)];
    }

  set_process_new(at);

}
