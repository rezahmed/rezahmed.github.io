/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file cipher.h
 * trivial implementation of a printable pair<int,int>
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_CIPHER_H
#define _UNDIP_CIPHER_H


#include <utility>
#include <iostream>

class Cipher
{

 public:

  Cipher(int _a,int _b, bool _bounded): a(_a), b(_b), bounded(_bounded){}

    int first()const{
      return a;
    }
    int second()const{
      return b;
    }
    bool is_bounded()const{
      return bounded;
    }

    friend std::ostream& operator<< (std::ostream& out, 
				     const Cipher& cipher);

 private:
  int a;
  int b;
  bool bounded;
};




inline std::ostream& operator<< (std::ostream& out, 
				 const Cipher& cipher)
{
  return out << (cipher.is_bounded()? "bounded" : "unbounded") << "(" << cipher.first() << "," << cipher.second() << ")" ;
}



#endif
