/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOKEN_SHARED = 258,
     TOKEN_PROCESS = 259,
     TOKEN_CHANNEL = 260,
     TOKEN_LEFT = 261,
     TOKEN_DOT = 262,
     TOKEN_RIGHT = 263,
     TOKEN_COMMA = 264,
     TOKEN_INFINITY = 265,
     TOKEN_SEMI_COLON = 266,
     TOKEN_COLON = 267,
     TOKEN_CONSTRAINT = 268,
     TOKEN_LESS = 269,
     TOKEN_EQUAL = 270,
     TOKEN_MINUS = 271,
     TOKEN_AND = 272,
     TOKEN_OR = 273,
     TOKEN_PRE = 274,
     TOKEN_WITH = 275,
     TOKEN_NEXT = 276,
     TOKEN_LC = 277,
     TOKEN_SDC = 278,
     TOKEN_GTC = 279,
     TOKEN_SDGT = 280,
     TOKEN_PCP = 281,
     TOKEN_BDC = 282,
     TOKEN_IBDC = 283,
     TOKEN_EXP = 284,
     TOKEN_BDP = 285,
     TOKEN_LEFT_DOMAIN = 286,
     TOKEN_RIGHT_DOMAIN = 287,
     TOKEN_LEFT_RIGHT_DOMAIN = 288,
     TOKEN_CHANNEL_VAR = 289,
     TOKEN_CHANNEL_IN_VAR = 290,
     TOKEN_CHANNEL_OUT_VAR = 291,
     TOKEN_PROCESS_VAR = 292,
     TOKEN_PROCESS_SQUARE = 293,
     TOKEN_COMMANDS = 294,
     TOKEN_CMD_EXIT = 295,
     TOKEN_CMD_PRINT = 296,
     TOKEN_CMD_UPRED = 297,
     TOKEN_FROM = 298,
     TOKEN_INITIAL = 299,
     ID = 300,
     INT = 301
   };
#endif
/* Tokens.  */
#define TOKEN_SHARED 258
#define TOKEN_PROCESS 259
#define TOKEN_CHANNEL 260
#define TOKEN_LEFT 261
#define TOKEN_DOT 262
#define TOKEN_RIGHT 263
#define TOKEN_COMMA 264
#define TOKEN_INFINITY 265
#define TOKEN_SEMI_COLON 266
#define TOKEN_COLON 267
#define TOKEN_CONSTRAINT 268
#define TOKEN_LESS 269
#define TOKEN_EQUAL 270
#define TOKEN_MINUS 271
#define TOKEN_AND 272
#define TOKEN_OR 273
#define TOKEN_PRE 274
#define TOKEN_WITH 275
#define TOKEN_NEXT 276
#define TOKEN_LC 277
#define TOKEN_SDC 278
#define TOKEN_GTC 279
#define TOKEN_SDGT 280
#define TOKEN_PCP 281
#define TOKEN_BDC 282
#define TOKEN_IBDC 283
#define TOKEN_EXP 284
#define TOKEN_BDP 285
#define TOKEN_LEFT_DOMAIN 286
#define TOKEN_RIGHT_DOMAIN 287
#define TOKEN_LEFT_RIGHT_DOMAIN 288
#define TOKEN_CHANNEL_VAR 289
#define TOKEN_CHANNEL_IN_VAR 290
#define TOKEN_CHANNEL_OUT_VAR 291
#define TOKEN_PROCESS_VAR 292
#define TOKEN_PROCESS_SQUARE 293
#define TOKEN_COMMANDS 294
#define TOKEN_CMD_EXIT 295
#define TOKEN_CMD_PRINT 296
#define TOKEN_CMD_UPRED 297
#define TOKEN_FROM 298
#define TOKEN_INITIAL 299
#define ID 300
#define INT 301




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 88 "undip-parser.yy"
{
	int n;
	string* str;
	Variable* range;
	pair<int,v_type>* var;
	Dbm* dbm;
	Action* action;
	Actions_Sequence* actions_sequence;
	Constraint* constraint;
	Rule* rule;
	MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> >* upward;
	UpwardPre* next;
	Quantifier_Domain domain;
	vector<Dbm>* sconjuncts;
	}
/* Line 1489 of yacc.c.  */
#line 157 "undip-parser.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

