/*
    Copyright (C) 2007 Rezine Ahmed

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file gtc.h
 * Header for GTC
 *
 * @author Rezine Ahmed
 */

#ifndef _UNDIP_GTC_H
#define _UNDIP_GTC_H

#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <map>

#include "ref.h"
#include "order.h"
#include "minset.h"
#include "dbm.h"
#include "clause.h"
#include "constraint.h"
#include "cipher.h"
#include "action.h"
#include "actions_sequence.h"
#include "rule.h"
#include "confederation.h"


using namespace std;

/** Brief Specialized Transitions for Getting Globally.  
 *  Updates the firing process and a channel, whose sender may eventually, 
 *  be created together with its channels with the other processes. The values
 *  of the firing process and of the channel are to verify and to be updated
 *  according to the list of dbms.
 */
class GTC: public Rule
{

  /** Brief fire transition at specified position without channel insertion.
   *  \param at index of the firing process.
   *  \param w index of the witness process.
   *  \param watv encoding position of the witness channel.
   *  \param atv encoding position of the firing process.
   *  \param cs number of encoding variables in the constraint.
   *  \param cstr_dbm dbm of the image constraint the pre of which is to be computed.
   *  \returns dbm of the predecessor constraint, empty dbm if disabled.
   */
  pair<Clause,Dbm> fire_position_specified_witness_no_insertion(int at, 
								int w, int bwatv,int uwatv, 
								int batv, int uatv, const Constraint_Ref& cstr) const;

 /** Brief fire transition at specified position with channel insertion.
   *  \param at index of the firing process before insertion.
   *  \param insert_position index of the witness process after insertion.
   *  \param cn number of processes before insertion.
   *  \param cstr_dbm dbm of the image constraint the pre of which is to be computed.
   *  \returns dbm of the predecessor constraint, empty dbm if disabled.
   */
  pair<Clause,Dbm> fire_position_inserted_witness(int at, int insert_position,
						  const Constraint_Ref& cstr, const pair<Clause,Dbm>& restriction)const;
  

/* 
 */
  int action_to_working(int i, int uatv, int uwatv, 
			int usegment, int ucs)const;


 int action_to_inserted_working(int i, int uatv, int nuatv, int nuwatv, 
				int usegment, int nucs)const;


 /* Get the constraint to the working dbm.
  *
  */  
 int constraint_to_working(int i, int ucs, 
			   int uatv, int uwatv) const;
 
 int constraint_to_inserted_working(int i, int nucs, int cn, int ncn, 
				    int at, int insert_position) const;


 /* Easy check to save time in case transitions disabled.
  *
  */
 bool check_satisfiable(int at, int batv, int uatv, const Constraint_Ref& cstr) const;


 /* Easy check to save time in case transition disabled on the given channel.
  *
  */
 bool check_channel_validity(int at, int batv, int uatv, int bwatv, int uwatv,
			     const Constraint_Ref& cstr) const;

 bool check_insertion_satisfiable(int batv, int uatv, const Constraint_Ref& cstr, const pair<Clause,Dbm>& restriction) const;


 /* The transition is of the form R(p1,..pp, c1,...,cc,p1',...,pp', c1',...cc')
  * where p1,...pp are the firing process variables, while c1,...cc are the channel variables.
  * It is useless to insert a channel whose variables, when combined with the process variables,
  * satisfy the projection of R on the predecessor variables. This is because if they do satisfy, 
  * then the result will be entailed by the predecessor.
  * To ensure the generated constraint obtained by insertion, is not entailed by the original constraint,
  * we "take away" the combination of the process and the channel variables from the projection 
  * of R on the predecessor variables. 
  */
 Confederation restrict_non_covered(Confederation& non_covered, int batv, int uatv, int bwatv, int uwatv, 
				    const Constraint_Ref& cstr) const;

 public:
/** Brief Construct a Specialized Transition for Sending Globally.
 *  
 */
  GTC(const Actions_Sequence & _sequence, 
       const Quantifier_Domain& _domain=LR);
  
  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > fire_position(const Constraint_Ref&, int, bool) const;

 protected:
  void printOn(ostream& o) const;

 private:
  Actions_Sequence bsequence;
  set<int> bounded_shared_modified, bounded_process_modified, 
    bounded_channel_modified;
  Actions_Sequence bounded_shared_and_process_guard, bounded_channel_guard;
  Clause bimage;
  
  Actions_Sequence usequence;
  set<int> unbounded_shared_modified, unbounded_process_modified, 
    unbounded_channel_modified;
  map<int, int> modification;
  Actions_Sequence unbounded_shared_and_process_guard, unbounded_channel_guard;
  Dbm uimage;
  
  Quantifier_Domain domain;  
};



#endif

