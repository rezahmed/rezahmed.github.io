/*
  Copyright (C) 2007 Rezine Ahmed

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  Contact information: Rezine Ahmed <Rezine.Ahmed@it.uu.se>  
*/

/** @file exp.cc
 * implementation of a EXP
 *
 * @author Rezine Ahmed
 */

#include "exp.h"
#include <iterator>

//#define DEBUG_EXP_CONSTRUCT
//#define DEBUG_FIRE_EXP
//#define DEBUG_WITNESS_VALIDITY
//#define DEBUG_COMPUTE_BI_INSERTED
//#define DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
//#define DEBUG_FIRE_POSITION_INSERTED_WITNESS
//#define DEBUG_RESTRICT_NON_COVERED

EXP::EXP(const Actions_Sequence& _sequence, 
	 const Quantifier_Domain& _domain): domain(_domain)
{
  rid=++rcounter;

  for(Actions_Sequence::const_iterator it=_sequence.begin(); 
      it!=_sequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    if(it->get_cipher().is_bounded())
      bsequence.add(*it);
    else
      usequence.add(*it);
  }


#ifdef DEBUG_EXP_CONSTRUCT
  cout << endl;
  cout << "EXP constructor % input id      : " << rid << endl;
  cout << "EXP constructor % input domain  : " << (domain==L? "L" : (domain==R? "R" : "LR")) << endl;
  cout << "EXP constructor % input bsequence: " << bsequence;
  cout << "EXP constructor % input usequence: " << usequence;
#endif

  // First, Bounded part
  int bs=Constraint::bs, bp=Constraint::bp;
  int bsegment=bs+bp+bp;
  bimage=Clause(bsegment);
  //collect the modified bounded variables
  for(Actions_Sequence::const_iterator it=bsequence.begin(); 
      it!=bsequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    assert(i==0 | j==0);
    assert(i!=j & i<=2*bsegment & j<=2*bsegment);
    int index=(i==0 ? j: i);
    if(0<index-bsegment){
      if(index-bsegment<=bs) bounded_shared_modified.insert(index-bsegment);
      else if(index-bsegment<=bs+bp) 
	bounded_process_modified.insert(index-bsegment);
      else bounded_witness_modified.insert(index-bsegment);
    }
  }
  //build the largest image, and collect the guards
  for(Actions_Sequence::const_iterator it=bsequence.begin(); 
      it!=bsequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    int index=(i==0? j: i);
    numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
    numb  ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
    if(bsegment < index){
      assert(bimage.tighten(index-bsegment, nlb, ub));
      if(index-bsegment<=bs+bp) bounded_shared_and_process_guard.add(*it);
      else bounded_witness_guard.add(*it);
    }
    else 
      if(bounded_shared_modified.find(index)==bounded_shared_modified.end() 
	 & bounded_process_modified.find(index)==bounded_process_modified.end() 
	 & bounded_witness_modified.find(index)==bounded_witness_modified.end() ) {
	assert(bimage.tighten(index, nlb, ub));
	if(index<=bs+bp) bounded_shared_and_process_guard.add(*it);
	else bounded_witness_guard.add(*it);
      }
  }

  //intersect with bounds 
  for(int index=1; index<=bs+bp; ++index)
    bimage.tighten(index, Constraint::Bb.gnlb(index), Constraint::Bb.gub(index));
  for(int index=bs+bp+1; index<=bsegment; ++index)
    bimage.tighten(index, Constraint::Bb.gnlb(index-bp), Constraint::Bb.gub(index-bp));

  assert(Constraint::pure_unbounded | !bimage.is_empty());

#ifdef  DEBUG_EXP_CONSTRUCT
  cout << "EXP constructor % bounded shared modified      : "; 
  copy(bounded_shared_modified.begin(), bounded_shared_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "EXP constructor % bounded process modified     : "; 
  copy(bounded_process_modified.begin(), bounded_process_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;  
  cout << "EXP constructor % bounded witness modified     : "; 
  copy(bounded_witness_modified.begin(), bounded_witness_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "EXP constructor % bounded shared/process guard : " << endl 
       << bounded_shared_and_process_guard << endl; 
  cout << "EXP constructor % bounded witness guard        : " << endl 
       << bounded_witness_guard << endl; 
  cout << "EXP constructor % obtained bounded image       : " << endl 
       << bimage << endl; 
#endif
  
  // Second, the unbounded case.
  int us=Constraint::us, up=Constraint::up;
  int usegment=us+up+up;
  
  Dbm dbm(2*usegment);
  for(Actions_Sequence::const_iterator it=usequence.begin(); 
      it!=usequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    assert(dbm.tighten(i,j,it->get_dbm().get(0,1)));
    assert(dbm.tighten(j,i,it->get_dbm().get(1,0)));
    if(0<i-usegment){
      if(i-usegment<=us) unbounded_shared_modified.insert(i-usegment);
      else if(i-usegment<=us+up) unbounded_process_modified.insert(i-usegment);
      else unbounded_witness_modified.insert(i-usegment);
    }
    if(0<j-usegment){
      if(j-usegment<=us) unbounded_shared_modified.insert(j-usegment);
      else if(j-usegment<=us+up) unbounded_process_modified.insert(j-usegment);
      else unbounded_witness_modified.insert(j-usegment);
    }
  }

  //fix encoding for modified unbounded variables
  set<int>::const_iterator mit;
  int incrementer=1;
  for(mit=unbounded_shared_modified.begin(); 
      mit!=unbounded_shared_modified.end(); ++mit, ++incrementer)  
    modification[*mit]=incrementer;  
  for(mit=unbounded_process_modified.begin(); 
      mit!=unbounded_process_modified.end(); ++mit, ++incrementer)  
    modification[*mit]=incrementer;  
  for(mit=unbounded_witness_modified.begin(); 
      mit!=unbounded_witness_modified.end(); ++mit, ++incrementer) 
    modification[*mit]=incrementer; 

  // Apply variable lower bounds
  for(int j=1; j<=us+up; ++j){ 
    assert(dbm.tighten(0,j,Constraint::Ub.gnlb(j))); //intersect with bound for base variables 
    assert(dbm.tighten(0,j+usegment,Constraint::Ub.gnlb(j))); //for image variables
    if(modification.find(j)==modification.end()){ //non modified variable are copied
      assert(dbm.tighten(j,j+usegment,numb(0)));
      assert(dbm.tighten(j+usegment,j,numb(0)));
    }
  }
  for(int j=us+up+1; j<=usegment; ++j){ 
    assert(dbm.tighten(0,j,Constraint::Ub.gnlb(j-up))); //intersect with bound for base variables 
    assert(dbm.tighten(0,j+usegment,Constraint::Ub.gnlb(j-up))); //for image variables
    if(modification.find(j)==modification.end()){ //non modified variable are copied
      assert(dbm.tighten(j,j+usegment,numb(0)));
      assert(dbm.tighten(j+usegment,j,numb(0)));
    }
  }

  uimage=dbm.project_away(1,usegment);

  assert(Constraint::pure_bounded | !uimage.is_empty());

  // collecting the guards for the unbounded variables
  for(Actions_Sequence::const_iterator it=usequence.begin(); 
      it!=usequence.end(); ++it){
    int i=it->get_cipher().first(), j=it->get_cipher().second();
    // is the variable a constant, a shared or a process variable that is either
    // modified in this action, or not modified in any action?
    bool shared_firing_guard_i=(i==0 | (usegment<i & i<=usegment+us+up) | 
				(i<=us+up & modification.find(i)==modification.end()));
    bool shared_firing_guard_j=(j==0 | (usegment<j & j<=usegment+us+up) | 
				(j<=us+up & modification.find(j)==modification.end()));
    //is the variable a constant, a shared or process or witness variable that is modified in 
    //this action, or witness variable that is not modified in any aciton?
    bool witness_guard_i=(i==0 | usegment<i  | 
			  ((us+up<i & i<=usegment) & modification.find(i)==modification.end()));
    bool witness_guard_j=(j==0 | usegment<j  | 
			  ((us+up<j & j<=usegment) & modification.find(j)==modification.end()));
    if(shared_firing_guard_i & shared_firing_guard_j)
      unbounded_shared_and_process_guard.add(*it);
    else 
      if(witness_guard_i & witness_guard_j)
	unbounded_witness_guard.add(*it);
  }
  
#ifdef  DEBUG_EXP_CONSTRUCT
  cout << "EXP constructor % modified ushared set: " ;
  copy(unbounded_shared_modified.begin(), unbounded_shared_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "EXP constructor % modified uprocess set: " ;
  copy(unbounded_process_modified.begin(), unbounded_process_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "EXP constructor % modified uwitness set: " ;
  copy(unbounded_witness_modified.begin(), unbounded_witness_modified.end(), ostream_iterator<int>(cout, ","));   cout << endl;
  cout << "EXP constructor % obtained dbm: " << dbm << endl; 
  cout << "EXP constructor % unbounded_shared_process_guard: " << endl << endl
       << unbounded_shared_and_process_guard << endl;
  cout << "EXP constructor % unbounded_witness_guard : " << endl << endl 
       << unbounded_witness_guard << endl;
#endif

}


MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > EXP::fire_position(const Constraint_Ref& cstr, int at, bool same) const
{//fire position
  
  assert(cstr);
  assert(1<=at & at<=cstr->cardinal());

#ifdef DEBUG_FIRE_EXP
  cout << endl 
	    << "fire_EXP% input at: " << at << endl 
	    << "fire_EXP% input c: " << *cstr << endl
	    << "fire_EXP% input r: " << rid << endl;
#endif

  if(cstr->is_empty() | !cstr->is_one_of_processes_old()){
#ifdef DEBUG_FIRE_EXP
    cout << "fire_EXP% output : empty input, result doomed to entail the input ! "<< endl ;
#endif
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > phi;
    return phi;
  }
  
  int cn=cstr->cardinal();//number of processes in cstr

  int bs=Constraint::bs, bp=Constraint::bp, bc=Constraint::bc;
  int bsegment=bs+bp+bc;
  int batv=bs+(at-1)*(bp+(cn-1)*bc);//begining of process "at"'s bounded variables 

  int us=Constraint::us, up=Constraint::up, uc=Constraint::uc;
  int usegment=us+up+uc;
  int uatv=us+(at-1)*(up+(cn-1)*uc);//begining of process "at"'s unbounded variables 
  
  if(!check_satisfiable(at, batv, uatv, cstr)){
#ifdef DEBUG_FIRE_EXP
    cout << "fire_EXP% output : rule not enabled ! "<< endl ;
#endif
    MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > phi;
    return phi;
  }

  MinSet<Constraint_Ref, EntailmentOrder<Constraint_Ref> > result_min_set; //resulting min set
  

  if(domain!=R)
    for(int w=1; w<at; ++w){
      //without insertion for each witness to the left
      int bwatv=bs+(w-1)*(bp+(cn-1)*bc);
      int uwatv=us+(w-1)*(up+(cn-1)*uc);
      
      //here, we restrict the to be inserted witness
      
      if(same & (cstr->is_process_old(at) | cstr->is_process_old(w))){//if same
	if(!check_witness_validity(at, batv, uatv, bwatv, uwatv, cstr))
	  continue;
	else{//if satisfiable witness
	  pair<Clause, Dbm> result=fire_position_specified_witness_no_insertion(at, w, batv, uatv, bwatv, uwatv, cstr);
#ifdef DEBUG_FIRE_EXP
	  cout << "fire_EXP% no insertion: (fire, witness)=(" << at << "," <<  w << ")" << endl 
	       << "fire_EXP% no insertion gives" << endl << result.first << result.second << endl ;
#endif
	  if(!(result.first.is_empty() & !Constraint::pure_unbounded) 
	     & !(result.second.is_empty() & !Constraint::pure_bounded)){//if result non empty
	    Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn));
	    cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	    cstr_result->copy_status(cstr);
	    cstr_result->set_process_old(at);
	    cstr_result->set_process_old(w);
	    if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_EXP
	      cout << "fire_EXP% which is entailed by the constraint: " << endl ;
#endif
	    }
	    else
	      result_min_set.insert(cstr_result);
	  }
	}
      }
    }
  if(domain!=L)//not pure left
    for(int w=at+1; w<=cn; ++w){
      //without insertion for each witness to the left
      int bwatv=bs+(w-1)*(bp+(cn-1)*bc);
      int uwatv=us+(w-1)*(up+(cn-1)*uc);

      if(same & (cstr->is_process_old(at) | cstr->is_process_old(w))){//same
	bool satisfiable_witness=check_witness_validity(at, batv, uatv, bwatv, uwatv, cstr);
	if(!satisfiable_witness)
	  continue;
	else{//satisfiable
	  pair<Clause, Dbm> result=fire_position_specified_witness_no_insertion(at, w, batv, uatv, bwatv, uwatv, cstr);
#ifdef DEBUG_FIRE_EXP
	  cout << "fire_EXP% no insertion: (fire, witness)=(" << at << "," <<  w << ")" << endl 
	       << "fire_EXP% no insertion gives" << result.first << result.second << endl ;
#endif
	  if(!(result.first.is_empty()&!Constraint::pure_unbounded) 
	     & !(result.second.is_empty()&!Constraint::pure_bounded)){//if result non empty
	    Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn));
	    cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	    cstr_result->copy_status(cstr);
	    cstr_result->set_process_old(at);
	    cstr_result->set_process_old(w);
	    if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_EXP
	      cout << "fire_EXP% which is entailed by the constraint: " << endl ;
#endif
	    }
	    else
	      result_min_set.insert(cstr_result);
	  }
	}
      }
    }


  // time for insertion
  if(!same & cstr->is_process_old(at))
      {
      if(domain!=R)
	{
	  int nbatv=bs+at*(bp+cn*bc); //new begining of process's variables 
	  int nuatv=us+at*(up+cn*uc); //new begining of process's variables 

	  for(int insert_position=1; insert_position<=at; ++insert_position)
	  {
	    int nbwatv=bs+(insert_position-1)*(bp+cn*bc); //new begining of channel's variables 
	    int nuwatv=us+(insert_position-1)*(up+cn*uc); //new begining of channel's variables 
	  
	    Constraint_Ref longer_cstr = cstr->insert_process_before(insert_position);

	    pair<Clause, Dbm> result=fire_position_specified_witness_no_insertion(at+1, insert_position, nbatv, nuatv, 
										  nbwatv, nuwatv, longer_cstr);
#ifdef DEBUG_FIRE_EXP
	    cout << "fire_EXP% insertion: (fire, witness)=(" << at << "," <<  insert_position << ")" << endl 
		 << "fire_EXP% insertion gives" << endl << result.first << result.second << endl ;
#endif
	
	    if(!(result.first.is_empty()&!Constraint::pure_unbounded)
	       & !(result.second.is_empty()&!Constraint::pure_bounded)){
	      Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn+1));
	      cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
	      cstr_result->copy_status_and_create(cstr, insert_position);
	      // cstr_result->set_process_old(at+1); //if the process was new we wouldn't have got here.
	      cstr_result->set_channel_old(at+1, insert_position);
	      if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_SDC
		cout << "fire_SDC% which is entailed by the constraint: " << endl ;
#endif
	      }
	      else
		result_min_set.insert(cstr_result);
	    }
	  }
	}

      if(domain!=L)
	{
	  int nbatv=bs+(at-1)*(bp+cn*bc); //new begining of process's variables 
	  int nuatv=us+(at-1)*(up+cn*uc); //new begining of process's variables 

	  for(int insert_position=at+1; insert_position<=cn+1; ++insert_position)
	    {
	      int nbwatv=bs+(insert_position-1)*(bp+cn*bc); //new begining of channel's variables 
	      int nuwatv=us+(insert_position-1)*(up+cn*uc); //new begining of channel's variables 
	
	      Constraint_Ref longer_cstr = cstr->insert_process_before(insert_position);
	      
	      pair<Clause, Dbm> result=fire_position_specified_witness_no_insertion(at, insert_position, nbatv, nuatv, 
										    nbwatv, nuwatv, longer_cstr);
#ifdef DEBUG_FIRE_EXP
	      cout << "fire_EXP% insertion: (fire, witness)=(" << at << "," <<  insert_position << ")" << endl 
		   << "fire_EXP% insertion gives" << endl << result.first << result.second << endl ;
#endif
	      
	      if(!(result.first.is_empty()&!Constraint::pure_unbounded)
		 & !(result.second.is_empty()&!Constraint::pure_bounded)){
		Constraint_Ref cstr_result(new Constraint(result.first, result.second, cn+1));
		cstr_result->set_bookmark(++Constraint::ccounter, cstr->cid, rid, at);
		cstr_result->copy_status_and_create(cstr, insert_position);
		cstr_result->set_channel_old(at, insert_position);
		if(cstr->entailed(cstr_result)){
#ifdef DEBUG_FIRE_EXP
		  cout << "fire_EXP% which is entailed by the constraint: " << endl ;
#endif
		}
		else
		  result_min_set.insert(cstr_result);
	      }
	    }
	}
      }      
  
#ifdef DEBUG_FIRE_EXP
  cout << "fire_EXP% output % " << result_min_set << endl ;
#endif
  
  return result_min_set;
}


bool EXP::check_satisfiable(int at, int batv, int uatv, const Constraint_Ref& cstr) const
{
    // First, the bounded case
  int bs=Constraint::bs, bp=Constraint::bp;
    int bsegment=bs+bp+bp;
    for(Actions_Sequence::const_iterator it=bounded_shared_and_process_guard.begin(); 
	it!=bounded_shared_and_process_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
	int r=0;
	if(index<=bs)	r=index;
	else if(index<=bs+bp) r=index-bs+batv;
	else if(index<=bsegment) assert(false);
	else if(index<=bsegment+bs) r=index-bsegment;
	else if(index<=bsegment+bs+bp) r=index-bsegment-bs+batv;
	else assert(false);
      
	if(ub+cstr->clause.gnlb(r)<=numb(-1)
	   | nlb+cstr->clause.gub(r)<=numb(-1) )
	  return false;
      }

    // Second, the unbounded variables
    int us=Constraint::us, up=Constraint::up;
    int usegment=us+up+up;
    for(Actions_Sequence::const_iterator it=unbounded_shared_and_process_guard.begin(); 
	it!=unbounded_shared_and_process_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int ri=0,rj=0;

	if(i<=us)  ri=i;
	else if(i<=us+up)	  ri=i-us+uatv;
	else if(i<=usegment) assert(false);
	else if(i<=usegment+us) ri=i-usegment;
	else if(i<=usegment+us+up) ri=i-usegment-us+uatv;
	else assert(false);
    
	if(j<=us)	rj=j;
	else if(j<=us+up)  rj=j-us+uatv;
	else if(j<=usegment)  assert(false);
	else if(j<=usegment+us) rj=j-usegment;
	else if(j<=usegment+us+up) rj=j-usegment-us+uatv;
	else assert(false);
      
	if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1)
	   | it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1) )
	  return false;
      }
    
    return true;
}


bool EXP::check_witness_validity(int at, int batv, int uatv, int bwatv, int uwatv, const Constraint_Ref& cstr) const
{
  if(!Constraint::pure_unbounded){
    // First, bounded variables
    int bs=Constraint::bs, bp=Constraint::bp;
    int bsegment=bs+bp+bp;
    for(Actions_Sequence::const_iterator it=bounded_witness_guard.begin(); 
	it!=bounded_witness_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));
	
	int r=0;
	if(bs+bp<index & index<=bsegment) r=index-bs-bp+bwatv;
	else if(bsegment+bs+bp<index) r=index-bsegment-bs-bp+bwatv;
	else assert(false);
	
	if(nlb+cstr->clause.gub(r)<=numb(-1)
	   | ub+cstr->clause.gnlb(r)<=numb(-1) )
	  return false;
      }
  }

  if(!Constraint::pure_bounded){
    // Second, unbounded variables
    int us=Constraint::us, up=Constraint::up;
    int usegment=us+up+up;
    for(Actions_Sequence::const_iterator it=unbounded_witness_guard.begin(); 
	it!=unbounded_witness_guard.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
	int ri=0, rj=0;
      
	if(i<=us) ri=i;
	else if(i<=us+up) ri=i-us+uatv;
	else if(i<=usegment) ri=i-us-up+uwatv;
	else if(i<=usegment+us) ri=i-usegment;
	else if(i<=usegment+us+up) ri=i-usegment-us+uatv;
	else ri=i-usegment-us-up+uwatv;
    
	if(j<=us) rj=j;
	else if(j<=us+up) rj=j-us+uatv;
	else if(j<=usegment) rj=j-us-up+uwatv;
	else if(j<=usegment+us) rj=j-usegment;
	else if(j<=usegment+us+up) rj=j-usegment-us+uatv;
	else rj=j-usegment-us-up+uwatv;
      
#ifdef DEBUG_WITNESS_VALIDITY
	cout << "check witness validity % (i,ri):(j,rj) " 
	     << ":(" << i << "," << ri << "):("  
	     << j << "," << rj << ")" << endl ;
      
	cout << "check witness validity % gij : "  << it->get_dbm().get(0,1) 
	     << ", rij: " << cstr->dbm.get(ri,rj) << endl ;
      
	cout << "check witness validity % gji : "  << it->get_dbm().get(1,0) 
	     << ", rji: " << cstr->dbm.get(rj,ri) << endl ;
#endif
      
	if(it->get_dbm().get(0,1)+cstr->dbm.get(rj,ri)<=numb(-1)
	   | it->get_dbm().get(1,0)+cstr->dbm.get(ri,rj)<=numb(-1) )
	  return false;
      }
  }

  return true;
}


pair<Clause,Dbm> EXP::fire_position_specified_witness_no_insertion(int at, int w, int batv, int uatv, 
						      int bwatv, int uwatv, const Constraint_Ref& cstr) const
{
  
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
  cout << "fire no insertion % input (at,w,batv, uatv, bwatv, uwatv) : ("
       << at << ","<< w << "," << batv << "," << uatv << "," << bwatv << "," << uwatv << ")"   << endl ;
#endif
  
  //first the bounded part
  int bs=Constraint::bs, bp=Constraint::bp;
  int bsegment=bs+bp+bp;
  Clause  working_clause=cstr->clause;

  if(!Constraint::pure_unbounded){
    // relax the modified variables
    set<int>::const_iterator mit;
    for(mit=bounded_shared_modified.begin(); mit!=bounded_shared_modified.end(); ++mit)  
      working_clause.modify(*mit, Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
    for(mit=bounded_process_modified.begin(); mit!=bounded_process_modified.end(); ++mit)  
      working_clause.modify(batv+*mit-bs,Constraint::Bb.gnlb(*mit), Constraint::Bb.gub(*mit));
    for(mit=bounded_witness_modified.begin(); mit!=bounded_witness_modified.end(); ++mit) 
      working_clause.modify(bwatv+*mit-bs-bp,Constraint::Bb.gnlb(*mit-bp), Constraint::Bb.gub(*mit-bp));
  
    // tighten whatever variable that was not modified, or is predecessor 
    // of a modified variable
    for(Actions_Sequence::const_iterator it=bsequence.begin(); it!=bsequence.end(); ++it)
      {
	int i=it->get_cipher().first(), j=it->get_cipher().second();
      
	int index=(i==0? j: i);
	numb nlb=(i==0? it->get_dbm().get(0,1) : it->get_dbm().get(1,0));
	numb ub=(i==0? it->get_dbm().get(1,0) : it->get_dbm().get(0,1));

	if(index<=bs)	
	  {if(!working_clause.tighten(index, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
	else if(index<=bs+bp)
	  {if(!working_clause.tighten(index-bs+batv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
	else if(index<=bsegment) 
	  {if(!working_clause.tighten(index-bs-bp+bwatv, nlb, ub)) return pair<Clause, Dbm>(Clause(), Dbm());}
      }

#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion % obtained clause :  " << working_clause << endl;
#endif 
  }

  //second, unbounded part
  int us=Constraint::us, up=Constraint::up;
  int usegment=us+up+up;
  Dbm  working_dbm(cstr->dbm.vars_card()+unbounded_shared_modified.size()
		   +unbounded_process_modified.size()+unbounded_witness_modified.size());

  if(!Constraint::pure_bounded){
    //copy the constraint. send the modified values according to modification.
    for(int i=0; i<=cstr->dbm.vars_card(); ++i){
      int bi=constraint_to_working(i, cstr->dbm.vars_card(), uatv, uwatv);
      for(int j=i+1; j<=cstr->dbm.vars_card(); ++j){
	int bj=constraint_to_working(j, cstr->dbm.vars_card(), uatv, uwatv);
	working_dbm.put(bi, bj, cstr->dbm.get(i,j));
	working_dbm.put(bj, bi, cstr->dbm.get(j,i));
      }
    }
 
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion % after copying constraint : " << working_dbm << endl ;
#endif

    // Get the bounds to the newly created variables 
    set<int>::const_iterator mit;
    for(mit=unbounded_shared_modified.begin(); mit!=unbounded_shared_modified.end(); ++mit)
      working_dbm.tighten(0,*mit,Constraint::Ub.gnlb(*mit));
    for(mit=unbounded_process_modified.begin(); mit!=unbounded_process_modified.end(); ++mit)
      working_dbm.tighten(0,uatv+*mit-us,Constraint::Ub.gnlb(*mit));
    for(mit=unbounded_witness_modified.begin(); mit!=unbounded_witness_modified.end(); ++mit)
      working_dbm.tighten(0,uwatv+*mit-us-up,Constraint::Ub.gnlb(*mit-up));

    // Finally apply the sequence of actions
    for(Actions_Sequence::const_iterator it=usequence.begin(); 
	it!=usequence.end(); ++it)
      { //for each action
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
	cout << "fire no insertion % considering action : " << *it << endl;
#endif   
	int i=it->get_cipher().first(), j=it->get_cipher().second();

	int wi=action_to_working(i, uatv, uwatv, usegment, cstr->dbm.vars_card()); // in working dbm
	int wj=action_to_working(j, uatv, uwatv, usegment, cstr->dbm.vars_card());

	if(!working_dbm.tighten(wi,wj,it->get_dbm().get(0,1)) 
	   | !working_dbm.tighten(wj,wi,it->get_dbm().get(1,0)))
	  {
	    return pair<Clause, Dbm>(Clause(), Dbm());
	  }
      }

    working_dbm=working_dbm.project_away(cstr->dbm.vars_card()+1, cstr->dbm.vars_card() 
					 + unbounded_shared_modified.size()+unbounded_process_modified.size()
					 + unbounded_witness_modified.size());
  
#ifdef DEBUG_FIRE_POSITION_SPECIFIED_WITNESS_NO_INSERTION
    cout << "fire no insertion% obtained dbm : " << working_dbm << endl ;
#endif    
  }

  return pair<Clause, Dbm> (working_clause, working_dbm);
}


inline int EXP::constraint_to_working(int i,int cs,int uatv,int uwatv) const
{

  if(i<=Constraint::us) //shared
    if(modification.find(i)!=modification.end())
      return cs+modification.find(i)->second;
    else return i;
  else if(uatv<i & i<=uatv+Constraint::up) //firing process 
    if(modification.find(Constraint::us+i-uatv)!=modification.end())
      return cs+(modification.find(Constraint::us+i-uatv)->second);
    else return i;
  else if(uwatv<i & i<=uwatv+Constraint::up ) //witness process 
    if(modification.find(Constraint::us+Constraint::up+i-uwatv)!=modification.end())
      return cs+(modification.find(Constraint::us+Constraint::up+i-uwatv)->second);
    else return i;
  else //anything else
    return i;
}


/* 
 */
inline int EXP::action_to_working(int i,int uatv,int uwatv,int usegment,int cs)const
{

  if(i<=Constraint::us)  return i; //shared variable !
  else if(i<=Constraint::us+Constraint::up) 
    return uatv+i-Constraint::us; //process variable
  else if(i<=usegment) 
    return uwatv+i-Constraint::us-Constraint::up; // witness variable
  else return cs+(modification.find(i-usegment)->second); //prime variable, check modification[i]
}


void EXP::printOn(ostream& o) const
{

#ifdef PRINT_PROCESS_WITNESS

#else
  cout << "EXP id: " << rid << endl;
  cout << "EXP domain: " << (domain==L? "L" : (domain==R? "R" : "LR")) << endl;
  cout << "EXP bsequence: " << bsequence;
  cout << "EXP bounded_shared_process_guard : " << endl 
       << bounded_shared_and_process_guard << endl;
  cout << "EXP bounded_witness_guard        : " << endl 
       << bounded_witness_guard << endl;
  cout << "EXP bounded image                : " << endl 
       << bimage << endl; 
  cout << "EXP usequence: " << usequence;
  cout << "EXP unbounded_shared_process_guard : " << endl 
       << unbounded_shared_and_process_guard << endl;
  cout << "EXP unbounded_witness_guard        : " << endl 
       << unbounded_witness_guard << endl;
  cout << "EXP unbounded image                : " << endl 
       << uimage << endl; 

#endif  
}








