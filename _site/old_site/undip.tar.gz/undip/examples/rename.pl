#!/usr/bin/env perl
use strict;

my $filename=shift;


open my $in, '<', $filename or die "can't open $filename $!";
open my $out, '>', "$filename.renamed" or die "can't write new file: $!";

while (<$in> )
{
    for(my $proc=1; $proc<=5; $proc++)
    {

	s/pc$proc\[0,0\]/pc$proc\(0\)/g;

	for(my $i=1; $i<=13; $i++)
	{
	    s/pc$proc\[-$i,$i\]/pc$proc\($i\)/g;
	}


	s/w$proc\[0,0\]/w$proc\(true\)/g ;
	s/w$proc\[-1,1\]/w$proc\(false\)/g ;
	
	s/a$proc\[0,0\]/a$proc\(true\)/g ;
	s/a$proc\[-1,1\]/a$proc\(false\)/g ;
	
	s/s$proc\[0,0\]/s$proc\(true\)/g ;
	s/s$proc\[-1,1\]/s$proc\(false\)/g ;

    }
    
    print $out $_;
}

close $in;
close $out;
