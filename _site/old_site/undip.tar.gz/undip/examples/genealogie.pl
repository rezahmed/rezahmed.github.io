#!/usr/bin/env perl
use strict;
#use warnings;


my $path=shift;

my $constraintid=shift;

my $onemore="true" ;

while ( $onemore eq "true" ) {
    $onemore="false";
    my $filelist=`ls $path`;
#    print $filelist;
    foreach my $filename ($filelist=~m/(\S+)/g){
#	print "processing file: $filename \n"; 
	open(my $in, $path.$filename) or die "can't open $filename $!";
	my $printnext="false";
	while (<$in> ){
	    if($onemore eq "false"){
#		print "here: $_";
		if($printnext eq "true"){
		print;
		print "\n";
		    if($constraintid!=0){
			$onemore="true";
		    }
		    $printnext="false";
		    
		}
		if(/\[id=$constraintid,/ && /pid=(\d+)\,.*rid=(\d+)\,.*pos=(\d+)/){
#		    print ;
		    print "parent is $1, rule is $2, position is $3 \n";
		    $constraintid=$1;
		    $printnext="true";
		}
	    }
	}
	close $in;
    }
}





